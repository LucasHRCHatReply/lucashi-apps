---
name: orch
description: Le tableau de bord de l'orchestration en cours — combien de sessions et d'agents elle a lancés, avec quel modèle, ce qu'ils coûtent, le poids du contexte, les règles du skill orchestrateur tenues ou manquées, et le bilan du mois. `/orch` (tableau), `/orch sessions`, `/orch agents`, `/orch poids`, `/orch cout`, `/orch regles`, `/orch bilan [jours]`, `/orch conseil`, `/orch accueil`.
version: 1.2.1
model: claude-haiku-5-5
effort: medium
allowed-tools: Bash(~/.claude/skills/orch/lancer.sh:*)
argument-hint: "[sessions|agents|poids|cout|regles|bilan N|conseil|accueil]"
---

# /orch — où en est l'orchestration

Toutes les commandes lisent la transcription de **cette** session (ou de tout ce Mac pour `bilan`) avec
`outils/etat.mjs` du dépôt du skill. Rien n'est envoyé nulle part.

Le dépôt est le dossier où pointe ce skill : `DEPOT=$(cd "$(dirname "$(readlink ~/.claude/skills/orch)")/.." && pwd)`
(ou `~/orchestration-claude` par défaut).

| Commande | Ce qu'elle dit | Lancer |
|---|---|---|
| `/orch` | le tableau : sessions, agents, poids, coût, suivi, règles tenues | `node "$DEPOT/outils/etat.mjs" tableau --dossier "$PWD"` |
| `/orch sessions` | chaque session lancée : titre, modèle, heure, état, id | `… sessions …` |
| `/orch agents` | les 25 derniers agents : modèle, en fond ou non, rendu ou non | `… agents …` |
| `/orch poids` | la jauge du contexte et le nombre de tours à partir duquel relancer coûte moins | `… poids …` |
| `/orch cout` | le coût de la session, conversation et agents | `… cout …` |
| `/orch regles` | les règles du skill orchestrateur tenues (✓), manquées (✗) et pourquoi | `… regles …` |
| `/orch bilan [jours]` | le mois de ce Mac comparé aux mesures de la v1 (≈ 25 s) | `… bilan 30` |
| `/orch conseil` | quel modèle et quel effort pour quel travail, avec la mesure | `… conseil` |
| `/orch accueil` | rouvre la page d'accueil et réécrit le mot d'accueil | voir plus bas |

## Sortie déjà calculée

Claude Code a lancé la commande avant ce tour (`/orch $ARGUMENTS`) ; sa sortie est ci-dessous :

!`~/.claude/skills/orch/lancer.sh $ARGUMENTS`

## Comment répondre

1. **Recopier la sortie ci-dessus telle quelle** (tableaux, jauges, ✓ ✗ ·), sans relancer la commande et sans
   rien recalculer de tête. Ne relancer par Bash que si la sortie est vide ou montre une erreur.
2. Pour `/orch` et `/orch sessions` dans l'app de bureau : compléter l'état **en direct** des sessions filles avec
   `mcp__ccd_session_mgmt__list_sessions` `{"linked": true}` (charger par `ToolSearch` s'il est différé) —
   colonne « En direct » : travaille, attend l'utilisateur, finie.
3. Terminer par **une ligne** « À faire maintenant : … » quand une règle est ✗ ou que le poids dépasse 200 k
   (ex. « armer `/point 5` », « écrire la note de reprise et relancer »). Rien d'autre.

## `/orch accueil`

`node "$DEPOT/outils/accueil.mjs"` relit les 30 derniers jours, écrit la page `~/.cache/orchestration/bienvenue.html` et l'ouvre.
Puis écrire dans la conversation un mot d'accueil court et visuel à partir de la sortie `--texte` :
`node "$DEPOT/outils/accueil.mjs" --texte` (chiffres de l'utilisateur) — un titre, trois chiffres marquants en tableau,
les trois commandes à essayer d'abord (`/orch`, `/orch conseil`, « orchestre ce chantier : … »), ton chaleureux et direct, aucun chiffre inventé.
