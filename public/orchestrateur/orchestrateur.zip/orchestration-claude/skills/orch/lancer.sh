#!/bin/bash
# Calcule la sortie de /orch avant le tour du modèle (injection !`…` du skill).
D="$(cd "$(dirname "$(readlink -f "$0")")/../.." && pwd)"
node "$D/outils/etat.mjs" "$@" --dossier "$PWD" 2>&1 | head -150
