---
name: orchestrateur
description: Session « prompt master » qui orchestre un chantier — découpe en étapes, lance de vraies sessions Claude Code (pas seulement des agents) avec pour chacune le modèle et l'effort les plus bas qui suffisent, les suit, les relance quand elles deviennent trop lourdes, et rend un résultat qu'on peut ouvrir. À utiliser automatiquement dès qu'on demande de lancer, déléguer, répartir ou faire faire du travail (sessions, agents, sous-tâches, « en parallèle », « lance les trois »), et quand on dit « orchestre », « prompt master », « /orchestrateur ». Chaque lancement s'annonce en une ligne : modèle · effort — parce que …
version: 3.1.0
---

# Orchestrateur — v3.1.0 du 16/11/2026

Ce skill condense des règles établies sur de vrais chantiers (migration de 20 sites, 335 pages relues,
206 essais modèle × effort) puis **corrigées sur 785 sessions mesurées du 20 au 29/10/2026**.
Chaque règle marquée *(mesuré)* vient d'un défaut observé ; le chiffre et sa source sont dans `CHANGELOG.md`.

## 0. Principe

L'orchestratrice **décide, découpe, vérifie**. Les sessions filles **exécutent** et rendent un résumé.
La mémoire du chantier vit dans des fichiers (plan, journal, notes de reprise), pas dans le contexte.

**Agent ou session ?** Ce n'est pas la même chose, et les confondre est l'échec n° 1 *(mesuré : 25 demandes
d'orchestration sur 45 n'ont lancé aucune session ; 8 ont fait des agents à la place)*.

| | Agent (outil `Agent`) | Session (outil `start_session`, ou `claude` lancé à part) |
|---|---|---|
| Vit | le temps du tour, rend un résultat à l'orchestratrice | sa propre conversation, survit au tour |
| L'utilisateur | ne la voit pas, ne lui parle pas | l'ouvre, la suit, lui parle, l'arrête |
| Pour | lire, chercher, relever, vérifier : un morceau du travail en cours | une tâche à part entière : une app, une branche, un domaine, un lot |

Quand l'utilisateur dit « lance des sessions », un agent **ne remplace pas** une session. Si aucune session
n'est possible ici, le dire en une ligne et prendre l'alternative du § 2 b, jamais basculer en silence.

## 1. Diagnostic de départ (30 secondes, à chaque orchestration)

1. **Quel moyen de lancer une session existe ici ?** Dans cet ordre :
   - Application de bureau Claude (onglet Code) : l'outil `mcp__ccd_session__start_session` existe, souvent
     **différé** : le charger d'abord avec `ToolSearch`, requête `select:mcp__ccd_session__start_session,mcp__ccd_session_mgmt__list_sessions,SendMessage`.
     S'il n'apparaît que dans la liste des outils différés, il existe : le charger, ne pas conclure qu'il manque.
   - Terminal (CLI) sans cet outil : lancer des processus `claude` à part (§ 2 b).
   - Ni l'un ni l'autre : agents en arrière-plan, **en le disant**.
2. **Annoncer** en une ligne : `Moyen : sessions de l'app` / `Moyen : claude -p en arrière-plan` / `Moyen : agents (pas de session possible ici, parce que …)`.
3. **Déjà fait ?** Chercher dans les notes et dépôts du projet ; la réponse s'ouvre par « Déjà fait : … » ou « Déjà fait : rien sur … ».

## 2. Lancer une session — le mode d'emploi concret

### a) Application de bureau (`start_session`)

```
start_session({
  title: "Relais — corriger l'envoi de fichiers",      // court, nomme la tâche
  initiation: "user_asked",                            // l'utilisateur l'a demandé en mots, dans CE tour
  context: "fresh",                                    // "fork" seulement tôt dans une conversation courte
  model: "claude-sonnet-5-5",                          // TOUJOURS explicite
  use_worktree: true,                                  // dès que deux sessions écrivent dans le même dépôt
  prompt: "<brief complet, voir § 4>"
})
```

Juste avant chaque appel, une ligne en gras avec le titre et une phrase sur ce que la session va faire ;
pour deux sessions ou plus, marquer d'abord un chapitre (`mark_chapter`).

Refus mesurés et parade *(mesuré : 30 lancements refusés sur 215, 14 %)* :

| Message de refus | Cause | Parade |
|---|---|---|
| « Start sessions only on the user's own words… » (19 fois) | le tour a été déclenché par une minuterie, un événement ou le message d'une autre session | **lancer toutes les sessions du plan dans le tour où l'utilisateur a parlé** ; sur un tour automatique, poser une carte (`initiation: "own_initiative"`) et le dire |
| « A proposal card cannot carry a host, folder… » (14 fois) | carte `own_initiative`/`offer` avec `cwd`, `host`, `preset` | une carte ne vise que ce projet ; un autre dossier demande `user_asked` |
| « working over Remote Control » (2 fois) | l'utilisateur écrit depuis son téléphone | le dire : à relancer depuis l'app de bureau, ou faire le travail ici |
| « not a trusted workspace » | dossier jamais ouvert dans l'app | demander à l'utilisateur de l'ouvrir une fois |

**Au lancement, le suivi sans modèle** (une fois par orchestration, 0 jeton ensuite) :
```bash
node ~/orchestration-claude/outils/suivi.mjs demarrer [--fond releve=chemin/du/journal.log] [--sonde 'pages=commande=>301'] [--depot chemin]
```
Il démarre le démon qui relit l'état écrit par les hooks (`hooks/etat.mjs`) et tient `~/.cache/orchestration/suivi/<id>/tableau.json`.
Puis `/sessiondesk` une fois, et le lien du bureau donné à l'utilisateur une fois : c'est **l'écran du point**. Puis le réveil (§ 5) :
`Monitor({ command: "node ~/orchestration-claude/outils/suivi.mjs guetter", description: "suivi : attentes, seuils, tout fini", timeout_ms: 1800000 })`.

Après le lancement : le résultat donne un `name` et un id `local_…`. Les suites passent par
`SendMessage({ to: "local_…" })` à **la session qui a le contexte**, jamais une nouvelle.

### b) Terminal, sans outil de session

```bash
cd <dépôt> && git worktree add ../<dépôt>-<tâche> -b <tâche>          # si elle écrit du code
cd ../<dépôt>-<tâche> && nohup claude -p "$(cat brief.md)" \
  --model sonnet --effort medium --permission-mode acceptEdits \
  --output-format stream-json --verbose > ~/.cache/orch/<tâche>.jsonl 2>&1 &
```

**Piège mesuré (03/11)** : avec `claude -p`, l'alias `--model haiku` donne **Haiku 4.5** (10× le prix de Haiku 5.5).
Passer l'id complet `--model claude-haiku-5-5`. Dans l'app, un agent `model: "haiku"` tourne bien sur Haiku 5.5.

Lancer chaque fille avec `ORCH_ORCHESTRATION=<id de l'orchestratrice>` devant `claude -p` : ses hooks l'étiquettent et
`suivi.mjs` la compte. Suivre : **pas de `tail` à chaque point** ; `guetter --fins` réveille sur chaque fin de tour (en CLI, l'app
ne le fait pas) et `suivi.mjs resume` dit ce qui a changé. La session rend son résumé dans le dernier événement `result`. Pour une session que l'utilisateur veut voir et piloter : lui donner la commande
`claude --model sonnet` à lancer dans un nouvel onglet du worktree, avec le brief à coller.

### c) Agents (morceaux du travail en cours)

`Agent({ description, prompt, model: "haiku"|"sonnet"|"opus" })` — toujours `model` explicite.
3 à 5 en parallèle au plus, dans un seul message. Au-delà de 20 agents en cours, l'outil refuse
(« Concurrent subagent limit reached ») : ne pas relancer en boucle, attendre qu'une vague finisse
*(mesuré : 78 refus de ce type)*. Un gros lot (des centaines de pages) passe par un script qui traite
par vagues, pas par des centaines d'agents.

### d) Production en série (vidéos, visuels, documents du même format)

Ne jamais faire coder chaque pièce. **Un gabarit, puis des données** *(mesuré le 02/11/2026 sur des vidéos
TikTok Remotion : 93 654 jetons Sonnet pour une vidéo codée à la main, contre ≈ 52 000 jetons Haiku pour un
JSON sur gabarit, de meilleure qualité ; le gabarit coûte 136 383 jetons une seule fois, amorti dès la 2e pièce)* :
1. Une fille Sonnet · medium construit le gabarit, le script de rendu (`--verifier` sans rendu) et un guide
   court qui sera **le seul contexte** des petits modèles.
2. Des filles Haiku · medium écrivent les données (une pièce ≈ 2 000 jetons ; le reste est le coût fixe de
   démarrage, donc **plusieurs pièces par fille**). Elles ne lancent pas le rendu.
3. Le rendu tourne en script, sans modèle, sous `caffeinate`.
4. Une fille Sonnet · low contrôle chaque chiffre affiché sur des images extraites, contre la source.
**Une pièce témoin validée par l'utilisateur avant tout lot** (contrôle, rendu, voix payante) *(mesuré : 0,62 $ de
contrôle perdus sur un lot rejeté ensuite ; écrire les données en série : 1 fille Sonnet pour 8 pièces = 0,058 $/pièce,
4 filles Haiku pour 8 = 0,017 $/pièce mais textes plats)*. Les textes qu'un humain écoute vont à Sonnet, pas à Haiku.
Tout calcul se vérifie par une commande (`node -e`) et sa formule s'affiche *(mesuré : l'essai du gabarit
affichait 0,357 × 8 000 = 2 856 € en oubliant + 1 395 € du barème)*.

### e) Déléguer hors Claude (GPT, Gemini)

Une tâche bornée, avec un critère de fin vérifiable, qu'un autre fournisseur fait mieux ou sans coût d'API
(manuel du § 3) : `node outils/deleguer.mjs --a gpt|gemini|claude --modele <id> --effort <e> --mode … --dossier … --brief …`,
toujours précédé de `--a-sec`. Mode d'emploi, refus et journal : `deleguer.md`. L'annonce suit la même forme :
> → images-lanterne — GPT Terra · low (déléguer) — parce que série d'images avec référence, 0 $ d'API

Le rendu se vérifie comme celui d'une fille : fichier ouvert, test relancé, capture regardée.

## 3. Choisir modèle et effort (à chaque lancement, relance ou changement)

Claude **orchestre, unifie, anime et vérifie** ; le reste va au fournisseur qui le fait le mieux, sur les abonnements.
Règle : **le plus petit modèle et le plus bas effort qui réussissent**, vérifiés par un critère objectif ;
monter le **modèle** avant l'**effort**. Juger sur le **gros du travail** (ce que la session lit et répète).

### Le manuel des modèles

Usage → modèle · effort → ce que ça donne. **Public** : évaluation publiée, relue à sa source le 13/11/2026
(détail, URL et dates : `manuel-modeles.md`). **Maison** : nos bancs (`bancv1/routage.txt`, banc intermodèle, banc de délégation).
Quand les deux divergent, la tâche décide : **courante → effort bas** (nos bancs saturent : l'effort n'y change rien),
**dure ou large → effort haut** (public : Opus ARC-AGI-2 low 70,1 → high 93,3 ; au-delà de high, le score baisse).

| Usage | Courant (maison) | Dur (public) | Ce que ça donne | À éviter |
|---|---|---|---|---|
| Code spécifié et testé : script, algorithme, bug, dépôt jusqu'à 32 fichiers | **Haiku · medium** ; Sonnet · low si aucun test ne vérifie le rendu ; ou **déléguer** à GPT Terra low (0 $ d'API) | Sonnet 5.5 · xhigh | banc codedur du 16/11 (8 tâches dures × 3) : Haiku medium 24/24 à 1,0 pour 0,0077 $, Sonnet low 24/24 pour 0,051 $ (6,6 ×), Haiku low 0,988 · délégation : 48/48 à 1,00 · SWE-bench Pro V2 Sonnet 95,8 %, Haiku 87,2 % | Haiku low sans test qui rattrape (semver 0,94) ; spec floue ou dépôt de plus de 32 fichiers : non mesuré, Sonnet ; `max` (FrontierCode 52,1 → 46,2) |
| Code : multi-fichiers, revue de diff | Sonnet · medium + seconde relecture GPT Terra | Sonnet 5.5 · xhigh (Fable 5.2 en premier choix qualité) | Terra relit : 7 constats, 16 570 jetons contre 8 et 79 921 pour Sonnet | `gpt-6-luna` pour relire |
| Décider, concevoir, orchestrer | Opus · medium | Opus 5.5 · high | ARC-AGI-2 high 93,3 % ; n'a battu Sonnet sur aucune des 11 tâches du banc v1 | Opus pour exécuter |
| Question courte, fait, commande | Haiku · low | — | — | — |
| Lire, extraire, trier, note à gabarit | Haiku · medium (jamais low pour extraire) | Haiku 5.5 volume, Sonnet contrôle | même note que Sonnet au banc v1, 1/15 du prix | Haiku sur un tableur (−10,4 points sous Sonnet) |
| Rédaction | Sonnet · low à medium | Opus 5.5 · high | banc v1 : Sonnet medium premier (0,948) · Arena créatif : Opus 1517, Sonnet 1464 | GPT-6 pour le style (1408 à 1451) |
| Veille, recherche web | **GPT Sol · medium `--search`**, chiffres recoupés par WebFetch | idem | 0 chiffre faux sur 5 questions, contre ≥ 10 pour Gemini Hydrogen ; 1,76 × plus lent | un chiffre Gemini non relu à sa page |
| Première passe de veille, liste de pages | Gemini Hydrogen · medium | — | 762 s pour 5 questions ; juste sur les classements simples | dépendre d'un chiffre lié à une version ou un effort |
| Image raster, texture, scène | **GPT Sol** via `codex exec` | GPT-Image (Sunburst) en tête des classements | 9,5/10 contre 7 pour Claude (SVG) | une image raster demandée à Claude |
| Série d'images, avatar, icône | référence validée puis **GPT Terra** `-i reference` | — | ≈ 35 000 → 15 000 jetons, note 6,3 → 8,2 ; série Lanterne : cohérence 9/10 | relancer sans référence |
| SVG à cadrage exact | Claude (SVG puis Inkscape) | — | 7,5 contre 7, taille garantie | — |
| Front-end, animations, intégration | Sonnet · medium | Sonnet 5.5 · xhigh (WebDev 1772) | Lanterne : intégration et animation Claude, juge 7/10 | GPT-6 Luna, Gemini 3.8 Flash (WebDev 1577, 1583) |
| Captures, comparaison d'images | Sonnet · low (**jamais Haiku**) | Opus 5.5 · high pour l'image | — | Haiku |
| Données de jeu (quiz, listes) | GPT Terra, faits relus par Claude | — | 8 contre 6,5 ; 9 460 jetons contre 58 976 | — |
| Données en masse structurées | Haiku · medium ; GPT Luna high si quota GPT ouvert | Haiku volume, Sonnet contrôle | banc v1 masse : Luna high 0,991 | GPT-6 en finance agentique (Luna 56,8) |
| Tâche longue autonome | étapes de quelques minutes, chacune vérifiée par Claude | Gemini Hydrogen · high pour la régularité | Vending-Bench 2 : Hydrogen ± 495 $, Sonnet ± 1 585 $ ; **aucune mesure publique de durée autonome fiable** | une chaîne de plusieurs heures sans point de contrôle |
| Très long contexte | n/a | n/a : aucun score MRCR ou RULER recoupé | — | prendre la fenêtre annoncée pour une longueur utile |
| Bloqué après 2 tentatives | Opus · high (sur accord), puis expliquer l'obstacle | — | — | `max` |

**Gemini 4 Hydrogen au banc v1** (13/11/2026, 153 essais sur 201, juge Sonnet medium ; verdict provisoire, 48 essais manquants faute de quota) : égale les meilleurs en **raisonnement à high** (1,0 ; medium 0,875) et en **web à medium** (0,978) ; égale sans gain en code, masse, contexte (plafonds du banc) ; **perd en veille** (0,794, jusqu'à 178 s) et en image (0,778). Usage : raisonnement ou page web quand le quota Claude est tendu, jamais seul pour la veille ni l'image.
Jamais Astra (quota), jamais Argon sous 30 % de quota, jamais `max`.

### La chaîne créative type

1. **Gemini** (Hydrogen · medium, recherche web) : veille de tendances et proposition de direction artistique (palette, polices, consigne d'image).
2. **GPT** : une image de référence (Sol), validée, puis la série avec `-i reference` (Terra ou Sol).
3. **Claude** : unifie (intègre dans la page, harmonise), anime, puis **vérifie** : captures 1440 et 390, images chargées, pas de défilement horizontal, juge.
Mesuré une fois (mini-site Lanterne, 13/11/2026, `outils/bancs/delegation/CONCLUSION.md`) : 7/10 au juge, cohérence des images 9/10 ;
les liens de veille de Gemini sont des redirections Google, à rouvrir. Pas de variante tout-Claude : la chaîne n'est pas prouvée meilleure, elle est la seule à produire des images raster.

### Hors Claude : comment

Par `outils/deleguer.mjs` (§ 2 e, `deleguer.md`) : il refuse au-delà des seuils de quota (Codex semaine > 70 % ou 5 h > 85 % ;
Gemini 5 h < 25 % ou semaine < 30 % de reste) et note chaque appel dans `~/.cache/orchestration/intermodele/<fournisseur>.jsonl`
(le bureau et `/orch modeles` le lisent). Avant un lot : `--a-sec`, puis plafond fixé avec l'utilisateur. Un sous-agent Claude paie
≈ 57 000 jetons de démarrage ; Codex 4 000 à 25 000. Images à la main (sans `codex` sur le poste) : l'orchestratrice écrit des briefs prêts à coller
(style, fichiers nommés, tailles, ZIP attendu), une fille Sonnet · low contrôle et installe le ZIP. Le volet visuel se propose d'office
*(consigne de l'utilisateur du 12/11/2026 : « à chaque fois je t'en ai parlé, tu dévies »)*.
Limites : une répétition au plus par couple (un point d'écart est du bruit), banc de code délégué saturé (tâches trop faciles), Fable non mesuré en orchestratrice.

- **Garde-fou Opus** : une session qui lit un domaine entier ou répète la même analyse part sur Sonnet.
  *(mesuré : les sessions principales Opus · medium font 66 sessions sur 785 et 75 % du coût.)*
- **La conversation elle-même** : sur Opus depuis 5 réponses sans rien lancer, et le travail est de l'exécution →
  proposer Sonnet en une ligne (sélecteur de l'app ou `/model sonnet`). Le hook `aiguillage` le rappelle une fois par conversation.
  *(mesuré le 02/11 : 59 conversations Opus sans lancement en 30 jours, 475 $ ; basculer à la 5ᵉ réponse : − 188 $ net, cache réécrit compris.)*
- **Jamais de modèle par défaut** pour une fille *(mesuré : 26 % des lancements sans `model` ; la fille hérite alors du modèle de l'app, souvent Opus)*.
- **Montée sur échec** : 1er → corriger le brief, même niveau ; 2e → modèle +1 ; 3e → Opus high, puis
  expliquer l'obstacle et passer à autre chose. Après 3 réussites vérifiées de suite, essayer le cran en dessous.
- **Jamais `max`.**

**Annonce obligatoire, avant chaque lancement** (dans l'app, le texte écrit juste avant un appel d'outil n'est pas
enregistré dans la transcription : aucun hook ne peut la contrôler, elle repose sur ce skill), une ligne dans la conversation, même pour un seul agent
*(mesuré : faite dans 24 % des orchestrations seulement ; le hook `aiguillage` la rappelle si elle manque)* :

> → relais-fichiers — Sonnet · medium — parce que code multi-fichiers vérifiable par `make test` (Opus n'a rien battu au banc, 2× le prix)

Pour un lot, le tableau :

| Session | Modèle · effort | Pourquoi | Critère de fin |
|---|---|---|---|
| relais-fichiers | Sonnet · medium | code multi-fichiers, tests automatiques | `make test` vert + envoi réel d'un fichier |

Un changement s'annonce `avant → après` avec la raison.

## 4. Le brief d'une fille

Une session neuve ne sait **que** ce que dit son brief. Il contient, dans l'ordre :
1. **But** en une phrase et **critère de fin vérifiable** (commande, test, comptage, capture).
2. **Zone** : dépôt, dossier, fichiers ; ce qu'elle ne doit pas toucher (fichiers d'une autre fille).
3. **Déjà décidé / ne pas refaire.**
4. **Conditions d'arrêt** dites par l'utilisateur (« arrête-toi une fois publié », « avant 18 h »).
5. **Processus de fond** : tout banc, serveur, `caffeinate`, surveillance qu'elle lance, elle l'arrête à la fin et le liste dans son rapport.
6. **Avancement** (trois lignes à coller telles quelles) : « À chaque étape franchie et au moins toutes les 10 minutes,
   lance `node ~/orchestration-claude/outils/avancer.mjs --etape n/N --nom "<étape>" --fait x/X --prochain "<action>" [--obstacle "<…>"]`.
   Un processus de fond que tu lances écrit dans son journal une ligne `[point] x/X, ~t min restantes` au moins toutes les minutes.
   Ne fais pas de point toi-même : l'écran le tient. » Le compteur d'outils ne dit pas l'avancement ; ces lignes, si.
7. **Rapport attendu** : 5 champs — fait ; preuve (commande + dernière ligne de sa sortie, collée telle quelle) ;
   non fait ou non vérifié ; décisions prises ; ce qui attend l'humain. Plus une ligne « ce qui contredit le brief ».

**Index de code (CodeGraph et équivalents) : ne pas en installer pour les filles.** Mesuré le 04/11 sur 64 essais
(Haiku 5.5 · medium, Sonnet 5.5 · low, `outils/bancs/outils-externes/resultats-gros.csv`) : sur un dépôt de 738 fichiers
comme sur un de 130, mêmes réponses exactes (11/16), mêmes tours (32 et 33), jetons **+19 à +30 %** et coût **+32 à +41 %** selon le calcul (cache écrit : définitions d'outils
en plus). Un sous-agent ne reçoit pas les instructions MCP : si un index existe déjà, le brief nomme l'outil et colle son bloc,
sinon la fille l'ignore. Au-delà de 738 fichiers ou pour des questions d'analyse en chaîne : non mesuré.

**Comment le remplir : `methode-brief.md`** (veille de 23 sources, `references/veille-prompts-2026-11.md`).
L'essentiel : lire avant de demander ; ne poser des questions que si deux lectures mènent à des livrables
différents, si le critère ou le périmètre manque, ou si l'action est irréversible (au plus 3, en un message,
avec le défaut recommandé) ; critère de fin = une commande et sa valeur attendue ; contexte par chemins, pas
par copie ; brief adapté au modèle (Haiku : étapes et critère mécanique ; Opus : spécification complète, sans
« vérifie deux fois »). *Statut : non prouvé au banc A/B du 03/11 (tâches trop faciles, le brief naïf réussissait
déjà ; questions : +10 points sur 10 demandes ambiguës, sous le seuil de 15). À remesurer sur des tâches dures.*

## 5. Pendant

- **Le bandeau** (extension de l'app, `mod/`) se tient replié au-dessus de la saisie ; quand le suivi tourne, il porte la ligne
  vivante du démon (« ◎ 5 sessions · 2 travaillent · 2 vous attendent · 1 rapport à juger · 11 h 23 ») ;
  un clic montre qui travaille, qui attend, le contexte et le coût, et « Bureau ↗ » ouvre `/sessiondesk`.
- **`/orch`** donne à tout moment le tableau de bord de l'orchestration (sessions, agents, poids, coût, règles tenues ✓/✗) ; s'en servir pour le point et avant le compte rendu final.
- **Le suivi couvre les sous-agents d'abord, les sessions ensuite** : chaque appel d'outil d'un agent arrive au hook avec son
  `agent_id`, `SubagentStart`/`SubagentStop` le bornent, et le tableau donne une carte par agent (description, modèle, dernière
  action, fin) avant les cartes de sessions. *(mesuré le 16/11 sur Claude Code 2.1.319.)*
- **Le suivi est tenu par les hooks, le démon `suivi.mjs` et le bureau : 0 jeton.** L'orchestratrice **n'arme aucune minuterie
  récurrente de moins de 20 minutes** et ne fait pas de point par tour de modèle. La règle de l'utilisateur « un point toutes les
  cinq minutes » reste vraie : c'est l'écran qui la tient (bandeau à 20 s, bureau à 2 s, `/point` à la demande). Ne pas réarmer
  une minuterie par réflexe. *(mesuré le 16/11/2026 : 13 points de minuterie en 76 min, 8 sans rien à juger ; chacun relisait
  200 000 à 300 000 jetons ; les 5 points utiles coïncidaient avec une fin de tour de fille, qui réveille déjà l'orchestratrice.)*
- **Elle ne se réveille que sur événement** :

  | Événement | Qui le détecte | Ce qu'elle fait |
  |---|---|---|
  | un agent en arrière-plan finit | l'outil (`<task-notification>`) | lit son résultat, le fait vérifier, juge |
  | une fille finit un tour | l'app (`<side-sessions-event>`) ; en CLI `guetter --fins` | lit le rapport, le fait vérifier, juge |
  | une fille attend l'utilisateur | hooks `etat` et `attente`, `guetter` | une ligne : qui, quoi, le lien du bureau ; rien de récurrent ensuite |
  | seuil : silence 15 min, même action 5 fois, contexte > 200 000 | `suivi.mjs`, `guetter` | un tour : corriger ou arrêter la fille |
  | heure dite par l'utilisateur | minuterie **ponctuelle**, écrite aussi dans le plan et la note de reprise | fait la tâche |
  | rien de tout cela | — | **aucun tour** |

  Le filet : l'expiration du `Monitor` à 30 min la réveille une fois ; elle lit le résumé, réarme, et c'est tout.
  **À chaque réveil, elle ne lit qu'un fichier** : `node ~/orchestration-claude/outils/suivi.mjs resume` (40 lignes au plus,
  ce qui a changé depuis le réveil précédent). Ni `list_sessions`, ni `tail` de journaux, ni sortie brute.
- **Le téléphone** part du démon (`notifier.sh`, s'il existe) sur trois événements seulement : une attente de plus de 10 min
  (sauf si le hook `relance-telephone` s'en charge déjà), un seuil franchi, tout fini. Jamais deux messages en moins de 5 min.
- **Regarder ce que font les filles, pas seulement si elles ont fini** : une fille qui répète le même
  groupe de tests depuis 20 min, ou qui tourne sans progrès, s'interrompt et se corrige. *(mesuré : correction de l'utilisateur)*
- **Une remarque de l'utilisateur qui concerne une fille** lui est transmise (`SendMessage`) tout de suite ; l'orchestratrice confirme « transmis à <nom> ».
- **Une consigne à heure dite** (« à 12 h, passe sur Relais ») s'arme en minuterie ou s'écrit dans le plan avec l'heure ; jamais de mémoire. *(mesuré : « je t'avais pas dit de bosser sur Relais à 12 h ? »)*
- Le rapport d'une fille **n'est pas une preuve** : ouvrir le diff, relancer le test, regarder la page.
  **Le vérificateur est le chemin par défaut** (`agents/verificateur.md`, Haiku · medium) : l'orchestratrice ne relit pas elle-même
  les notes des filles ni ne relance leurs commandes ; les sondes mécaniques (`--sonde`) tournent dans le démon. Elle ne reçoit
  que « accepté » ou « à reprendre » avec la raison, note le verdict (`suivi.mjs juger --session <id> --verdict accepte|a-reprendre`,
  le bureau cesse de compter le rapport « à juger ») et garde pour elle les jugements non mécaniques. Un seul vérificateur par chantier,
  lancé avec les critères de fin de chaque fille, puis continué par `SendMessage` avec chaque rapport ;
  il relance les commandes, recompte, ouvre les diffs, et rend « accepté » ou « à reprendre » avec la consigne
  à renvoyer. *(mesuré le 03/11 : 16 défauts semés sur 16 trouvés, 0 fausse alerte sur 8 cas justes, 0,0023 $
  par vérification ; cas petits, effet plafond possible.)*
- **Une fille qui attend l'utilisateur** (question ou autorisation) : le hook `attente` l'écrit dans
  `~/.cache/orchestration/attentes/`, le bandeau la compte. L'orchestratrice la présente en carte
  (`questions-visuelles.md`, gabarit `outils/question-carte.html`, ≈ 550 jetons) : la question en mots simples,
  le contexte, un schéma, 2 à 4 options avec leur conséquence, la recommandée en premier ; la réponse part à la
  fille par `SendMessage`. **Une autorisation d'outil reste la décision de l'utilisateur** : l'orchestratrice
  l'explique et le dit, elle ne l'approuve jamais à sa place (un message n'est pas un clic, et les filles le refusent).
  **Une orchestratrice ne relaie jamais un accord d'écriture de l'utilisateur** (écrire en ligne, publier, pousser, supprimer) :
  le bureau porte, pour chaque attente, **la phrase d'accord à coller et le lien de la session** (`claude://code/needs-input?session=…`) ;
  l'utilisateur la colle lui-même dans la fille. *(constaté le 16/11 : les filles refusent un accord relayé, le contrôle
  d'autorisations aussi ; c'est le bon comportement, ne pas perdre un tour à essayer.)*
  Les autorisations récurrentes s'évitent en amont : liste d'autorisations validée par l'utilisateur.
- Un obstacle qui résiste à deux tentatives : l'expliquer en français courant, le noter, passer à autre chose.
- Une remarque de l'utilisateur en cours de route se range dans l'étape qui la couvre ; elle ne rouvre pas l'ordre du plan.

## 6. Poids des sessions : relancer plutôt que grossir

*(mesuré : 59 sessions ont dépassé 300 000 jetons de contexte, 20 seulement ont été relancées avec une note ; elles font 76 % du coût total.)*

- Avertir à **200 000** jetons ; relancer à **300 000** à la fin de l'étape ; tout de suite à **500 000**. Filles : 200 000.
- Formule : relancer coûte moins que continuer si `tours restants > 3,3 M / (contexte − 100 000)`.
- **Note de reprise** (≤ 150 lignes) : but et critère de fin, compteurs avec source, commande de reprise
  unique, décisions et « ne pas refaire », fichiers, traitements en cours, sessions filles (id, modèle, effort,
  état), processus de fond, ce qui attend l'humain. La session neuve ne lit que la note et ce qu'elle liste.
- Le hook `hooks/poids-de-session.mjs` (installé par `install.sh`) rappelle les seuils automatiquement.
- **Ce qui ne doit pas grossir le contexte** : le résumé de réveil est borné à 40 lignes ; aucune sortie de journal brute,
  aucun tableau de point répété. Le démon `suivi.mjs` et ses fichiers survivent à la relance : la note de reprise donne
  la commande `suivi.mjs demarrer` (elle rattache le même tableau) et le `Monitor` à réarmer.
- **À 250 000, la note s'écrit d'elle-même** (dans l'app) : `outils/ranger.mjs relance` la pose dans
  `Journal/Sessions/` du projet, avec le plan, les commits, les fichiers, le reste à faire et le prompt de la session
  neuve. La session la **complète** (décisions, chiffres avec leur source, pièges), commite, puis propose la relance.
  *(mesuré le 02/11 : une grosse session sur deux seulement laissait une note quand on comptait sur la consigne.)*

## 7. Finir

- **Arrêter ce qu'on a lancé** : bancs, serveurs, `caffeinate`, minuteries, `Monitor`, le démon de suivi
  (`node ~/orchestration-claude/outils/suivi.mjs arreter` ; il s'arrête seul après 12 h, ou 2 h après que tout est fini), sessions filles inutiles.
  Le compte rendu final liste ce qui tourne encore et pourquoi. *(mesuré : trois corrections pour un banc ou un `caffeinate` oublié)*
- **Aller jusqu'au résultat exploitable** : un lien, un fichier, une page — et vérifier que l'utilisateur a
  **la bonne version** (fichier remplacé, page rechargée).
- Compte rendu : situer (quoi, pourquoi, où on en est), puis le détail, les décisions prises, ce qui reste ; tableaux et chemins à la fin.
- Le verdict de la session (tests, commits, corrections) s'écrit seul à chaque fin de tour (hook `verdict`) ;
  un changement de code se termine par ses tests : si du code a changé depuis les derniers tests d'un dépôt
  qui en a, le hook refuse une fois la fin de tour et donne la commande. `/retour` ne sert plus qu'à ajouter le prompt et la leçon, quand la session a appris quelque chose qui contredit ce skill.

## Prompt de démarrage type

> Tu es l'orchestratrice de ce chantier (skill `orchestrateur`). But : <…>. Critère de fin : <…>.
> Fais le diagnostic de départ, annonce le plan en étapes puis le tableau des sessions
> (modèle · effort · pourquoi · critère de fin), lance-les **toutes dans ce tour**, démarre le suivi (`suivi.mjs demarrer`, bureau, `Monitor` sur `guetter`) sans minuterie de point,
> vérifie chaque rapport, relance toute session au-delà de 300 000 jetons avec une note de reprise,
> arrête tout ce que tu as lancé à la fin. Va jusqu'au résultat exploitable.

## Références

`references/` garde les règles d'origine avec leurs mesures (dépôt complet seulement : le paquet public ne les contient pas). Ce sont les règles de travail d'un
utilisateur précis : les chemins `~/pboard` et les prénoms y sont des exemples, pas des prérequis.
