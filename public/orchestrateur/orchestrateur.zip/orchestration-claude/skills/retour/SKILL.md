---
name: retour
description: Retour d'expérience de fin de session, partagé entre les comptes via le dépôt orchestration-claude — type de tâche, modèle · effort choisis, verdict, montée éventuelle, le prompt (généralisé) qui a marché ou raté, la leçon. Alimente la synthèse commune. À utiliser en fin de session, quand on dit « /retour », « fais le retour », « partage les perfs », ou avant `/pause`.
---

# /retour — ce que cette session apprend aux autres

Les chiffres (jetons, coût, modèles, agents) sont déjà relevés par `outils/extraire.mjs` (relu sur les transcriptions) et le hook `hooks/verdict.mjs`. Ce skill ajoute **ce que les chiffres ne disent pas** : est-ce que ça a marché, avec quel prompt, et faut-il changer la règle.

## Étapes

0. Le verdict est déjà calculé : le hook Stop `hooks/verdict.mjs` l'écrit à chaque fin de tour dans `~/.cache/orchestration/verdicts/<session>.json` (dernière série de tests, commits réussis, corrections, `verdict` et `critere`). Le reprendre pour la ligne de la session principale ; ne le changer que si la relecture le contredit, et dire pourquoi dans `ce_qui_a_rate`.
1. Relire la session et dresser **une ligne par tâche distincte** confiée à un modèle (la session elle-même, chaque agent, chaque session fille). Au plus 8 lignes.
2. Pour chaque ligne, remplir l'objet JSON ci-dessous. **Rien de confidentiel** : pas de nom de client, d'URL interne, de donnée personnelle ni de secret. Le prompt se **généralise** (« Relève toutes les différences de texte entre la capture A et B, format : tableau zone/source/cible ») ; jamais de copie brute.
3. Ajouter les lignes à `~/orchestration-claude/perfs/<compte>/retours.jsonl` (le compte est dans `perfs/.compte`), une ligne JSON par tâche.
4. Si une leçon vaut pour tout le monde (règle à changer, prompt réutilisable), l'écrire aussi dans `apprentissages/AAAA-MM-JJ-<conclusion>.md` (10 lignes au plus : constat, mesure, ce qu'on change).
5. Commiter et pousser :
   `cd ~/orchestration-claude && git add perfs apprentissages && git commit -m "perfs : retour <compte> <sujet>" && git pull --rebase && git push`
6. Dire en 2 lignes ce qui a été partagé.

## Format d'une ligne

```json
{"v":1,"date":"2026-10-22","compte":"ton-prenom","session":"30c03422","tache":"capture|extraction|code-script|code-bug|code-revue|code-refacto|redaction|classement|decision|orchestration|recherche|autre","role":"principal|agent|session-fille","modele":"haiku|sonnet|opus","effort":"low|medium|high|xhigh","verdict":"reussi|reussi-apres-correction|echec","montee":"aucune|prompt|modele|effort","critere":"comment on a vérifié (tests, comptage, relecture…)","prompt_generalise":"…","ce_qui_a_marche":"…","ce_qui_a_rate":"…","lecon":"une phrase, ou vide"}
```

## Règles

- Le verdict s'appuie sur un critère objectif (test, comptage, relecture humaine), sinon `reussi` ne s'écrit pas : `n/a`.
- Ce skill est mécanique : Haiku · medium suffit ; ne pas lancer d'agent pour le faire.
