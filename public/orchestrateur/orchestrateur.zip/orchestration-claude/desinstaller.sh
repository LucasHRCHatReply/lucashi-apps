#!/bin/bash
# Retire ce que install.sh a posé : les hooks de ce dépôt dans ~/.claude/settings.json (sauvegarde gardée à côté),
# les liens des skills vers ce dépôt, les tâches mensuelles. Le dossier lui-même et vos perfs restent : supprimez-le
# ensuite si vous le voulez (rm -rf ~/orchestration-claude).
# Usage : ./desinstaller.sh
set -euo pipefail
cd "$(dirname "$0")"; DEPOT=$(pwd)
S=~/.claude/settings.json
if [ -f "$S" ]; then
  cp "$S" "$S.avant-desinstallation"
  node -e '
const fs=require("fs"),[s,depot]=process.argv.slice(1);const d=JSON.parse(fs.readFileSync(s,"utf8"));let n=0;
for(const [ev,liste] of Object.entries(d.hooks||{})){const garde=liste.map(g=>({...g,hooks:(g.hooks||[]).filter(h=>{const x=String(h.command||"").includes(depot+"/hooks/");if(x)n++;return !x})})).filter(g=>g.hooks.length);
  if(garde.length)d.hooks[ev]=garde;else delete d.hooks[ev];}
fs.writeFileSync(s,JSON.stringify(d,null,2));console.log(n+" hook(s) retiré(s) ; sauvegarde : "+s+".avant-desinstallation");' "$S" "$DEPOT"
fi
for l in ~/.claude/skills/*; do [ -L "$l" ] && [[ "$(readlink "$l")" == "$DEPOT/"* ]] && rm "$l" && echo "skill retiré : $(basename "$l")"; done
for P in ~/Library/LaunchAgents/com.orchestration-claude.*.plist; do [ -f "$P" ] || continue
  launchctl bootout gui/$(id -u) "$P" 2>/dev/null || true; rm "$P"; echo "tâche retirée : $(basename "$P")"; done
echo "Fait. Le dossier $DEPOT reste en place."
