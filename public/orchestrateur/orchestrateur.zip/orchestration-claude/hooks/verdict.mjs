#!/usr/bin/env node
// Hook Stop : à chaque fin de tour, le verdict de la session sans /retour — dernière série de tests
// (verte ou rouge), commits réussis, corrections de l'utilisateur — écrit dans
// ~/.cache/orchestration/verdicts/<session>.json. /retour le reprend tel quel ; extraire.mjs le recalcule
// pour l'historique partagé. Ne bloque jamais, n'injecte rien. 02/11/2026 : 0 /retour donné depuis le 22/10.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { analyserSession, verdict } from '../outils/extraire.mjs';
const lireStdin = () => { try { return fs.readFileSync(0, 'utf8'); } catch { return ''; } };
export const DOSSIER = process.env.ORCH_VERDICTS || path.join(os.homedir(), '.cache', 'orchestration', 'verdicts');

try {
  const e = JSON.parse(lireStdin() || '{}');
  const f = e.transcript_path;
  if (f && fs.existsSync(f)) {
    const { s, projet } = await analyserSession(f, '0000');
    const v = { session: String(e.session_id || path.basename(f, '.jsonl')), app: process.env.CLAUDE_CODE_HOST_SESSION_ID || '',
      projet, debut: s.debut, fin: s.fin, messages_humains: s.humains, corrections: s.corrections,
      series_tests: s.seriesTests, tests_fin: s.tests, commits: s.commits, ...verdict(s) };
    fs.mkdirSync(DOSSIER, { recursive: true });
    const cible = path.join(DOSSIER, v.session + '.json');
    fs.writeFileSync(cible + '.tmp', JSON.stringify(v) + '\n'); fs.renameSync(cible + '.tmp', cible);
  }
} catch {}
process.exit(0);
