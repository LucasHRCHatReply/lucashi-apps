#!/usr/bin/env node
// Hook UserPromptSubmit + PostToolUse : mesure ce qu'une session relit à chaque tour (le contexte
// envoyé au modèle, lu dans l'usage du dernier tour du journal de session) et, au passage d'un palier,
// rappelle en contexte la règle « une-session-trop-longue-se-relance-avec-une-note-de-reprise ».
// Une fois par palier et par session ; au palier fort, une notification part aussi sur le téléphone.
// Ne bloque jamais. Mesure du 09/10 : la session PPA relisait ~780 000 jetons par tour.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
const lireStdin = () => { try { return fs.readFileSync(0, 'utf8'); } catch { return ''; } };

const AVERTIR = 200_000;   // la session coûte déjà cher : préparer la relance (mesure du 20/10 : 80 % du coût Opus est au-delà de 300 000)
const RELANCER = 300_000;  // relancer à la fin de l'étape en cours (seuils recalculés le 20/10, voir la règle)
const RAPPEL_TOUS = 100_000; // au-delà, un nouveau rappel tous les 100 000 jetons de plus
const ETAT = path.join(os.homedir(), '.cache', 'orchestration', 'poids-sessions');
const JOURNAL = path.join(os.homedir(), '.cache', 'orchestration', 'poids-sessions.jsonl');
// Notification facultative : une commande qui reçoit (message, titre), ex. ORCH_NOTIFIER=~/bin/ntfy.sh
const NOTIFIER = process.env.ORCH_NOTIFIER || (fs.existsSync(path.join(os.homedir(), 'pboard/outils/notifier.sh')) ? path.join(os.homedir(), 'pboard/outils/notifier.sh') : '');

// Lit la fin du journal de session (il peut peser des centaines de Mo) et rend le contexte du dernier tour.
function contexteDuDernierTour(fichier) {
  const taille = fs.statSync(fichier).size;
  const n = Math.min(taille, 4 * 1024 * 1024);
  const fd = fs.openSync(fichier, 'r');
  const buf = Buffer.alloc(n);
  fs.readSync(fd, buf, 0, n, taille - n);
  fs.closeSync(fd);
  const lignes = buf.toString('utf8').split('\n').reverse();
  for (const l of lignes) {
    if (!l.includes('"usage"')) continue;
    try {
      const d = JSON.parse(l);
      const u = d?.message?.usage;
      if (d.type === 'assistant' && u) return (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    } catch {}
  }
  return 0;
}

try {
  let entree = {};
  try { entree = JSON.parse(lireStdin() || '{}'); } catch {}
  const transcript = entree.transcript_path;
  if (!transcript || !fs.existsSync(transcript)) process.exit(0);
  const session = String(entree.session_id || path.basename(transcript, '.jsonl'));
  const contexte = contexteDuDernierTour(transcript);
  if (contexte < AVERTIR) process.exit(0);

  fs.mkdirSync(ETAT, { recursive: true });
  const fEtat = path.join(ETAT, `${session}.json`);
  let etat = { dernier: 0, notifie: false };
  try { etat = JSON.parse(fs.readFileSync(fEtat, 'utf8')); } catch {}
  const prochain = etat.dernier === 0 ? AVERTIR : etat.dernier + RAPPEL_TOUS;
  if (contexte < prochain) process.exit(0);

  const k = Math.round(contexte / 1000);
  const fort = contexte >= RELANCER;
  const texte = fort
    ? `Poids de cette session : elle relit environ ${k} 000 jetons à chaque tour, ce qui vide vite le quota. Règle du skill orchestrateur (section 5) : à la fin de l'étape en cours, ne lance rien de nouveau ; écris une note de reprise (état chiffré, fichiers et commandes, traitements inachevés et comment les reprendre, décisions, prochaines étapes, ce qui attend l'utilisateur), commite, puis propose de continuer dans une session neuve où Opus orchestre et Sonnet relève.`
    : `Poids de cette session : elle relit déjà environ ${k} 000 jetons à chaque tour. Garde les relevés, captures et gros fichiers dans des agents Sonnet qui rendent un résumé, et prépare la note de reprise : au-delà de 300 000, la relance avec note de reprise s'applique (skill orchestrateur, section 5).`;

  const evenement = entree.hook_event_name || (entree.prompt !== undefined ? 'UserPromptSubmit' : 'PostToolUse');
  process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: evenement, additionalContext: texte } }));

  if (fort && !etat.notifie && NOTIFIER) {
    const titre = path.basename(entree.cwd || '') || 'session';
    // Détaché : la notification part même si le hook rend la main tout de suite.
    spawn(NOTIFIER, [`Session ${titre} : ~${k} 000 jetons relus par tour, à relancer avec une note de reprise`, 'Session trop longue'], { detached: true, stdio: 'ignore' }).unref();
    etat.notifie = true;
  }
  etat.dernier = contexte;
  fs.writeFileSync(fEtat, JSON.stringify(etat));
  fs.appendFileSync(JOURNAL, JSON.stringify({ ts: new Date().toISOString(), session, cwd: entree.cwd, contexte, palier: fort ? 'relancer' : 'avertir' }) + '\n');
} catch {}
process.exit(0);
