#!/bin/bash
# Installe le skill d'orchestration sur ce Mac.
# Usage : ./install.sh <nom-du-compte> [--analyste] [--sans-accueil] [--sans-taches]
#   <nom-du-compte>  nom sous lequel les perfs de ce Mac sont partagées (ex. lucas-perso)
#   --analyste       ce Mac fait aussi la passe mensuelle d'amélioration (un seul Mac, ex. le Mac mini)
# Ce que ça pose :
#   ~/.claude/skills/<skill>  liens vers ce dépôt (un « git pull » met les skills à jour) ;
#                             un skill du même nom déjà présent est gardé tel quel
#   hook poids-de-session     rappel de relance à 200 000 / 300 000 jetons (UserPromptSubmit)
#   tâche du 1er du mois      propose de partager les perfs du mois, avec aperçu — rien ne part sans « Partager »
#   tâche du 3 du mois        (--analyste) synthèse + proposition d'amélioration en PR
#   page d'accueil            écrite par Claude (Haiku, ≈ 0,01 $) sur les 30 derniers jours de ce Mac, puis ouverte
set -e
cd "$(dirname "$0")"
DEPOT=$(pwd)
COMPTE=${1:-$(cat perfs/.compte 2>/dev/null || true)}
[[ "$COMPTE" == --* ]] && COMPTE=$(cat perfs/.compte 2>/dev/null || true)
if [ -z "$COMPTE" ]; then read -rp "Nom de ce compte dans les perfs (ex. lucas-perso) : " COMPTE; fi
echo "$COMPTE" > perfs/.compte
NODE=$(command -v node) || { echo "node est requis (https://nodejs.org)"; exit 1; }
command -v claude >/dev/null || echo "attention : la commande claude n'est pas dans le PATH"

# 1. Skills
mkdir -p ~/.claude/skills
for s in skills/*/; do
  nom=$(basename "$s"); cible=~/.claude/skills/"$nom"; source="$DEPOT/${s%/}"
  if [ -L "$cible" ] && [ "$(readlink "$cible")" != "$source" ]; then
    echo "gardé : $nom (déjà installé depuis $(readlink "$cible"))"; continue; fi
  if [ -d "$cible" ] && [ ! -L "$cible" ]; then echo "gardé : $nom (un skill à vous porte ce nom)"; continue; fi
  ln -sfn "$source" "$cible"; echo "installé : $nom"
done

# 2. Hooks : poser le rappel de poids, retirer l'ancien envoi automatique de fin de session (v0)
S=~/.claude/settings.json; [ -f "$S" ] || echo '{}' > "$S"
"$NODE" -e '
const fs=require("fs"),[s,node,depot]=process.argv.slice(1);const d=JSON.parse(fs.readFileSync(s,"utf8"));
fs.copyFileSync(s,s+".avant-orchestration");d.hooks??={};
if(d.hooks.SessionEnd){const n=d.hooks.SessionEnd.length;d.hooks.SessionEnd=d.hooks.SessionEnd.filter(h=>!JSON.stringify(h).includes("perfs/collecter.mjs"));
  if(d.hooks.SessionEnd.length<n)console.log("ancien envoi automatique de fin de session retiré");if(!d.hooks.SessionEnd.length)delete d.hooks.SessionEnd;}
d.hooks.UserPromptSubmit??=[];
if(!JSON.stringify(d.hooks).includes("poids-de-session.mjs")){d.hooks.UserPromptSubmit.push({hooks:[{type:"command",command:`${node} ${depot}/hooks/poids-de-session.mjs`,timeout:10}]});console.log("hook poids-de-session ajouté");}
else console.log("hook poids-de-session déjà présent");
fs.writeFileSync(s,JSON.stringify(d,null,2));' "$S" "$NODE" "$DEPOT"

# 3. Tâches mensuelles (launchd)
tache() { # nom jour heure script
  local P=~/Library/LaunchAgents/com.orchestration-claude.$1.plist
  mkdir -p ~/.cache/orchestration ~/Library/LaunchAgents
  cat > "$P" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.orchestration-claude.$1</string>
  <key>ProgramArguments</key><array><string>/bin/bash</string><string>$DEPOT/$4</string></array>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>$(dirname "$NODE"):$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin</string></dict>
  <key>StartCalendarInterval</key><dict><key>Day</key><integer>$2</integer><key>Hour</key><integer>$3</integer><key>Minute</key><integer>0</integer></dict>
  <key>StandardOutPath</key><string>$HOME/.cache/orchestration/$1.log</string>
  <key>StandardErrorPath</key><string>$HOME/.cache/orchestration/$1.log</string>
</dict></plist>
PLIST
  launchctl bootout gui/$(id -u) "$P" 2>/dev/null || true
  launchctl bootstrap gui/$(id -u) "$P" && echo "tâche $1 : le $2 du mois à $3 h"
}
if [[ " $* " == *" --sans-taches "* ]]; then echo "tâches mensuelles : non posées (--sans-taches)"; else
tache partage 1 10 outils/partager.sh
if [[ " $* " == *" --analyste "* ]]; then
  command -v gh >/dev/null || echo "attention : gh (GitHub CLI) est requis pour ouvrir la PR mensuelle"
  tache analyse 3 9 outils/analyse-mensuelle.sh
fi
fi

# 4. Le mot d'accueil : Claude le rédige sur les chiffres de ce Mac, la page s'ouvre
if [[ " $* " != *" --sans-accueil "* ]]; then "$NODE" outils/accueil.mjs || true; fi

echo
echo "Compte : $COMPTE. Dans Claude Code : « orchestre ce chantier », /orch pour le tableau de bord, /orch accueil pour revoir l'accueil."
echo "Partager l'historique existant maintenant (aperçu puis accord) : outils/partager.sh --depuis 2026-10-01"
