# Journal des versions du skill orchestrateur

## 1.5.0 — la note de reprise s'écrit d'elle-même à 250 k — 02/11/2026

- Défaut mesuré par le bilan d'utilité : une session de plus de 300 k sur deux seulement laissait une note de reprise. Jusqu'ici, le hook ne faisait que rappeler la consigne.
- **`hooks/poids-de-session.mjs`** : à 250 000 jetons de contexte, une fois par session et dans l'app seulement (il faut l'id `local_…`), il lance `outils/ranger.mjs relance`. Le code écrit la note ; la session la complète avant de proposer la relance.
- **`ranger.mjs relance [id]`** : note de relance même en plein travail, sans toucher au plan de rangement. Elle contient le prompt de la session neuve. Elle n'est jamais réécrite par-dessus les compléments. 0,8 s sur cette session (11 Mo, 242 tours).
- **Commits retrouvés** : `git commit -qm` et `-am` n'étaient pas reconnus, seul `-m` l'était. La note de cette session passe d'1 commit à 19. Cache de `ranger` en version 4.
- **Conseil Sonnet (1.4)** : un lancement est maintenant marqué par le hook PostToolUse. Le conseil ne se trompait plus que sur les longues conversations dont le lancement était sorti des 4 derniers Mo, comme celle-ci : il a conseillé Sonnet à une conversation qui avait lancé des agents.
- Tests : `aiguillage.test.mjs` 11/11 (marquage, 220 k, 260 k hors de l'app, 260 k dans l'app une seule fois), `ranger.test.mjs` 31/31.
- Limite : « Ce qui tourne encore » liste aussi les tâches de fond déjà finies.

## 1.4.0 — la conversation qui ne lance rien se voit proposer Sonnet — 02/11/2026

- Défaut mesuré par le bilan d'utilité : le skill choisissait le modèle des agents et des sessions, jamais celui de la conversation où l'on tape. Une conversation sur deux qui ne lance rien restait sur Opus.
- **Le hook `aiguillage`** (UserPromptSubmit) compte les réponses distinctes de la conversation. Sur Opus depuis 5 réponses, sans session, agent ni workflow lancé, il demande une fois de proposer Sonnet en une ligne, seulement si le travail est de l'exécution ; un travail de décision reste sur Opus. Une marque dans le dossier temporaire empêche le conseil de revenir.
- Seuil réglé sur 30 jours (`bascule.mjs`, scratchpad de la session) : 59 conversations Opus sans lancement, 475 $. Basculer à la 3ᵉ, 5ᵉ, 8ᵉ ou 12ᵉ réponse : − 192, − 188, − 183, − 178 $ net. La réécriture du cache Sonnet compte pour 13 $, et 42 conversations sur 52 y gagnent. La 5ᵉ réponse laisse le temps de voir la nature du travail.
- Coût du hook : 0,04 s sur une transcription de 168 Mo (lecture des 4 derniers Mo). Test `aiguillage.test.mjs` 7/7.

## Bilan d'utilité — le skill sert-il ? — 02/11/2026

Mesuré sur ce Mac, conversations réelles (au moins 3 messages humains), trois périodes : avant le skill (15/09 → 19/10, 63 sessions), règle + skill v0 (20/10 → 29/10, 39), skill v1.2 automatique (30/10 → 02/11, 11). Outil : **`outils/utilite.mjs`**, sur les fiches de `extraire.mjs`.
- Coût par message humain : 5,34 $ → 1,80 $ → 1,38 $ (− 74 %). Tours d'agents sur Opus : 67,5 % → 23,2 % → 0 %. Agents avec un modèle explicite : 34 % → 100 % → 100 %.
- Tours au-delà de 300 k de contexte : 66,7 % → 25,3 % → 12,5 %. Annonce modèle · effort dans les orchestrations : 21 % → 39 % → 83 %.
- Corrections de l'utilisateur pour 100 messages (indice de qualité, par expression régulière) : 6,7 → 7,5 → 3,0.
- Pas tenu : les sessions qui ne lancent rien restent sur Opus une fois sur deux (58 % → 62 % → 50 %) ; une grosse session sur deux seulement laisse une note de reprise ; aucun verdict `/retour` n'a été donné.
- Banc des 11 tâches recalculé : 0,61 $ → 0,26 $ (− 57 %, et non − 66 %), note 0,94 → 0,96, 203 s → 135 s. Le relevé du CLI y comptait Haiku 5.5 environ 40 fois son prix : on garde le calcul aux prix publics.
- Rejeu de dix jours recalculé (`simuler.mjs` gardait la première ligne de chaque réponse) : 2 206 $ → 1 849 $ (− 16 %, − 357 $), et non 1 759 $ → 1 408 $ (− 20 %).
- `extraire.mjs` : le coût des agents garde la plus longue ligne d'une réponse, comme la conversation. `ranger.mjs` : `releveCorrige()` recalcule la part Haiku 5.5 du relevé, que Claude Code compte à 0,55 de son prix public (médiane de 370 relevés). Test `couts.test.mjs` 10/10.
- Limite : 11 sessions sur 3,6 jours, week-end compris, pour la v1.2 ; à revoir avec la passe mensuelle du 30/11.

## /sessiondesk 1.2.0 — coûts justes, rafraîchissement en 5 ms, frise du temps — 02/11/2026

Demande : apprendre des outils équivalents pour un outil fiable, rapide et chiffré. Code lu (pas seulement les README) : ccusage, claude-code-viewer, sniffly, disler/claude-code-hooks-multi-agent-observability ; crystal et vibe-kanban repérés.
- **Le coût était faux de −17 % à −24 % (médiane par session), corrigé.** Témoin : le relevé `cost-state` que Claude Code écrit lui-même dans la transcription (coût par modèle, agents compris), sur les 222 sessions qu'il couvre en entier. Trois causes :
  (1) une réponse s'écrit en plusieurs lignes sous le même `message.id`, et seule la dernière porte la sortie complète. L'ancienne déduplication gardait la première ligne (exemple : 812 jetons de sortie Sonnet comptés au lieu de 62 690). Nouveau `compteur()` dans `extraire.mjs` : il garde la ligne la plus longue, comme ccusage ;
  (2) l'écriture en cache d'une heure (la moitié des écritures de Claude Code) était comptée ×1,25 au lieu de ×2 ;
  (3) les prix étaient par famille. Opus 5 était compté au prix d'Opus 5.5, la lecture du cache Sonnet 5.5 à ×0,05 au lieu de ×0,1, celle de Fable 5.1 à ×0,05 au lieu de ×0,025. S'y ajoutent le tarif de Haiku 5.5 au-delà de 100 k jetons et le mode rapide ×2. Nouvelle grille au modèle exact (prix publics du 06/10/2026).
- **Mesures** (`node outils/tests/couts.test.mjs` 9/9, et comparaison au relevé sur ce Mac) :

  | | Avant | Après |
  |---|---|---|
  | Total des 222 sessions (relevé : 4 875 $) | 3 925 $ | 4 811 $ |
  | Écart médian au relevé | 23,2 % | 4,8 % |
  | Sessions à moins de 2 % du relevé | 1 | 75 |

  Sur 30 jours (97 214 tours), le coût au prix de l'API passe de 7 164 $ à 10 430 $. L'écart qui reste vient d'appels que Claude Code facture sans les écrire dans la transcription. **Quand le relevé couvre toute la session, la page l'affiche** (« relevé ») ; sinon elle affiche le calcul, qui est un plancher (« calculé »). Lignée des apps du 28 au 30/10 : 543 $ affichés en 1.1, 641 $ maintenant, dont 24 sessions sur 32 au relevé. Les chiffres déjà publiés avec l'ancienne formule (bancs, bilans, perfs d'octobre) ne sont pas recalculés ici.
- **Rafraîchissement : 611 ms → 5 ms quand rien n'a bougé.** Le serveur garde le dernier calcul et une empreinte de l'environnement : tailles et dates du magasin de l'app, des transcriptions et des dossiers d'agents (5,9 ms, sans rien lire). Il ne recalcule que si l'empreinte change. La page relit donc toutes les **5 s** au lieu de 15 (idée de sniffly, cache taille + mtime). Une génération nouvelle ajoute un fichier au magasin : la page la voit au rafraîchissement suivant, la suit et l'annonce (« ↻ L'orchestration vient d'être relancée : génération n »).
- **Mode Temps** (idée de disler et de ccusage) : une frise avec une barre par session, de sa création à sa dernière activité. La couleur dit le modèle, la bordure l'état. Les agents sont des traits fins sous la session qui les a lancés, les relances de l'orchestration des pointillés, et une ligne verte marque maintenant quand quelqu'un travaille.
- **État « en suspens »** (idée de crystal : ne pas réclamer d'action pour rien) : une session qui attend ou s'est arrêtée depuis plus de 2 jours, processus fermé, quitte « Bloquées » pour « Au repos ». Lignée des apps : « À débloquer » passe de 19 entrées à 2, les deux seules qui datent du jour.
- `lignee.test.mjs` suit la session « (4) » supprimée de l'app le 02/11 (la lignée du lundi compte maintenant 3 générations) : 12/12. `bureau.test.mjs` 35/35, `ranger.test.mjs` 31/31.

## Partage automatique — 02/11/2026

Le partage du 01/11 n'a rien envoyé : lancé par launchd après un clic à 16 h 06, `git ls-remote origin` a échoué et le script a posé le fichier dans `~/Downloads` sans le signaler, en marquant pourtant le mois comme partagé (`perfs/.dernier-partage` à 2026-11-01). Source : `~/.cache/orchestration/partage.log`. Pour une installation faite depuis le zip du site, c'était même le seul chemin possible : fichier à envoyer à la main.
- **Après « Partager », plus rien à envoyer à la main.** Clone avec droit d'écriture : push (3 essais). Sinon, ou si GitHub ne répond pas : `POST https://apps.srv875929.hstgr.cloud/api/perfs` (serveur `serveur/perfs/` du dépôt lucashi-apps, pm2 `lucashi-perfs`, port 8242). Si rien ne passe : le mois reste à partager, une copie va dans `~/Downloads`, notification.
- **La réception refuse tout texte libre** : chaque fiche est vérifiée (session en 8 hex, projet haché, chaînes de 80 caractères au plus, sans ponctuation de phrase) ; un prompt dans une ligne fait refuser tout le lot. `perfs/.cle` (tirée à la première fois, hors dépôt) attache le nom du compte à son installation. 6 envois par heure et par IP, 8 Mo par lot.
- **`outils/rapatrier.sh`** (hors du zip public) : le 2 du mois à 10 h (`install.sh --rapatrier`, compris dans `--analyste`) et au début de la passe du 3, copie par ssh les lots reçus, les fusionne dans `perfs/<compte>/historique.jsonl`, pousse, puis les range dans `traites/` sur le serveur. Serveur lu dans `perfs/.vps` (hors dépôt).
- Mesures : fichier d'octobre accepté tel quel par la réception (1 205 fiches) ; essai zip contre une réception locale : 55 fiches reçues, réception coupée → code 1, mois non marqué ; essai de bout en bout VPS → clone jetable : 3 fiches reçues, rapatriées, poussées, rangées. Octobre poussé dans le dépôt : l'historique du Mac de l'auteur passe de 785 à 1 253 sessions (commit f26946a).

## /sessiondesk 1.1.0 — 02/11/2026

Retours de Lucas sur la 1.0 (« ça marche pas mal pour une V1 ») : suivre une orchestration qui se relance, et une page qui se lit d'un coup d'œil.
- **Une orchestration relancée reste une seule orchestration.** Quand une orchestratrice trop lourde passe la main à une session neuve, la page montre la lignée G1 → G2 → … : titre et état de la dernière génération, sous-sessions et agents de toutes les générations, coûts et compteurs additionnés. Liens déterministes (`generations()` dans `outils/bureau.mjs`), lus dans le magasin de l'app et le premier message de chaque session (mis en cache) :
  (1) fille au titre marqué (« (reprise) », « (4) », « reprise du … ») et proche de celui de sa mère (mots communs ≥ 40 %) ;
  (2) fille dont le brief dit la passation (« passe la main », « ancienne orchestration », note `reprise-orchestration-…` ou `reprise-commune`, ou le résumé de contexte « previous orchestration »), au titre proche ou orchestration comme sa mère ;
  (3) session sans mère qui « reprend l'orchestration » : la dernière orchestration du même dossier, finie depuis moins de 72 h.
  Une fille de travail relancée (même titre, marque ou brief de reprise) devient la suite de sa devancière : un seul poste, marqué ↻.
- **Mesures** (magasin de ce Mac, 374 sessions) : **21 liens de génération** trouvés en 6 ms une fois les briefs en cache (50 ms à froid), tous vérifiés à la main. Lignée d'un chantier client du 2/11 : **4 générations**, 19 sessions dont 6 relances, 21 agents, 92,71 $, calculée en 0,54 s. Lignée des apps du 28 au 30/10 : **5 générations**. La 2ᵉ venait d'une passation écrite dans le résumé automatique de contexte, en anglais ; ajoutée après un premier essai qui en voyait 4. Environnements : 59 → **58** (une entrée par lignée, nommée par sa dernière génération). Faux lien écarté : « Orchestrateur : commande pour ranger… », fille d'une orchestration, reste une fille.
- **Page plus visuelle** : quatre tuiles d'état (En cours, Bloquées, Finies, Au repos) qui filtrent la page, et une bande **À débloquer** qui donne la question en attente de chaque session bloquée. Au Bureau, les pôles sont triés par état, avec une bordure de couleur et l'état en deux mots. Les agents qui travaillent ou bloquent gardent leur poste ; les agents finis se replient en un tas (« ✓ 12 ») qu'un clic déplie. Les générations précédentes finies sont repliables (« Génération 3 · 2 tâches finies · 6 agents · 17,94 $ »). En Liste, les sessions sont groupées par génération. Le détail va au survol : état expliqué, question, modèle, coût, contexte, relances.
- Tests : `bureau.test.mjs` **35/35** (Mac fictif, avec une génération 2, une fille relancée et une fille qui cite une note de reprise sans être une génération) ; nouveau `lignee.test.mjs` **12/12** sur les vraies sessions de ce Mac (sauté ailleurs) ; `ranger.test.mjs` 31/31.

## /sessiondesk 1.0.0 — 02/11/2026

Nouveau skill `/sessiondesk` : une page locale (`http://127.0.0.1:4517`) qui montre ce qu'orchestre la session courante. En tête, son titre et une phrase qui dit ce qu'elle orchestre. Dessous, ses sous-sessions et ses agents : état, modèle · effort, coût, contexte, durée. Deux modes : **Bureau**, où chacun est un petit personnage à son poste (couleur = modèle, animation = état), et **Liste**, en tableaux filtrables. « Voir plus » raconte en français ce que chacun a fait, ce qu'il a rendu et ce qui reste. Un sélecteur permet de passer aux autres orchestrations du Mac.
- **Calcul déterministe avant le tour** (`outils/bureau.mjs`, injection `!` comme `/orch`). La famille de sessions vient de `ranger.mjs liste --json --avec-archivees` (réutilisé tel quel), les agents de `~/.claude/projects/…/<session>/subagents/agent-*.meta.json` et de leur transcription. Le rendu d'un agent se lit dans l'outil `SubagentHandback`. Cache par transcription (`bureau-cache.json`, clé taille:mtime). Mesures : 0,56 s pour une orchestration de 1 session ; **2,3 s à froid, 0,45 s en cache** pour 28 sessions et 234 agents ; 55 environnements trouvés en 0,2 s (sessions de l'app qui ont lancé des sessions ou des agents, et transcriptions du terminal qui ont lancé des agents, sur 45 jours).
- **Seul le récit passe par un modèle** : Haiku 5.5 · low, sans outils, sans serveurs MCP, sans réglages ni hooks, avec un prompt système réduit. L'extrait envoyé fait 2 000 caractères environ (demande, dernier rapport, plan, commits ; ou consigne et rendu de l'agent). Il est mis en cache par empreinte de l'extrait : un état inchangé ne coûte plus rien. Mesures d'un récit : 6 à 10 s, 13 à 15 k jetons, **0,002 $ aux prix du dépôt**, 0,054 à 0,064 $ selon la CLI. Au deuxième affichage : **0,01 s et 0 $**. La phrase de tête suit la même règle, une fois par famille (6,5 s puis 0,01 s).
- **Coût d'un lancement de `/sessiondesk`** (`claude -p "/sessiondesk"` depuis `~/lucashi-apps`, 02/11/2026) : le tour passe sur Haiku 5.5 (modèle du skill), 1 tour, 5,1 s, 63 877 jetons de contexte écrits en cache, 427 en sortie, **0,26 $ selon la CLI**. Le script lui-même prend 0,8 s. Dans une session déjà longue, ce tour relit le contexte de la session sur Haiku.
- Le serveur local se remplace seul quand le code change (empreinte des fichiers dans `/api/ping`) et s'arrête après 3 h sans visite. La page relit les données toutes les 15 s, sans modèle.
- États : travaille, attend, interrompue, à relire, au repos, endormie, finie, et **rangée** (archivée dans l'app). Une session rangée n'apparaît plus « attend » ou « interrompue ». Un agent non fini dont la session ne tourne plus est « interrompu ».
- Tests : `node outils/tests/bureau.test.mjs`, **28/28**, sur un Mac fictif (HOME temporaire, `claude` simulé, aucun coût). `ranger.test.mjs` reste à 31/31. Le paquet public passe le garde-fou de `outils/paquet.sh` (essai dans un dossier temporaire, zip public non reconstruit).

## 1.3.2 — 02/11/2026

Ajout du § 2 d « Production en série » après un banc de vidéos TikTok Remotion (dépôt `~/le-vrai-chiffre`, note `R-D/2026-11-02-une-video-tiktok-a-chiffres-se-fabrique-par-un-gabarit-remotion-et-un-json-ecrit-par-haiku`).
- Vidéo codée de zéro, Sonnet · medium : 93 654 jetons. Gabarit Sonnet · medium : 136 383 jetons une fois. JSON par Haiku · medium : 98 261 à 114 922 jetons pour 2 vidéos (≈ 52 000 par vidéo), 8/8 valides du premier coup. Source : `subagent_tokens` des notifications.
- Retour qualité de l'utilisateur sur le lot Haiku (« mots pas intéressants ») : textes réécrits par Sonnet, 0,46 $ pour 8. Règle « pièce témoin avant tout lot » ajoutée (0,62 $ de contrôle perdus).
- Un calcul faux dans l'essai du gabarit (barème kilométrique sans + 1 395 €) : vérification par commande rendue obligatoire.

## 1.3.1 — 30/10/2026

Correction de `/orch ranger` après l'essai de Lucas sur une orchestration de chantier client (20 sessions, 65 Mo de transcriptions). Rejeu en lecture seule : `node outils/tests/ranger.test.mjs` (31 vérifications), avec `--avec-archivees` et `--maintenant 2026-10-30T16:23:44Z`.

- **Lenteur** : `liste` dépassait 120 s dans l'injection et Haiku recevait une sortie vide. Mesure (temps cumulé par commande sur 26 sessions) : `git rev-parse` 27,4 s, `git log -1` 9,8 s, `git show` 3,5 s, `git log --all` 3,5 s, `git branch` 3,0 s, `git status` 0,7 s ; la lecture des transcriptions comptait pour presque rien. Corrigé : un cache par transcription (`~/.cache/orchestration/ranger-cache.json`, clé taille:mtime, résumé sérialisable), la recherche de commits déplacée dans `notes`, un `git` par dépôt pendant le run, et pour un fichier de plus de 40 Mo la lecture de la fin seule (coût, jetons et tours alors `n/a`, jamais 0). **48 s → 0,7 s** sur 26 sessions (lucashi-apps, même famille avant et après) ; **0,51 s à froid, 0,31 s à chaud** sur le cas réel (20 sessions).
- **`timeout` n'existe pas sur macOS** : Haiku l'avait utilisé pour relancer à la main. Le skill n'autorise plus que `~/.claude/skills/orch/lancer.sh ranger …` et, si la sortie injectée est vide, le relance tel quel.
- **Faux « travaille »** : 8 sessions sans processus, inactives depuis des jours, l'étaient parce que le `mtime` du fichier est retouché par l'app. Corrigé : horodatage du dernier événement `user` ou `assistant`, « travaille » = processus vivant et moins de 3 min. Nouveaux états : 🔴 interrompue (pas de processus, dernier tour non terminé) et 💤 dort (pas de statut fini, plus de 30 min) ; les deux s'archivent avec leur note. **8 faux « travaille » → 0** ; 4 sessions reconnues interrompues.
- **Surveillance** : Monitor, Bash de fond, CronCreate/CronDelete, ScheduleWakeup, skill `loop`, tâches planifiées et TaskStop sont relevés dans la transcription. Une surveillance vivante (délai pas échu, processus vivant, pas arrêtée) garde la session (« 👁 surveille »). Signal prudent « ⚠ surveillance annoncée, aucune minuterie vivante : à vérifier » quand le rapport annonce une surveillance sans mécanisme vivant : cas réel : une orchestration du 26/10 dont le Monitor était arrêté depuis quatre jours, gardée. Avant : 0 mécanisme relevé.
- **« 0 Mo à rendre » trompeur** : quand les processus à archiver sont fermés, le tableau dit « leur mémoire est déjà rendue (processus fermés) » ; il ajoute la mémoire que tiennent les sessions gardées encore ouvertes et ce que rendrait l'archivage des sessions qui dorment.
- **Nouveau mode `ranger tout --reprise-dans <session>`** : une note de reprise par session de la famille (sauf la courante et celles qui tournent vraiment), une note commune `<jour>-reprise-commune-<titre>-<id8>.md`, et les lignes `Note commune`, `Envoyer à`, `Prêtes à archiver`, `Gardées (tournent)`. Le plan est mis à jour pour `bilan`.
- **Session courante** « (sans titre) », contexte et coût à 0 : repli sur la transcription la plus récente du dossier et sur le dernier événement `custom-title` ; option `--session <id>` ; les entrées du magasin sans `sessionId` sont ignorées. Cas réel : l'orchestratrice retrouvée avec son titre, 427 k de contexte, 16,29 $.
- **Titre du tableau vide** : repli sur le titre de la session courante, puis le nom du dossier.
- **Haiku réécrivait le tableau en liste** : le skill demande de recopier mot pour mot, tableaux compris, et n'ajoute qu'une question ; `liste` finit par la ligne « Question à poser ».
- **Session déjà archivée qui laisse une tâche planifiée** : `notes --avec-archivees` écrit sa note quand même et y ajoute « Ce qui tourne encore sans la session ». Cas réel : une tâche planifiée toutes les heures en semaine, toujours active après l'archivage de la session qui l'avait créée.
- Options d'essai : `--avec-archivees` (reprend les archivées comme ouvertes, plan dans `ranger-essai.json`, aucune note ; `notes <ids> --avec-archivees` écrit pour de vrai les ids donnés), `--maintenant <ISO>`.

## 1.3.0 — 30/10/2026

- **`/orch ranger`** range une orchestration. `outils/ranger.mjs` lit le magasin de sessions de l'app de bureau (titre, parent, archivée, dernier rapport, question en attente), la transcription de chaque session (contexte, coût, plan, commits) et `ps` (mémoire vive de chaque processus `claude`, retrouvé par `CLAUDE_CODE_HOST_SESSION_ID`). Il propose archiver / garder (avec la raison) / relancer, écrit une **note de reprise** par session avant de l'archiver (dans `Projets/<Nom>/Journal/Sessions/` du coffre quand le dépôt y a son `docs/`, sinon `~/.cache/orchestration/notes/`), et `ranger bilan` mesure la mémoire après. Un seul oui pour toute la liste ; jamais une session qui travaille ou attend.
- Commits retrouvés même en `git commit -q` : par le message passé à `-m` dans le journal des dépôts touchés, puis par les empreintes que la session cite. Essai sur 12 sessions finies : 1 à 11 commits chacune, aucune à zéro.
- Mesuré sur ce Mac le 30/10/2026 : 348 sessions dans l'app, 331 non archivées, **22 processus vivants pour 4,47 Go** ; une session finie au repos pèse 140 à 250 Mo (médiane 177) ; les 14 finies gardaient 2,52 Go ; swap 5,9 Go sur 7. Les serveurs MCP ajoutent 63 outils (92 au lieu de 29), 3 800 jetons au premier message et 1,5 s au démarrage (`claude -p`, deux essais avec et sans `--strict-mcp-config`).
- Sur l'orchestration de ce site : 26 sessions, 12 proposées à l'archivage, 886 Mo de processus et 3,0 M jetons de contexte à rendre ; `claude -p "/orch ranger"` : Haiku 5.5 seul, 42 s, 0,24 $.

## 1.2.1 — 30/10/2026

- **`/orch` tourne sur Haiku 5.5 · medium** (`model` et `effort` dans l'en-tête du skill, pour ce tour seulement) et sa sortie est **calculée avant le tour** par `skills/orch/lancer.sh` (injection `` !`…` ``) : le modèle ne lance plus rien, il recopie. Mesuré en session neuve (`claude -p "/orch poids"`) : 6,3 s, Haiku seul, aucun appel d'outil.
- Limite : dans une longue session, passer à Haiku relit toute la conversation sans cache ; le gain en temps est sûr, le gain en coût dépend du poids de la session.

## 1.2.0 — 30/10/2026

- **Automatique** : le hook `hooks/aiguillage.mjs` (UserPromptSubmit) applique le skill dès qu'un message demande de lancer, déléguer ou répartir du travail — plus besoin de dire « orchestre ». Réglé sur les messages des 7 derniers jours : il réagit à 107 sur 915 (≈ 1 sur 9), en écartant les résumés de reprise et les prompts de script.
- **Annonce de chaque lancement**, une ligne dans la conversation : `→ titre — Modèle · effort — parce que …`. Le même hook (PostToolUse sur `Agent`, `Task`, `start_session`) la rappelle aussitôt si elle manque ou si le modèle n'est pas fixé. *(mesuré : annonce faite dans 24 % des orchestrations, 26 % des lancements sans modèle.)*
- **`outils/simuler.mjs`** rejoue chaque réponse facturée avec les mêmes jetons sous deux règles : Opus seulement pour orchestrer (− 135 $), relance à 300 k avec note (63 relances, − 221 $). Du 20 au 29/10 : 1 759 $ → 1 408 $ (− 20 %).
- Banc relu en « tout Opus · medium » contre le choix du skill sur les 11 tâches : 1,06 $ → 0,36 $ (− 66 %), note 0,94 → 0,96, temps 203 s → 137 s (− 33 %) ; 5 tâches sur Haiku, 6 sur Sonnet, 0 sur Opus.

## 1.1.0 — 30/10/2026

- **`/orch`**, le tableau de bord de l'orchestration en cours, lu dans la transcription de la session
  (`outils/etat.mjs`) : sessions lancées (titre, modèle, état, id), agents, poids du contexte en jauge,
  coût, règles du skill tenues ✓ / manquées ✗. Sous-commandes `sessions`, `agents`, `poids`, `cout`,
  `regles`, `bilan [jours]` (le mois de ce Mac face aux mesures de la v1), `conseil`, `accueil`.
  Essai : sur une orchestration du 29/10, 5 sessions retrouvées avec leur id, règles 4/5 (pas de minuterie) ;
  `bilan 30` sur ce Mac en 25 s : 1 145 sessions, 4 720 $, 86 % du coût au-delà de 300 k jetons.
- **Accueil** : `install.sh` finit par une page `~/.cache/orchestration/bienvenue.html` dont le mot et les
  trois conseils sont écrits par Claude (Haiku · medium, un appel) sur les 30 derniers jours du Mac ;
  repli sur un texte fixe sans `claude`. `/orch accueil` la rouvre.
- **Paquet public** (`outils/paquet.sh`) : un zip sans `references/` ni perfs, téléchargeable sur la page
  du site ; installé ainsi, `partager.sh` dépose le fichier de perfs dans `~/Downloads` (pas de dépôt où pousser).

## 1.0.0 — 29/10/2026

Première version partageable. Source des chiffres : `node outils/extraire.mjs --depuis 2026-10-20`
sur le Mac de l’auteur (895 transcriptions, 785 sessions exploitables, 1 757 $ aux prix publics),
résumé dans `perfs/SYNTHESE.md`.

| Constat (20–29/10) | Chiffre | Ce qui change dans le skill |
|---|---|---|
| Demandes d'orchestration sans aucune session lancée | 25 / 45 (8 avec des agents à la place) | § 0 « Agent ou session ? », § 1 diagnostic de départ, `start_session` différé à charger par `ToolSearch` |
| Lancements de session refusés | 30 / 215 (14 %) : 19 sur un tour automatique, 14 cartes avec dossier, 2 Remote Control | § 2 a, tableau des refus et parades : lancer tout le plan dans le tour de l'utilisateur |
| Lancements sans `model` explicite | 26 % | § 3 « jamais de modèle par défaut », exemple d'appel complet |
| Annonce modèle · effort faite | 24 % des orchestrations | § 3 annonce en tableau, avec critère de fin |
| Sessions > 300 000 jetons | 59, dont 20 relancées avec une note ; 76 % du coût total | § 6 inchangé sur le fond, hook rendu autonome |
| Sessions principales Opus · medium | 66 / 785 sessions, 75 % du coût | § 3 garde-fou Opus rappelé avec le chiffre |
| Refus « Concurrent subagent limit reached » | 78 | § 2 c : 20 agents au plus, vagues par script |
| Corrections de l'utilisateur liées à l'orchestration | banc et `caffeinate` oubliés (3), consigne à heure dite oubliée (2), fille qui répète ses tests (1), remarque à transmettre (1) | § 4 brief (arrêt, processus de fond), § 5, § 7 |

Autres changements :
- **Partage avec accord** : l'envoi automatique de fin de session (`perfs/collecter.mjs`, v0) est retiré —
  il poussait sans demander et ne voyait que la moitié des sessions (367 fiches pour 785 sessions).
  Remplacé par `outils/partager.sh` : extraction depuis les transcriptions, aperçu, « Partager » ou rien.
  Noms de projet hachés.
- **Passe mensuelle** : `outils/analyse-mensuelle.sh` (Mac analyste, le 3 du mois) régénère la synthèse
  et propose la version suivante du skill en PR, jamais appliquée sans relecture.
- `hooks/poids-de-session.mjs` ne dépend plus d'un coffre `~/pboard` (il plantait sur un autre Mac).
- `/retour` n'avait servi aucune fois : il devient facultatif ; la mesure automatique le remplace.
- Synthèse GitHub Actions retirée (le jeton n'avait pas le droit `workflow`, elle n'a jamais tourné).

## 0.1 — 20/10/2026

Premier dépôt : skill orchestrateur, `/point`, `/pause`, `/reprise`, `/retour`, hook de fin de session.
