# Journal des versions du skill orchestrateur

## 1.2.1 — 30/10/2026

- **`/orch` tourne sur Haiku 5.5 · medium** (`model` et `effort` dans l'en-tête du skill, pour ce tour seulement) et sa sortie est **calculée avant le tour** par `skills/orch/lancer.sh` (injection `` !`…` ``) : le modèle ne lance plus rien, il recopie. Mesuré en session neuve (`claude -p "/orch poids"`) : 6,3 s, Haiku seul, aucun appel d'outil.
- Limite : dans une longue session, passer à Haiku relit toute la conversation sans cache ; le gain en temps est sûr, le gain en coût dépend du poids de la session.

## 1.2.0 — 30/10/2026

- **Automatique** : le hook `hooks/aiguillage.mjs` (UserPromptSubmit) applique le skill dès qu'un message demande de lancer, déléguer ou répartir du travail — plus besoin de dire « orchestre ». Réglé sur les messages des 7 derniers jours : il réagit à 107 sur 915 (≈ 1 sur 9), en écartant les résumés de reprise et les prompts de script.
- **Annonce de chaque lancement**, une ligne dans la conversation : `→ titre — Modèle · effort — parce que …`. Le même hook (PostToolUse sur `Agent`, `Task`, `start_session`) la rappelle aussitôt si elle manque ou si le modèle n'est pas fixé. *(mesuré : annonce faite dans 24 % des orchestrations, 26 % des lancements sans modèle.)*
- **`outils/simuler.mjs`** rejoue chaque réponse facturée avec les mêmes jetons sous deux règles : Opus seulement pour orchestrer (− 135 $), relance à 300 k avec note (63 relances, − 221 $). Du 20 au 29/10 : 1 759 $ → 1 408 $ (− 20 %).
- Banc relu en « tout Opus · medium » contre le choix du skill sur les 11 tâches : 1,06 $ → 0,36 $ (− 66 %), note 0,94 → 0,96, temps 203 s → 137 s (− 33 %) ; 5 tâches sur Haiku, 6 sur Sonnet, 0 sur Opus.

## 1.1.0 — 30/10/2026

- **`/orch`**, le tableau de bord de l'orchestration en cours, lu dans la transcription de la session
  (`outils/etat.mjs`) : sessions lancées (titre, modèle, état, id), agents, poids du contexte en jauge,
  coût, règles du skill tenues ✓ / manquées ✗. Sous-commandes `sessions`, `agents`, `poids`, `cout`,
  `regles`, `bilan [jours]` (le mois de ce Mac face aux mesures de la v1), `conseil`, `accueil`.
  Essai : sur une orchestration du 29/10, 5 sessions retrouvées avec leur id, règles 4/5 (pas de minuterie) ;
  `bilan 30` sur ce Mac en 25 s : 1 145 sessions, 4 720 $, 86 % du coût au-delà de 300 k jetons.
- **Accueil** : `install.sh` finit par une page `~/.cache/orchestration/bienvenue.html` dont le mot et les
  trois conseils sont écrits par Claude (Haiku · medium, un appel) sur les 30 derniers jours du Mac ;
  repli sur un texte fixe sans `claude`. `/orch accueil` la rouvre.
- **Paquet public** (`outils/paquet.sh`) : un zip sans `references/` ni perfs, téléchargeable sur la page
  du site ; installé ainsi, `partager.sh` dépose le fichier de perfs dans `~/Downloads` (pas de dépôt où pousser).

## 1.0.0 — 29/10/2026

Première version partageable. Source des chiffres : `node outils/extraire.mjs --depuis 2026-10-20`
sur le Mac de l’auteur (895 transcriptions, 785 sessions exploitables, 1 757 $ aux prix publics),
résumé dans `perfs/SYNTHESE.md`.

| Constat (20–29/10) | Chiffre | Ce qui change dans le skill |
|---|---|---|
| Demandes d'orchestration sans aucune session lancée | 25 / 45 (8 avec des agents à la place) | § 0 « Agent ou session ? », § 1 diagnostic de départ, `start_session` différé à charger par `ToolSearch` |
| Lancements de session refusés | 30 / 215 (14 %) : 19 sur un tour automatique, 14 cartes avec dossier, 2 Remote Control | § 2 a, tableau des refus et parades : lancer tout le plan dans le tour de l'utilisateur |
| Lancements sans `model` explicite | 26 % | § 3 « jamais de modèle par défaut », exemple d'appel complet |
| Annonce modèle · effort faite | 24 % des orchestrations | § 3 annonce en tableau, avec critère de fin |
| Sessions > 300 000 jetons | 59, dont 20 relancées avec une note ; 76 % du coût total | § 6 inchangé sur le fond, hook rendu autonome |
| Sessions principales Opus · medium | 66 / 785 sessions, 75 % du coût | § 3 garde-fou Opus rappelé avec le chiffre |
| Refus « Concurrent subagent limit reached » | 78 | § 2 c : 20 agents au plus, vagues par script |
| Corrections de l'utilisateur liées à l'orchestration | banc et `caffeinate` oubliés (3), consigne à heure dite oubliée (2), fille qui répète ses tests (1), remarque à transmettre (1) | § 4 brief (arrêt, processus de fond), § 5, § 7 |

Autres changements :
- **Partage avec accord** : l'envoi automatique de fin de session (`perfs/collecter.mjs`, v0) est retiré —
  il poussait sans demander et ne voyait que la moitié des sessions (367 fiches pour 785 sessions).
  Remplacé par `outils/partager.sh` : extraction depuis les transcriptions, aperçu, « Partager » ou rien.
  Noms de projet hachés.
- **Passe mensuelle** : `outils/analyse-mensuelle.sh` (Mac analyste, le 3 du mois) régénère la synthèse
  et propose la version suivante du skill en PR, jamais appliquée sans relecture.
- `hooks/poids-de-session.mjs` ne dépend plus d'un coffre `~/pboard` (il plantait sur un autre Mac).
- `/retour` n'avait servi aucune fois : il devient facultatif ; la mesure automatique le remplace.
- Synthèse GitHub Actions retirée (le jeton n'avait pas le droit `workflow`, elle n'a jamais tourné).

## 0.1 — 20/10/2026

Premier dépôt : skill orchestrateur, `/point`, `/pause`, `/reprise`, `/retour`, hook de fin de session.
