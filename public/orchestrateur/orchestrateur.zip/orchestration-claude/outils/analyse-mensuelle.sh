#!/bin/bash
# Passe mensuelle d'amélioration (Mac analyste, ex. le Mac mini), lancée par launchd le 3 du mois.
# 1. récupère les perfs partagées par tous les comptes ;
# 2. régénère perfs/SYNTHESE.md ;
# 3. demande à Claude (Opus · medium, sans réseau ni écriture hors du dépôt) de proposer une version
#    suivante du skill sur une branche, avec CHANGELOG et apprentissage ;
# 4. pousse la branche et ouvre une PR : rien n'est appliqué sans relecture humaine.
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
MOIS=$(date +%Y-%m)
JOURNAL=~/.cache/orchestration/analyse-$MOIS.log
mkdir -p ~/.cache/orchestration
exec >>"$JOURNAL" 2>&1
echo "== $(date) analyse $MOIS"

git checkout -q main && git pull -q --rebase
bash outils/rapatrier.sh || echo "rapatriement impossible, synthèse sur les perfs déjà dans le dépôt"
node perfs/synthese.mjs
if ! git diff --quiet perfs/SYNTHESE.md; then git add perfs/SYNTHESE.md && git commit -qm "perfs : synthese de $MOIS" && git push -q; fi

BRANCHE=amelioration-$MOIS
git checkout -q -B "$BRANCHE"
caffeinate -i claude -p "$(cat outils/prompt-amelioration.md)" \
  --model opus --effort medium --permission-mode acceptEdits \
  --allowedTools "Read,Grep,Glob,Edit,Write,Bash(node:*),Bash(git diff:*),Bash(git status:*)" \
  --max-turns 60 > ~/.cache/orchestration/analyse-$MOIS.md

if git diff --quiet && [ -z "$(git status --porcelain)" ]; then
  echo "aucune proposition ce mois-ci"; git checkout -q main; exit 0
fi
git add -A skills apprentissages CHANGELOG.md
git commit -qm "orchestrateur : proposition de $MOIS d apres $(grep -c . perfs/*/historique.jsonl | awk -F: '{s+=$2} END {print s}') sessions"
git push -q -u origin "$BRANCHE"
URL=$(gh pr create --fill --base main --head "$BRANCHE" --body "$(cat ~/.cache/orchestration/analyse-$MOIS.md)" 2>/dev/null || gh pr view "$BRANCHE" --json url -q .url)
git checkout -q main
[ -n "${ORCH_NOTIFIER:-}" ] && "$ORCH_NOTIFIER" "Proposition d'amélioration du skill : $URL" "Orchestration $MOIS" || true
echo "PR : $URL"
