#!/usr/bin/env node
// Les essais hors Claude : un travail confié à GPT (Codex), Gemini, Antigravity… (ou un essai de banc, Claude compris).
// Un essai = une ligne JSON. Ce module lit les trois endroits où ils vivent, les nettoie, les fusionne sans doublon,
// et les compare par type de tâche. Aucun modèle, aucun réseau.
//
// Où ils vivent :
//   1. outils/bancs/intermodele/essais.jsonl      — le banc de mesure (écrit par la session qui mesure) ;
//   2. ~/.cache/orchestration/intermodele/*.jsonl  — le journal d'un script d'appel sur ce Mac (ORCH_INTERMODELE) ;
//   3. perfs/<compte>/intermodele.jsonl            — ce que chaque compte a partagé par GitHub (partager.sh).
//
// Format (tous les champs sauf date et fournisseur sont facultatifs) :
//   date, compte, tache, type, fournisseur, modele, voie (abonnement | api), cout_eur, quota_consomme (0 à 1, part du quota
//   de la période), duree_s, conformite (0 à 1 : a respecté la consigne), qualite (0 à 1), source (étiquette courte).
//
// Usage : node outils/intermodele.mjs lire [--json]
//         node outils/intermodele.mjs partage --compte X [--depuis AAAA-MM-JJ] [--sortie fichier]   (lignes à partager, nettoyées)
//         node outils/intermodele.mjs fusionner cible.jsonl nouveau.jsonl…                          (fusion sans doublon, in situ)
//         node outils/intermodele.mjs comparer
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dossierDonnees } from './donnees.mjs';

const DEPOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Les fournisseurs reconnus (noms d'usage → nom canonique) et leur nom affiché.
const ALIAS = { gpt: 'openai', openai: 'openai', codex: 'openai', chatgpt: 'openai', gemini: 'google', google: 'google', antigravity: 'antigravity',
  claude: 'anthropic', anthropic: 'anthropic' };
export const NOMS = { openai: 'GPT (Codex)', google: 'Gemini', antigravity: 'Antigravity', anthropic: 'Claude' };
export const nomFournisseur = (f) => NOMS[f] || f || '—';
const VOIES = { abonnement: 'abonnement', subscription: 'abonnement', forfait: 'abonnement', api: 'api', cle: 'api' };
export const SEUIL_QUALITE = 0.7, SEUIL_CONFORMITE = 0.5;

// ── Nettoyage : rien de ce qui est privé ne doit passer. Une tâche est une étiquette (« extraction-json »), pas un prompt ;
// on coupe, et on masque ce qui ressemble à un chemin, une clé ou une adresse.
export const assainir = (t, n = 120) => String(t ?? '')
  .replace(/(?:\/Users|\/home|[A-Za-z]:\\Users)[\\/][^\s"')]+/g, '~')
  .replace(/\b(?:sk|pk|key|ghp|gho|xox[a-z]|AIza)[-_A-Za-z0-9]{12,}/g, '[clé masquée]')
  .replace(/[\w.+-]+@[\w-]+\.[\w.-]+/g, '[adresse masquée]')
  .replace(/\s+/g, ' ').trim().slice(0, n);
const nombre = (v, borne) => { if (v === '' || v == null) return null; const x = Number(v); return Number.isFinite(x) && x >= 0 ? (borne ? Math.min(borne, x) : x) : null; };
const note = (v) => { if (v === true) return 1; if (v === false) return 0; const x = nombre(v); return x == null ? null : x > 1 && x <= 10 ? x / 10 : x > 10 ? null : x; };

// Une ligne brute → un essai propre, ou null (ligne illisible, sans date ou sans fournisseur). Seuls les champs du format passent.
export function normaliser(brut, { compte = '', origine = '' } = {}) {
  let o = brut; if (typeof brut === 'string') { try { o = JSON.parse(brut); } catch { return null; } }
  if (!o || typeof o !== 'object') return null;
  const date = Date.parse(o.date); if (!Number.isFinite(date)) return null;
  const fournisseur = ALIAS[String(o.fournisseur || '').toLowerCase().trim()] || assainir(o.fournisseur, 30).toLowerCase();
  if (!fournisseur) return null;
  const e = { date: new Date(date).toISOString(), compte: assainir(o.compte || compte, 40).toLowerCase().replace(/[^a-z0-9-]/g, '-'), tache: assainir(o.tache, 120), type: assainir(o.type, 40).toLowerCase() || 'autre',
    fournisseur, modele: assainir(o.modele, 60), voie: VOIES[String(o.voie || '').toLowerCase()] || '', cout_eur: nombre(o.cout_eur), quota_consomme: nombre(o.quota_consomme, 1),
    duree_s: nombre(o.duree_s), conformite: note(o.conformite), qualite: note(o.qualite), source: assainir(path.basename(String(o.source || '')), 60) };
  // L'identité d'un essai : ce qui le distingue. Deux comptes qui l'enregistrent chacun une fois ne font qu'un (le compte compte).
  e.id = o.id ? assainir(o.id, 40) : crypto.createHash('sha1').update([e.date, e.compte, e.tache, e.type, e.fournisseur, e.modele, e.voie, o.essai ?? ''].join('|')).digest('hex').slice(0, 16);
  if (origine) Object.defineProperty(e, 'origine', { value: origine, enumerable: false });
  return e;
}
const CHAMPS = ['id', 'date', 'compte', 'tache', 'type', 'fournisseur', 'modele', 'voie', 'cout_eur', 'quota_consomme', 'duree_s', 'conformite', 'qualite', 'source'];
export const serialiser = (e) => JSON.stringify(Object.fromEntries(CHAMPS.map((c) => [c, e[c]])));

const lignes = (f) => { try { return fs.readFileSync(f, 'utf8').split('\n').filter(Boolean); } catch { return []; } };
export const compteLocal = (depot = DEPOT) => { try { return fs.readFileSync(path.join(dossierDonnees(depot), 'perfs/.compte'), 'utf8').trim(); } catch { return os.userInfo().username; } };

// ── Les trois sources.
export function sources({ depot = DEPOT, maison = os.homedir() } = {}) {
  const S = [];
  // ORCH_BANC_ESSAIS : remplace le fichier du banc du dépôt (les tests s'isolent ainsi des vraies mesures)
  const banc = (depot === DEPOT && process.env.ORCH_BANC_ESSAIS) || path.join(depot, 'outils/bancs/intermodele/essais.jsonl');
  if (fs.existsSync(banc)) S.push({ fichier: banc, origine: 'banc', compte: '' });
  const journal = process.env.ORCH_INTERMODELE || path.join(maison, '.cache/orchestration/intermodele');
  if (fs.existsSync(journal)) for (const f of fs.readdirSync(journal).sort()) if (f.endsWith('.jsonl')) S.push({ fichier: path.join(journal, f), origine: 'journal', compte: '' });
  const perfs = path.join(dossierDonnees(depot), 'perfs');
  if (fs.existsSync(perfs)) for (const c of fs.readdirSync(perfs).sort()) { const f = path.join(perfs, c, 'intermodele.jsonl'); if (fs.existsSync(f)) S.push({ fichier: f, origine: 'partage', compte: c }); }
  return S;
}

// Fusion sans doublon : par identité ; si deux versions existent, celle qui a le plus de champs renseignés gagne.
const remplis = (e) => CHAMPS.filter((c) => e[c] !== null && e[c] !== '' && e[c] !== undefined).length;
export function fusionner(...listes) {
  const m = new Map();
  for (const L of listes) for (const e of L) { const p = m.get(e.id); if (!p || remplis(e) > remplis(p)) m.set(e.id, e); }
  return [...m.values()].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
}

export function lireEssais(opts = {}) {
  const compteDefaut = opts.compte ?? compteLocal(opts.depot);
  // Une ligne sans compte : celle d'un fichier partagé garde le compte de son dossier ; celle du banc (dans le dépôt, commune aux deux
  // comptes) n'appartient à aucun compte précis ; celle du journal de ce Mac est de ce compte-ci.
  const L = sources(opts).filter((s) => !opts.origines || opts.origines.includes(s.origine))
    .map(({ fichier, origine, compte }) => lignes(fichier).map((l) => normaliser(l, { compte: compte || (origine === 'banc' ? 'banc' : compteDefaut), origine })).filter(Boolean));
  return fusionner(...L);
}

// L'empreinte des fichiers sources : tailles et dates, pour que la page ne recalcule que si l'un a bougé.
export const empreinteEssais = (opts = {}) => sources(opts).map(({ fichier }) => { try { const s = fs.statSync(fichier); return `${fichier}:${s.size}:${Math.floor(s.mtimeMs)}`; } catch { return fichier; } }).join('|');

// Ce que `partager.sh` emporte : le journal de CE Mac, sous le nom de ce compte (le banc et les autres comptes sont déjà dans le dépôt).
export function pourPartage({ compte, depuis = '2000-01-01', ...opts } = {}) {
  const c = compte || compteLocal(opts.depot);
  return lireEssais({ ...opts, compte: c, origines: ['journal'] }).filter((e) => e.date.slice(0, 10) >= depuis).map((e) => ({ ...e, compte: c }));
}

// Fusionne des fichiers de lignes dans une cible, sans doublon ; rend { avant, apres, ajoutes }.
export function fusionnerFichiers(cible, nouveaux, { compte = '' } = {}) {
  const lire = (f, c) => lignes(f).map((l) => normaliser(l, { compte: c })).filter(Boolean);
  const avant = lire(cible, compte); const tous = fusionner(avant, ...nouveaux.map((f) => lire(f, compte)));
  fs.mkdirSync(path.dirname(cible), { recursive: true });
  fs.writeFileSync(cible, tous.map(serialiser).join('\n') + (tous.length ? '\n' : ''));
  return { avant: avant.length, apres: tous.length, ajoutes: tous.length - fusionner(avant).length };
}

// ── La comparaison : par type de tâche, une ligne par fournisseur · modèle · voie.
export const reussi = (e) => (e.qualite == null || e.qualite >= SEUIL_QUALITE) && (e.conformite == null || e.conformite >= SEUIL_CONFORMITE) && (e.qualite != null || e.conformite != null);
const moy = (L) => { const v = L.filter((x) => x != null); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null; };
const med = (L) => { const v = L.filter((x) => x != null).sort((a, b) => a - b); return v.length ? (v.length % 2 ? v[(v.length - 1) / 2] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2) : null; };
export function comparer(essais) {
  const types = new Map();
  for (const e of essais) { const t = types.get(e.type) || types.set(e.type, new Map()).get(e.type); const k = `${e.fournisseur}|${e.modele}|${e.voie}`; (t.get(k) || t.set(k, []).get(k)).push(e); }
  const comptes = [...new Set(essais.map((e) => e.compte))].sort();
  return { comptes, total: essais.length,
    types: [...types].map(([type, M]) => ({ type, n: [...M.values()].reduce((a, L) => a + L.length, 0),
      lignes: [...M.values()].map((L) => { const [e0] = L; const jugés = L.filter((e) => e.qualite != null || e.conformite != null);
        return { fournisseur: e0.fournisseur, modele: e0.modele, voie: e0.voie, n: L.length, coutMoyen: moy(L.map((e) => e.cout_eur)), quotaMoyen: moy(L.map((e) => e.quota_consomme)), dureeMediane: med(L.map((e) => e.duree_s)),
          qualiteMoyenne: moy(L.map((e) => e.qualite)), conformiteMoyenne: moy(L.map((e) => e.conformite)), jugés: jugés.length, reussis: jugés.filter(reussi).length,
          parCompte: Object.fromEntries(comptes.map((c) => { const Lc = L.filter((e) => e.compte === c); const J = Lc.filter((e) => e.qualite != null || e.conformite != null); return [c, { n: Lc.length, jugés: J.length, reussis: J.filter(reussi).length, coutMoyen: moy(Lc.map((e) => e.cout_eur)), dureeMediane: med(Lc.map((e) => e.duree_s)) }]; }).filter(([, v]) => v.n)) }; })
        .sort((a, b) => (b.jugés ? b.reussis / b.jugés : -1) - (a.jugés ? a.reussis / a.jugés : -1) || (a.coutMoyen ?? 1e9) - (b.coutMoyen ?? 1e9)) }))
      .sort((a, b) => b.n - a.n) };
}

// Ce que la page du bureau reçoit : les essais de la fenêtre [de, a] (hors Claude : fournisseurs autres qu'anthropic), et le total.
export function pourBureau({ de = 0, a = Date.now(), ...opts } = {}) {
  const tous = lireEssais(opts); const hors = tous.filter((e) => e.fournisseur !== 'anthropic');
  const dedans = hors.filter((e) => { const t = Date.parse(e.date); return t >= de && t <= a; });
  return { essais: dedans.map((e) => ({ ...e, cle: `x:${e.id}`, genre: 'essai', titre: e.tache || e.type, nomFournisseur: nomFournisseur(e.fournisseur), exemple: /^exemple/i.test(e.source),
    etat: (e.qualite != null || e.conformite != null) && !reussi(e) ? 'à relire' : 'finie', debut: e.date, fin: new Date(Date.parse(e.date) + (e.duree_s || 0) * 1000).toISOString() })),
    total: tous.length, horsClaude: hors.length, dehors: hors.length - dedans.length, comptes: [...new Set(tous.map((e) => e.compte))].sort(),
    parFournisseur: hors.reduce((o, e) => { o[e.fournisseur] = (o[e.fournisseur] || 0) + 1; return o; }, {}) };
}

// ── Ligne de commande
if (process.argv[1] && fileURLToPath(import.meta.url) === fs.realpathSync(process.argv[1])) {
  const a = process.argv.slice(2); const opt = (n) => { const i = a.indexOf(n); return i >= 0 ? a.splice(i, 2)[1] : null; };
  const compte = opt('--compte') || ''; const depuis = opt('--depuis') || '2000-01-01'; const sortie = opt('--sortie');
  const [cmd = 'lire', ...reste] = a;
  if (cmd === 'partage') { const L = pourPartage({ compte: compte || undefined, depuis }); const t = L.map(serialiser).join('\n') + (L.length ? '\n' : ''); if (sortie) fs.writeFileSync(sortie, t); else process.stdout.write(t); }
  else if (cmd === 'fusionner') { const [cible, ...nv] = reste.filter((x) => !x.startsWith('--')); console.log(JSON.stringify(fusionnerFichiers(cible, nv, { compte }))); }
  else if (cmd === 'comparer') console.log(JSON.stringify(comparer(lireEssais()), null, 1));
  else console.log(a.includes('--json') ? JSON.stringify(lireEssais()) : `${lireEssais().length} essais`);
}
