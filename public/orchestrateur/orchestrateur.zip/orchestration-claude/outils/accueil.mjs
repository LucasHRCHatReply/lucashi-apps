#!/usr/bin/env node
// Le message d'accueil, à l'installation (et par /orch accueil).
// 1. relit les 30 derniers jours de ce Mac (outils/etat.mjs bilan --json) ;
// 2. demande à Claude (Haiku · medium, un seul appel, ≈ 0,01 $) un mot d'accueil écrit sur ces chiffres ;
// 3. écrit ~/.cache/orchestration/bienvenue.html et l'ouvre.
// Sans Claude dans le PATH, ou s'il ne répond pas en 90 s, un mot par défaut est utilisé.
//
// Usage : node outils/accueil.mjs [--texte] [--sans-claude] [--sans-ouvrir]
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const DEPOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const a = process.argv.slice(2);
const PRENOM = (() => { try { return fs.readFileSync(path.join(DEPOT, 'perfs/.compte'), 'utf8').trim(); } catch { return os.userInfo().username; } })();
const VERSION = (fs.readFileSync(path.join(DEPOT, 'skills/orchestrateur/SKILL.md'), 'utf8').match(/^version:\s*(.+)$/m) || [])[1] || '?';

process.stderr.write('Lecture de vos 30 derniers jours de Claude Code…\n');
let b;
try { b = JSON.parse(execFileSync(process.execPath, [path.join(DEPOT, 'outils/etat.mjs'), 'bilan', '30', '--json'], { encoding: 'utf8', maxBuffer: 1e7 })); }
catch { b = { n: 0, tot: 0, parModele: {}, lourdes: 0, relancees: 0, partLourdes: 0, orch: 0, orchSansSession: 0, lancees: 0, sansModele: 0, refus: 0, agents: 0, annonces: 0 }; }

const pct = (x, n) => (n ? Math.round((100 * x) / n) : null);
const euros = (n) => `${Math.round(n).toLocaleString('fr-FR')} $`;
const modeles = Object.entries(b.parModele).filter(([m]) => m !== 'autre').sort((x, y) => y[1].c - x[1].c);
const dominant = modeles[0]?.[0];
const chiffres = {
  sessions: b.n, cout: Math.round(b.tot), lourdes: b.lourdes, relancees: b.relancees, part_cout_lourdes: pct(b.partLourdes, 1),
  orchestrations: b.orch, orchestrations_sans_session: b.orchSansSession, lancements: b.lancees,
  lancements_sans_modele_pct: pct(b.sansModele, b.lancees), agents: b.agents, modele_le_plus_cher: dominant,
  part_du_modele_le_plus_cher: dominant ? pct(b.parModele[dominant].c, b.tot) : null,
};

if (a.includes('--texte')) {
  console.log(`Prénom : ${PRENOM} · skill v${VERSION}\nChiffres des 30 derniers jours (prix publics) :\n${JSON.stringify(chiffres, null, 1)}`);
  process.exit(0);
}

// ── Le mot de Claude
let mot = null;
if (!a.includes('--sans-claude') && spawnSync('sh', ['-c', 'command -v claude']).status === 0) {
  process.stderr.write('Claude écrit votre mot d’accueil…\n');
  const prompt = `Tu écris le mot d'accueil de quelqu'un qui vient d'installer le skill « orchestrateur » pour Claude Code (v${VERSION}).
Le skill fait d'une session Claude une chef d'orchestre : elle découpe, lance de vraies sessions avec le modèle le moins cher qui suffit, suit, relance les sessions trop lourdes, s'arrête au résultat.
Voici les chiffres réels de ses 30 derniers jours sur ce Mac (null = rien de mesuré) : ${JSON.stringify(chiffres)}.
Réponds UNIQUEMENT par un objet JSON : {"titre": "...", "mot": "...", "conseils": ["...", "...", "..."]}
- titre : 3 à 7 mots, chaleureux, s'adresse à ${PRENOM} par son prénom.
- mot : 2 ou 3 phrases, tutoiement, ton complice et drôle sans en faire trop ; cite un ou deux de ses chiffres tels quels.
- conseils : trois conseils concrets tirés de SES chiffres (ex. part du coût au-delà de 300 k jetons → relancer avec une note ; orchestrations sans session → dire « lance des sessions » ; modèle cher dominant → Sonnet par défaut pour les sessions filles). 20 mots max chacun.
N'invente aucun chiffre. Français.`;
  const r = spawnSync('claude', ['-p', prompt, '--model', 'claude-haiku-5-5', '--effort', 'medium', '--output-format', 'text', '--tools', ''], { encoding: 'utf8', timeout: 90000 });
  try { const t = r.stdout || ''; mot = JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1)); } catch { mot = null; }
}
mot ??= {
  titre: `Bienvenue dans l'orchestre, ${PRENOM}`,
  mot: b.n ? `${b.n} sessions ce mois-ci : de quoi former un bel orchestre. À partir de maintenant, une session dirige, les autres jouent, et chacune reçoit le modèle le moins cher qui suffit.` : 'Votre première orchestration commence ici : une session dirige, les autres jouent, et chacune reçoit le modèle le moins cher qui suffit.',
  conseils: ['Dites « lance des sessions » : le skill charge l’outil de session avant tout.', 'Tapez /orch pendant un chantier pour voir qui travaille et ce que ça coûte.', 'Au-delà de 300 000 jetons, une note de reprise et une session neuve coûtent moins.'],
};

// ── La page
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const COUL = { opus: '#c2410c', sonnet: '#7c3aed', haiku: '#0891b2', fable: '#be185d' };
const NOM = { opus: 'Opus', sonnet: 'Sonnet', haiku: 'Haiku', fable: 'Fable' };
const barres = modeles.map(([m, v]) => `<div class="bar"><span>${NOM[m] || m}</span><i style="--w:${Math.max(1, pct(v.c, b.tot) || 0)}%;--bc:${COUL[m] || '#888'}"></i><b>${pct(v.c, b.tot) ?? 0} %</b><small>${v.n} sessions · ${euros(v.c)}</small></div>`).join('');
const carte = (n, l, aide) => `<div class="kpi" title="${esc(aide)}"><b>${n}</b><span>${l}</span></div>`;
const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bienvenue — Orchestrateur</title><style>
:root{--f:#0b0b12;--t:#f4f4f8;--m:#a1a1b5;--c:#16161f;--l:#262635;--a:#f59e0b}
@media (prefers-color-scheme:light){:root{--f:#f7f7fb;--t:#15151c;--m:#5c5c70;--c:#fff;--l:#e4e4ee}}
*{box-sizing:border-box}body{margin:0;background:var(--f);color:var(--t);font:16px/1.55 -apple-system,BlinkMacSystemFont,"SF Pro Text",system-ui,sans-serif}
.w{max-width:880px;margin:0 auto;padding:56px 20px 80px}
.hero{text-align:center;margin-bottom:40px}.baton{font-size:64px;animation:b 2.4s ease-in-out infinite;display:inline-block;transform-origin:20% 80%}
@keyframes b{0%,100%{transform:rotate(-12deg)}50%{transform:rotate(14deg)}}
h1{font-size:clamp(32px,6vw,52px);line-height:1.05;letter-spacing:-.03em;margin:.2em 0}
.mot{font-size:20px;color:var(--m);max-width:640px;margin:0 auto}.sig{margin-top:10px;font-size:13px;color:var(--m)}
h2{font-size:24px;letter-spacing:-.02em;margin:48px 0 14px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.kpi{background:var(--c);border:1px solid var(--l);border-radius:18px;padding:18px}.kpi b{display:block;font-size:34px;letter-spacing:-.03em}.kpi span{color:var(--m);font-size:14px}
.bar{display:grid;grid-template-columns:70px 1fr 50px;gap:10px;align-items:center;margin:8px 0}.bar i{height:14px;border-radius:7px;background:var(--l);position:relative;overflow:hidden}
.bar i:after{content:"";position:absolute;inset:0;width:var(--w);background:var(--bc);border-radius:7px;animation:g 1.2s ease-out}
.bar small{grid-column:2/4;color:var(--m);font-size:12px;margin-top:-6px}@keyframes g{from{width:0}}
.conseils{display:grid;gap:10px;counter-reset:c}.conseils div{background:var(--c);border:1px solid var(--l);border-radius:16px;padding:14px 16px 14px 54px;position:relative}
.conseils div:before{counter-increment:c;content:counter(c);position:absolute;left:16px;top:13px;width:26px;height:26px;border-radius:50%;background:var(--a);color:#000;font-weight:700;display:grid;place-items:center;font-size:14px}
.cmds{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}.cmd{background:var(--c);border:1px solid var(--l);border-radius:14px;padding:12px 14px}
.cmd code{font:600 15px ui-monospace,Menlo,monospace;color:var(--a)}.cmd p{margin:4px 0 0;color:var(--m);font-size:14px}
.flow{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.flow span{background:var(--c);border:1px solid var(--l);border-radius:999px;padding:8px 14px;font-size:14px}.flow em{color:var(--m);font-style:normal}
footer{margin-top:56px;color:var(--m);font-size:13px;text-align:center}
</style></head><body><div class="w">
<div class="hero"><div class="baton">🪄</div><h1>${esc(mot.titre)}</h1><p class="mot">${esc(mot.mot)}</p><p class="sig">— écrit par Claude pour vous, sur vos chiffres · skill orchestrateur v${esc(VERSION)}</p></div>
<h2>Vos 30 derniers jours</h2>
<div class="kpis">${carte(b.n, 'sessions Claude Code', 'Conversations de ~/.claude/projects modifiées ces 30 jours')}${carte(euros(b.tot), 'aux prix publics', 'Recalculé depuis les jetons ; pas une facture')}${carte(b.lancees, 'sessions lancées', 'Appels start_session')}${carte(b.agents, 'agents', 'Appels Agent')}${carte(b.lourdes, 'sessions > 300 k jetons', `dont ${b.relancees} relancées avec une note`)}${carte(`${pct(b.partLourdes, 1) ?? 0} %`, 'du coût au-delà de 300 k', 'Ce que la relance avec note de reprise fait économiser')}</div>
${barres ? `<h2>Où part le budget</h2>${barres}` : ''}
<h2>Les conseils de Claude, d'après vos chiffres</h2><div class="conseils">${mot.conseils.map((c) => `<div>${esc(c)}</div>`).join('')}</div>
<h2>Ce que fait l'orchestrateur</h2>
<div class="flow"><span>🎯 découpe le chantier</span><em>→</em><span>📋 annonce modèle · effort</span><em>→</em><span>🚀 lance de vraies sessions</span><em>→</em><span>⏱ point toutes les 5 min</span><em>→</em><span>🔁 relance à 300 k jetons</span><em>→</em><span>✅ s'arrête au résultat</span></div>
<h2>Les commandes à essayer</h2>
<div class="cmds">
<div class="cmd"><code>orchestre ce chantier : …</code><p>Démarre une orchestration (ou <code>/orchestrateur</code>).</p></div>
<div class="cmd"><code>/orch</code><p>Le tableau de bord : sessions, agents, poids, coût, règles tenues.</p></div>
<div class="cmd"><code>/orch sessions</code><p>Chaque session lancée, son modèle, son état.</p></div>
<div class="cmd"><code>/orch poids</code><p>La jauge du contexte, et quand relancer.</p></div>
<div class="cmd"><code>/orch conseil</code><p>Quel modèle pour quel travail, mesures à l'appui.</p></div>
<div class="cmd"><code>/orch bilan</code><p>Votre mois comparé aux mesures du skill.</p></div>
<div class="cmd"><code>/point 5</code><p>Un point d'avancement toutes les 5 minutes.</p></div>
<div class="cmd"><code>/pause</code> · <code>/reprise</code><p>Arrêter proprement, reprendre en un mot.</p></div>
</div>
<footer>Le 1er du mois, une fenêtre vous proposera de partager ces chiffres (jamais vos messages) pour améliorer le skill. Rien ne part sans « Partager ».<br>Rouvrir cette page : <code>/orch accueil</code></footer>
</div></body></html>`;
const sortie = path.join(os.homedir(), '.cache/orchestration/bienvenue.html');
fs.mkdirSync(path.dirname(sortie), { recursive: true });
fs.writeFileSync(sortie, html);
console.log(`Page d'accueil : ${sortie}`);
if (!a.includes('--sans-ouvrir')) spawnSync('open', [sortie]);
