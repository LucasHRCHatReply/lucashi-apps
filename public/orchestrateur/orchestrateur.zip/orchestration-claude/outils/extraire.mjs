#!/usr/bin/env node
// Relit les transcriptions Claude Code de ce Mac (~/.claude/projects) et en tire, par session,
// le comportement d'orchestration : sessions lancées, agents, modèle · effort, annonces, échecs
// d'outils, corrections de l'utilisateur, poids du contexte, coût.
//
// Deux sorties :
//   perfs/<compte>/historique.jsonl   partageable : chiffres et noms d'outils seulement, aucun texte
//   .local/extraits-<compte>.jsonl    jamais commité : courts extraits des corrections, pour l'analyse locale
//
// Usage : node outils/extraire.mjs [--depuis 2026-10-20] [--compte nom] [--projets-en-clair] [--sortie fichier]
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const DEPOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const arg = (n, d) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : d; };
const DEPUIS = arg('--depuis', '2026-10-20');
const COMPTE = arg('--compte', (() => { try { return fs.readFileSync(path.join(DEPOT, 'perfs/.compte'), 'utf8').trim(); } catch { return os.userInfo().username; } })());
const RACINE = path.join(os.homedir(), '.claude/projects');
const LIGNE_MAX = 400 * 1024;
// Un nom de dossier peut nommer un client : il part haché, sauf --projets-en-clair.
const EN_CLAIR = process.argv.includes('--projets-en-clair');
const anonyme = p => EN_CLAIR ? p : 'p-' + crypto.createHash('sha1').update(COMPTE + p).digest('hex').slice(0, 6);

export const PRIX = { haiku: [0.10, 0.50, 0.1], sonnet: [2, 10, 0.05], opus: [4, 20, 0.05], fable: [10, 50, 0.05] };
export const famille = (m = '') => Object.keys(PRIX).find(k => m.includes(k)) || 'autre';
export const cout = (f, u) => { const p = PRIX[f]; if (!p) return 0;
  return ((u.input_tokens || 0) * p[0] + (u.cache_creation_input_tokens || 0) * p[0] * 1.25
    + (u.cache_read_input_tokens || 0) * p[0] * p[2] + (u.output_tokens || 0) * p[1]) / 1e6; };

// Une correction : l'utilisateur dit que ce qui vient d'être fait n'est pas ce qu'il voulait.
const CORRECTION = /\b(non[ ,.!]|pas (?:ça|ca|comme ça)|j'(?:ai|avais) (?:dit|demandé)|pourquoi (?:tu|t'as|as-tu)|t'as (?:pas|oublié)|tu as oublié|ça (?:marche|fonctionne) (?:pas|toujours pas)|c'est (?:faux|pas bon)|refais|arr[eê]te|encore une fois|toujours pas)/i;
// Une annonce conforme : « nom — modèle · effort — raison »
const ANNONCE = /(haiku|sonnet|opus|fable)(?:[\s-]*\d(?:[.,]\d)?)?\s*[·•\/,(]\s*(?:effort\s*)?(low|medium|high|xhigh|max)\b/i;
const ORCH_MOT = /orchestr|prompt master|lance (?:des|une|les) sessions?|répartis|en parall[eè]le|sessions? filles?/i;

function texteUtilisateur(m) {
  const c = Array.isArray(m.content) ? m.content : [{ type: 'text', text: String(m.content || '') }];
  return c.filter(x => x.type === 'text' && x.text && !/^\s*<(?!pasted)/.test(x.text)).map(x => x.text).join('\n');
}

export async function lire(fichier, onEv) {
  const rl = readline.createInterface({ input: fs.createReadStream(fichier), crlfDelay: Infinity });
  for await (const l of rl) { if (!l || l.length > LIGNE_MAX) continue; try { onEv(JSON.parse(l)); } catch {} }
}

export async function analyserSession(fichier, depuis = DEPUIS) {
  const s = { debut: null, fin: null, tours: 0, cout: 0, ctxMax: 0, tours300k: 0, modeles: {}, efforts: {},
    humains: 0, corrections: 0, demandeOrch: 0, annonces: 0, textesAssistant: 0,
    sessions: [], sessionsRefusees: 0, handoffs: 0, agents: [], workflows: 0, toolsearchSession: 0,
    sendMessage: 0, minuteries: 0, notifs: 0, notesReprise: 0, skills: new Set(), erreursOutils: {}, outils: {} };
  const extraits = [];
  const vus = new Set(); const appel = new Map();
  let projet = '';
  await lire(fichier, ev => {
    if (ev.timestamp) { if (ev.timestamp < depuis && !s.debut) return; s.debut ??= ev.timestamp; s.fin = ev.timestamp; }
    if (ev.cwd && !projet) projet = path.basename(ev.cwd);
    if (ev.effort) s.efforts[ev.effort] = (s.efforts[ev.effort] || 0) + 1;
    const m = ev.message; if (!m) return;
    if (ev.type === 'user') {
      for (const c of Array.isArray(m.content) ? m.content : []) {
        if (c.type === 'tool_result' && c.is_error) {
          const n = appel.get(c.tool_use_id) || '?'; s.erreursOutils[n] = (s.erreursOutils[n] || 0) + 1;
          if (/start_session$/.test(n)) s.sessionsRefusees++;
        }
      }
      const t = texteUtilisateur(m);
      if (t && !ev.isMeta && !ev.isSidechain) {
        s.humains++;
        if (ORCH_MOT.test(t)) s.demandeOrch++;
        if (CORRECTION.test(t.slice(0, 600))) { s.corrections++; extraits.push(t.slice(0, 280).replace(/\s+/g, ' ')); }
      }
      return;
    }
    if (ev.type !== 'assistant') return;
    for (const c of Array.isArray(m.content) ? m.content : []) {
      if (c.type === 'text' && c.text) { s.textesAssistant++; if (ANNONCE.test(c.text)) s.annonces++; }
      if (c.type !== 'tool_use') continue;
      appel.set(c.id, c.name);
      s.outils[c.name] = (s.outils[c.name] || 0) + 1;
      const i = c.input || {};
      if (/start_session$/.test(c.name)) s.sessions.push({ initiation: i.initiation || 'n/a', contexte: i.context || 'n/a', modele: i.model || 'défaut', worktree: i.use_worktree ?? 'n/a' });
      else if (/hand_off_to_session$/.test(c.name)) s.handoffs++;
      else if (c.name === 'Agent' || c.name === 'Task') s.agents.push({ type: i.subagent_type || 'general-purpose', modele: i.model || 'hérité', effort: i.effort || 'défaut' });
      else if (c.name === 'Workflow') s.workflows++;
      else if (c.name === 'ToolSearch' && /start_session|session/.test(i.query || '')) s.toolsearchSession++;
      else if (c.name === 'SendMessage' || /send_message$/.test(c.name)) s.sendMessage++;
      else if (/CronCreate|ScheduleWakeup|Monitor/.test(c.name)) s.minuteries++;
      else if (c.name === 'Bash' && /notifier\.sh|ntfy/.test(i.command || '')) s.notifs++;
      else if ((c.name === 'Write' || c.name === 'Edit') && /reprise|passation/i.test(i.file_path || '')) s.notesReprise++;
      else if (c.name === 'Skill' && i.skill) s.skills.add(i.skill);
    }
    if (!m.usage || (m.id && vus.has(m.id))) return;
    if (m.id) vus.add(m.id);
    const f = famille(m.model); const u = m.usage;
    s.tours++; s.modeles[f] = (s.modeles[f] || 0) + 1; s.cout += cout(f, u);
    const ctx = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    s.ctxMax = Math.max(s.ctxMax, ctx); if (ctx > 300000) s.tours300k++;
  });
  // Les agents ont leurs propres transcriptions : on ajoute leur coût et leur modèle réel.
  const dossier = path.join(fichier.replace(/\.jsonl$/, ''), 'subagents');
  const agentsReels = {}; let coutAgents = 0;
  if (fs.existsSync(dossier)) for (const f of fs.readdirSync(dossier)) if (f.endsWith('.jsonl')) {
    const v = new Set();
    await lire(path.join(dossier, f), ev => { const m = ev.message; if (ev.type !== 'assistant' || !m?.usage || v.has(m.id)) return; v.add(m.id);
      const fa = famille(m.model); agentsReels[fa] = (agentsReels[fa] || 0) + 1; coutAgents += cout(fa, m.usage); });
  }
  return { s, extraits, projet, agentsReels, coutAgents };
}

// Lancé directement (et non importé par etat.mjs ou accueil.mjs) : extraction complète.
if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
const fichiers = [];
for (const d of fs.readdirSync(RACINE)) {
  const p = path.join(RACINE, d); if (!fs.statSync(p).isDirectory()) continue;
  for (const f of fs.readdirSync(p)) if (f.endsWith('.jsonl')) {
    const fp = path.join(p, f); if (fs.statSync(fp).mtime.toISOString().slice(0, 10) >= DEPUIS) fichiers.push(fp);
  }
}
const sortie = arg('--sortie', path.join(DEPOT, 'perfs', COMPTE, 'historique.jsonl'));
const local = path.join(DEPOT, '.local', `extraits-${COMPTE}.jsonl`);
fs.mkdirSync(path.dirname(sortie), { recursive: true }); fs.mkdirSync(path.dirname(local), { recursive: true });
const out = fs.createWriteStream(sortie); const loc = fs.createWriteStream(local);
let n = 0;
for (const f of fichiers) {
  const { s, extraits, projet, agentsReels, coutAgents } = await analyserSession(f);
  n++; if (n % 100 === 0) process.stderr.write(`${n}/${fichiers.length}\n`);
  if (!s.debut || !s.tours) continue;
  const id = path.basename(f, '.jsonl').slice(0, 8);
  const top = o => Object.entries(o).sort((a, b) => b[1] - a[1])[0]?.[0] || 'n/a';
  const fiche = { v: 2, compte: COMPTE, session: id, projet: anonyme(projet), debut: s.debut, fin: s.fin,
    duree_min: Math.round((new Date(s.fin) - new Date(s.debut)) / 60000),
    modele: top(s.modeles), effort: top(s.efforts), tours: s.tours,
    cout: +(s.cout + coutAgents).toFixed(2), cout_agents: +coutAgents.toFixed(2),
    contexte_max: s.ctxMax, tours_au_dela_300k: s.tours300k,
    messages_humains: s.humains, corrections: s.corrections, demandes_orchestration: s.demandeOrch,
    textes: s.textesAssistant, annonces_modele_effort: s.annonces,
    sessions_lancees: s.sessions, sessions_refusees: s.sessionsRefusees, handoffs: s.handoffs,
    toolsearch_session: s.toolsearchSession, agents: s.agents, agents_reels: agentsReels,
    workflows: s.workflows, messages_aux_sessions: s.sendMessage, minuteries: s.minuteries,
    notifications: s.notifs, notes_reprise: s.notesReprise, skills: [...s.skills],
    erreurs_outils: s.erreursOutils,
    outils: Object.fromEntries(Object.entries(s.outils).sort((a, b) => b[1] - a[1]).slice(0, 15)) };
  out.write(JSON.stringify(fiche) + '\n');
  for (const e of extraits) loc.write(JSON.stringify({ session: id, projet, extrait: e }) + '\n');
}
out.end(); loc.end();
console.log(`${fichiers.length} transcriptions lues → ${sortie}`);
}
