Tu fais la passe mensuelle d'amélioration du skill `skills/orchestrateur/SKILL.md` de ce dépôt.

Lis, dans cet ordre : `perfs/SYNTHESE.md`, `CHANGELOG.md`, `skills/orchestrateur/SKILL.md`,
puis les fiches `perfs/*/historique.jsonl` du mois écoulé (une ligne JSON par session ; calcule avec
`node -e`, ne lis pas tout à la main) et `perfs/*/retours.jsonl` s'il existe.

But : trouver ce qui, ce mois-ci, a coûté cher ou échoué, et proposer la plus petite modification du skill
qui l'aurait évité. Questions à se poser, chiffres à l'appui :
- Quelle part des demandes d'orchestration n'a lancé aucune session ? Pourquoi (refus, agents à la place) ?
- Quels outils échouent le plus, avec quel message, et le skill dit-il quoi faire ?
- Quel modèle · effort a coûté le plus pour quel résultat ? Un cran en dessous aurait-il suffi ?
- Combien de sessions dépassent 300 000 jetons sans note de reprise, et quelle part du coût ?
- L'annonce modèle · effort est-elle faite ? Les lancements ont-ils un modèle explicite ?
- Un compte se comporte-t-il très différemment d'un autre ? Qu'est-ce que l'autre fait mieux ?

Ce que tu écris (et rien d'autre) :
1. `skills/orchestrateur/SKILL.md` : les modifications, chacune marquée *(mesuré : …)* avec le chiffre ;
   monte `version:` (correctif → 1.0.x, règle nouvelle ou changée → 1.x.0). Garde le fichier sous 220 lignes.
2. `CHANGELOG.md` : une entrée datée en tête — ce qui change, le chiffre qui le justifie, sa source.
3. `apprentissages/<AAAA-MM-JJ>-<conclusion-en-mots>.md` (10 lignes au plus) si une leçon vaut hors de ce skill.

Règles : ne change rien qui ne soit pas justifié par un chiffre d'au moins 3 cas ; un chiffre non
mesurable s'écrit `n/a` ; aucun nom de client, de personne ou d'URL interne ; ton direct et impersonnel.
S'il n'y a rien à changer, ne modifie aucun fichier.

Ta réponse finale (elle devient la description de la PR) : 10 lignes au plus — les constats chiffrés,
les modifications proposées, ce que la relecture doit vérifier.
