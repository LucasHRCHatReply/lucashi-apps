#!/bin/bash
# Construit le paquet public du skill : un zip sans références personnelles ni données de perfs.
# Usage : outils/paquet.sh [dossier-de-sortie]   (défaut : ~/lucashi-apps/public/orchestrateur)
set -euo pipefail
cd "$(dirname "$0")/.."
SORTIE=${1:-$HOME/lucashi-apps/public/orchestrateur}
V=$(sed -n 's/^version: *//p' skills/orchestrateur/SKILL.md | head -1)
T=$(mktemp -d); D=$T/orchestration-claude
mkdir -p "$D/perfs"
# outils/tests/ rejoue un cas réel (noms de client, chemins du Mac) : il reste dans le dépôt privé, hors du zip.
git ls-files | grep -vE '^(perfs/|skills/orchestrateur/references/|apprentissages/|outils/tests/|\.github/)' | while read -r f; do mkdir -p "$D/$(dirname "$f")"; cp -p "$f" "$D/$f"; done
for f in outils/etat.mjs outils/ranger.mjs outils/accueil.mjs outils/paquet.sh skills/orch/SKILL.md; do mkdir -p "$D/$(dirname "$f")"; cp -p "$f" "$D/$f"; done
echo "$V" > "$D/VERSION"
# Garde-fou : aucun nom de client, aucun chemin de machine, aucun compte dans le paquet.
if grep -rIniE 's[k]olae|kord[i]s|wiz[a]rd|/Us[e]rs/|lucas-rep[l]y' "$D" | grep -v 'paquet.sh'; then echo "REFUS : donnée privée dans le paquet"; exit 1; fi
mkdir -p "$SORTIE"; rm -f "$SORTIE/orchestrateur.zip"
(cd "$T" && zip -qr -X "$SORTIE/orchestrateur.zip" orchestration-claude)
echo "$SORTIE/orchestrateur.zip — v$V, $(unzip -l "$SORTIE/orchestrateur.zip" | tail -1 | awk '{print $2}') fichiers"
rm -rf "$T"
