#!/bin/bash
# Construit le paquet public du skill : un zip sans références personnelles ni données de perfs.
# Usage : outils/paquet.sh [dossier-de-sortie]   (défaut : ~/lucashi-apps/public/orchestrateur)
set -euo pipefail
cd "$(dirname "$0")/.."
garde_fou() {
  local D=$1
  # Garde-fou : aucun nom de client, aucun chemin de machine, aucun compte, aucun prénom ni identifiant personnel dans le paquet.
  # (03/11/2026 : le garde-fou d'origine ne cherchait que cinq motifs et laissait passer « Lucas », « lucas-perso » et « chantier client ».)
  if grep -rIniE 's[k]olae|kord[i]s|wiz[a]rd|/Us[e]rs/|lucas|hirschau[e]r|chantier cli[e]nt|reply\.com|lucas-rep[l]y' "$D" | grep -v 'paquet.sh'; then echo "REFUS : donnée privée dans le paquet"; return 1; fi
  # L'installateur ne doit citer que des fichiers qui sont dans le paquet (sauf ceux qu'il refuse lui-même sans le dépôt complet).
  for f in install.sh; do
    for c in $(grep -oE '(outils|perfs|hooks|skills)/[A-Za-z0-9_./-]+\.(sh|mjs)' "$D/$f" | sort -u); do
      [ -e "$D/$c" ] || [ -e "$D/${c%%/\*}" ] || case "$c" in outils/rapatrier.sh|outils/analyse-mensuelle.sh|perfs/synthese.mjs|perfs/collecter.mjs|hooks/attente.mjs) ;;   # cités mais gardés par install.sh (absents sans le dépôt complet, ou fichier non encore suivi par git)
   *) echo "REFUS : $f cite $c, absent du paquet"; return 1 ;; esac
    done
  done
}
# Essai du garde-fou seul : outils/paquet.sh --verifier <dossier>
if [ "${1:-}" = "--verifier" ]; then garde_fou "$2"; exit $?; fi
SORTIE=${1:-$HOME/lucashi-apps/public/orchestrateur}
V=$(sed -n 's/^version: *//p' skills/orchestrateur/SKILL.md | head -1)
T=$(mktemp -d); D=$T/orchestration-claude
mkdir -p "$D/perfs"
# outils/tests/ rejoue un cas réel (noms de client, chemins du Mac) : il reste dans le dépôt privé, hors du zip.
# CHANGELOG.md raconte les essais de la personne qui maintient le dépôt (prénom, chantier client) : lui aussi reste hors du zip.
git ls-files | grep -vE '^(perfs/|skills/orchestrateur/references/|apprentissages/|outils/tests/|outils/rapatrier\.sh|outils/analyse-mensuelle\.sh|CHANGELOG\.md|\.github/)' | while read -r f; do mkdir -p "$D/$(dirname "$f")"; cp -p "$f" "$D/$f"; done
for f in outils/etat.mjs outils/ranger.mjs outils/accueil.mjs outils/paquet.sh skills/orch/SKILL.md; do mkdir -p "$D/$(dirname "$f")"; cp -p "$f" "$D/$f"; done
echo "$V" > "$D/VERSION"
garde_fou "$D" || exit 1
mkdir -p "$SORTIE"; rm -f "$SORTIE/orchestrateur.zip"
(cd "$T" && zip -qr -X "$SORTIE/orchestrateur.zip" orchestration-claude)
# Empreinte publiée à côté du zip : le prompt d'installation la fait vérifier avant d'ouvrir le zip.
(cd "$SORTIE" && shasum -a 256 orchestrateur.zip | cut -d' ' -f1 > orchestrateur.zip.sha256 && echo "$V" > orchestrateur.version)
echo "$SORTIE/orchestrateur.zip — v$V, $(unzip -l "$SORTIE/orchestrateur.zip" | tail -1 | awk '{print $2}') fichiers"
rm -rf "$T"
