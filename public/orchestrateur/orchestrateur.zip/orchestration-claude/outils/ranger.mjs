#!/usr/bin/env node
// Range une orchestration : les sessions de la famille (lancées par elle, ses sœurs, ses filles), leur état,
// leur poids en mémoire vive et en jetons, le tri à archiver / garder / relancer, les notes de reprise
// et le bilan après archivage. Sert `/orch ranger`. Sortie en Markdown, que Claude recopie telle quelle.
//
// Usage : node outils/ranger.mjs [liste|notes [ids…]|bilan] [--dossier chemin] [--json]
// Lit, sans rien y écrire : le magasin de sessions de l'app de bureau, ~/.claude/projects, `ps`, `git status`.
// Écrit : ~/.cache/orchestration/ranger.json (le plan et la mémoire avant), les notes de reprise.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { lire, famille, cout } from './extraire.mjs';

const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args.splice(i, 2)[1] : null; };
const JSON_ = args.includes('--json') && args.splice(args.indexOf('--json'), 1);
const DOSSIER = opt('--dossier') || process.cwd();
const [CMD = 'liste', ...IDS] = args;
const MAISON = os.homedir();
const MAGASIN = path.join(MAISON, 'Library/Application Support/Claude/claude-code-sessions');
const PROJETS = path.join(MAISON, '.claude/projects');
const CACHE = path.join(MAISON, '.cache/orchestration');
const PLAN = path.join(CACHE, 'ranger.json');
const COFFRE = process.env.ORCH_COFFRE || path.join(MAISON, 'pboard');
const MOI = process.env.CLAUDE_CODE_HOST_SESSION_ID || '';
const MAINTENANT = Date.now();

// ── Mise en forme (comme etat.mjs)
const k = (n) => n >= 1e6 ? `${(n / 1e6).toFixed(1).replace('.', ',')} M` : n >= 1000 ? `${Math.round(n / 1000)} k` : String(n);
const $ = (n) => `${n.toFixed(2).replace('.', ',')} $`;
const mo = (n) => n >= 1024 ? `${(n / 1024).toFixed(2).replace('.', ',')} Go` : `${Math.round(n)} Mo`;
const jauge = (v, max, l = 10) => { const p = Math.min(1, v / max); const n = Math.round(p * l); return '█'.repeat(n) + '░'.repeat(l - n); };
const age = (ms) => { const m = Math.round(ms / 60000); return m < 60 ? `${m} min` : m < 1440 ? `${Math.floor(m / 60)} h` : `${Math.floor(m / 1440)} j ${Math.floor((m % 1440) / 60)} h`; };
const court = (t = '', n = 70) => { const s = String(t).replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[|\n]+/g, ' ').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s || '—'; };
const slug = (t) => t.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50);
const sh = (cmd, a, cwd) => { try { return execFileSync(cmd, a, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 8000 }); } catch { return ''; } };

// ── Le magasin de l'app : un JSON par session (titre, dossier, archivée, dernier rapport, parent).
function magasin() {
  const S = new Map();
  const marcher = (d, n) => { if (n > 3 || !fs.existsSync(d)) return;
    for (const f of fs.readdirSync(d)) { const p = path.join(d, f);
      if (f.startsWith('local_') && f.endsWith('.json')) { try { const j = JSON.parse(fs.readFileSync(p, 'utf8')); S.set(j.sessionId, j); } catch {} }
      else if (!f.includes('.') && fs.statSync(p).isDirectory()) marcher(p, n + 1); } };
  marcher(MAGASIN, 0);
  return S;
}

// ── La mémoire vive : chaque processus `claude` porte l'id de sa session dans son environnement.
function memoire() {
  const ps = sh('ps', ['-axo', 'pid=,ppid=,rss=,comm=']).trim().split('\n').map((l) => l.trim().match(/^(\d+)\s+(\d+)\s+(\d+)\s+(.*)$/)).filter(Boolean)
    .map((m) => ({ pid: +m[1], ppid: +m[2], rss: +m[3] / 1024, comm: m[4] }));
  const enfants = (p) => ps.filter((x) => x.ppid === p).flatMap((x) => [x, ...enfants(x.pid)]);
  const parSession = {}; let total = 0; let n = 0;
  for (const p of ps.filter((x) => /\/claude$/.test(x.comm))) {
    const env = sh('ps', ['eww', '-o', 'command=', '-p', String(p.pid)]);
    const id = env.match(/CLAUDE_CODE_HOST_SESSION_ID=(\S+)/)?.[1] || `pid-${p.pid}`;
    const rss = p.rss + enfants(p.pid).reduce((a, x) => a + x.rss, 0);
    parSession[id] = (parSession[id] || 0) + rss; total += rss; n++;
  }
  return { parSession, total, n, date: new Date().toISOString() };
}

// ── La famille : on remonte les parents jusqu'à la racine, puis on prend tous ses descendants.
function famillede(S, moi) {
  const parent = (j) => j?.spawnedFrom?.sessionId;
  let racine = moi; const vus = new Set();
  while (parent(S.get(racine)) && !vus.has(racine)) { vus.add(racine); racine = parent(S.get(racine)); }
  const ancetres = new Set([...vus, racine]);
  const membres = new Set([racine]); let ajout = true;
  while (ajout) { ajout = false; for (const [id, j] of S) if (!membres.has(id) && membres.has(parent(j))) { membres.add(id); ajout = true; } }
  return { racine, membres, ancetres };
}

// ── Ce qu'une transcription dit de la session : contexte, coût, commits, plan restant, fichiers touchés.
function transcription(j) {
  const nom = `${j.cliSessionId}.jsonl`;
  for (const d of [j.cwd, j.originCwd].filter(Boolean).map((c) => path.join(PROJETS, c.replace(/[^A-Za-z0-9]/g, '-')))) if (fs.existsSync(path.join(d, nom))) return path.join(d, nom);
  for (const d of fs.existsSync(PROJETS) ? fs.readdirSync(PROJETS) : []) if (fs.existsSync(path.join(PROJETS, d, nom))) return path.join(PROJETS, d, nom);
  return null;
}
async function lireSession(f, cwd) {
  const r = { ctx: 0, cout: 0, jetons: 0, tours: 0, commits: [], plan: [], fichiers: new Set(), dossiers: new Set(), messages: new Set(), cites: new Set(), debut: '', fin: '', demande: '', recap: '', ask: '', modele: '', mtime: 0, cwd };
  if (!f) return r;
  r.mtime = fs.statSync(f).mtimeMs; const vus = new Set(); const bash = new Map();
  await lire(f, (ev) => {
    if (ev.timestamp) { r.debut ||= ev.timestamp; r.fin = ev.timestamp; }
    const m = ev.message; if (!m) return;
    if (ev.type === 'user') {
      for (const c of Array.isArray(m.content) ? m.content : []) {
        if (c.type === 'tool_result' && bash.has(c.tool_use_id)) {
          const t = Array.isArray(c.content) ? c.content.map((x) => x.text || '').join('\n') : String(c.content || '');
          for (const x of t.matchAll(/^\[([\w./-]+)(?: \(root-commit\))? ([0-9a-f]{7,})\] (.+)$/gm)) r.commits.push({ branche: x[1], sha: x[2], msg: x[3].slice(0, 140), dossier: bash.get(c.tool_use_id) });
        }
      }
      const t = typeof m.content === 'string' ? m.content : (Array.isArray(m.content) ? m.content.filter((x) => x.type === 'text').map((x) => x.text).join('\n') : '');
      const propre = t.replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, '').trim();
      if (propre && !ev.isMeta && !/^\s*<(?!pasted)/.test(propre)) r.demande = propre;
      return;
    }
    if (ev.type !== 'assistant') return;
    for (const c of Array.isArray(m.content) ? m.content : []) {
      if (c.type === 'text') for (const x of (c.text || '').matchAll(/`([0-9a-f]{7,12})`|\bcommits? ([0-9a-f]{7,12})\b/g)) r.cites.add(x[1] || x[2]);
      if (c.type !== 'tool_use') continue; const i = c.input || {};
      if (c.name === 'Bash') {
        const cmd = i.command || ''; const d = (cmd.match(/(?:^|[;&|]\s*)cd\s+([^\s;&|]+)/) || [])[1] || (cmd.match(/git\s+-C\s+(\S+)/) || [])[1];
        if (d) r.dossiers.add(d.replace(/^~/, MAISON).replace(/^["']|["']$/g, ''));
        if (/git\b[^|;&]*\bcommit\b/.test(cmd)) { bash.set(c.id, d || ev.cwd); const msg = cmd.match(/-m\s+(?:"([^"\n]+)|'([^'\n]+))/); if (msg) r.messages.add((msg[1] || msg[2]).trim()); }
      }
      else if (/update_plan$/.test(c.name) && Array.isArray(i.items)) { r.plan = i.items.map((x) => ({ quoi: x.content, etat: x.status })); r.ask = ''; }
      else if (/update_plan$/.test(c.name) && i.advance && r.plan.length) { const n = r.plan.findIndex((x) => x.etat === 'in_progress'); if (n >= 0) { r.plan[n].etat = 'completed'; if (r.plan[n + 1]) r.plan[n + 1].etat = 'in_progress'; } }
      else if (/wrap_up$/.test(c.name)) { r.recap = i.recap || ''; r.ask = i.ask || ''; r.plan.forEach((x) => { x.etat = 'completed'; }); } // la fin de tour coche toute la liste
      else if ((c.name === 'Edit' || c.name === 'Write') && i.file_path) r.fichiers.add(i.file_path);
    }
    if (!m.usage || (m.id && vus.has(m.id))) return;
    if (m.id) vus.add(m.id);
    const u = m.usage; r.tours++; r.modele = m.model || r.modele; r.cout += cout(famille(m.model), u);
    r.ctx = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    r.jetons += r.ctx + (u.output_tokens || 0);
  });
  // `git commit -q` n'écrit rien : on retrouve les commits dans le journal des dépôts touchés, par leur message.
  if (r.messages.size && r.debut) for (const d of r.dossiers) {
    if (!fs.existsSync(d)) continue;
    const fin = new Date(new Date(r.fin).getTime() + 120000).toISOString();
    for (const l of sh('git', ['log', '--all', `--since=${r.debut}`, `--until=${fin}`, '--format=%h%x09%D%x09%s'], d).split('\n').filter(Boolean)) {
      const [sha, refs, msg] = l.split('\t');
      if (r.messages.has(msg) && !r.commits.some((c) => sha.startsWith(c.sha) || c.sha.startsWith(sha))) r.commits.push({ branche: sh('git', ['branch', '--show-current'], d).trim() || refs || '?', sha, msg: msg.slice(0, 140), dossier: d });
    }
  }
  // Filet : les empreintes que la session cite elle-même (« commit 0e6adca »), vérifiées dans ses dépôts.
  for (const sha of r.cites) if (!r.commits.some((c) => c.sha.startsWith(sha) || sha.startsWith(c.sha))) for (const d of [...r.dossiers, r.cwd].filter((x) => x && fs.existsSync(x))) {
    const l = sh('git', ['log', '-1', '--format=%h%x09%s', sha], d).trim(); if (!l) continue;
    const [h, msg] = l.split('\t'); r.commits.push({ branche: sh('git', ['branch', '--show-current'], d).trim() || '?', sha: h, msg: msg.slice(0, 140), dossier: d }); break;
  }
  for (const c of r.commits) if (c.dossier && fs.existsSync(c.dossier)) for (const f of sh('git', ['show', '--name-only', '--format=', c.sha], c.dossier).split('\n').filter(Boolean)) r.fichiers.add(path.join(sh('git', ['rev-parse', '--show-toplevel'], c.dossier).trim(), f));
  return r;
}

// ── Le travail non commité : les fichiers touchés par la session qui restent modifiés dans son dépôt.
function nonCommite(j, fichiers) {
  if (!j.cwd || !fs.existsSync(j.cwd)) return [];
  const racine = sh('git', ['rev-parse', '--show-toplevel'], j.cwd).trim(); if (!racine) return [];
  const sales = sh('git', ['status', '--porcelain'], racine).split('\n').filter(Boolean).map((l) => path.join(racine, l.slice(3).replace(/^"|"$/g, '')));
  return sales.filter((f) => fichiers.has(f));
}

// ── Le projet du coffre : le dossier `docs/` du dépôt est un lien vers Projets/<Nom>/.
function projetCoffre(cwd) {
  const commun = sh('git', ['rev-parse', '--path-format=absolute', '--git-common-dir'], cwd).trim();
  const depot = commun ? path.dirname(commun) : cwd;
  try { const p = fs.realpathSync(path.join(depot, 'docs')); if (p.startsWith(path.join(COFFRE, 'Projets') + path.sep)) return p; } catch {}
  return null;
}

// ── Le tri, règle par règle. Jamais une session qui travaille ou attend une réponse.
function trier(x) {
  if (x.id === MOI) return ['garder', 'c’est cette session'];
  if (x.ancetre) return ['garder', 'orchestration au-dessus de celle-ci'];
  if (x.etat === 'travaille') return ['garder', 'travaille'];
  if (x.question) return ['garder', `attend : ${court(x.question, 60)}`];
  if (x.nonCommite.length) return ['garder', `${x.nonCommite.length} fichier(s) non commité(s)`];
  if (x.fillesActives) return ['garder', `${x.fillesActives} fille(s) encore active(s)`];
  if ((x.reste.length || x.ask) && x.ctx > 250000) return ['relancer', `suite proposée, ${k(x.ctx)} de contexte : repartir de la note`];
  if (x.etat === 'à relire' && x.inactif < 12 * 36e5) return ['garder', 'à relire'];
  if (x.inactif < 30 * 60000) return ['garder', 'active il y a moins de 30 min'];
  return ['archiver', x.reste.length ? `${x.reste.length} étape(s) non faite(s), notées` : x.ask ? 'finie, sa suite est notée' : 'finie'];
}

async function inventaire() {
  const S = magasin();
  if (!S.size) return { erreur: 'Magasin de sessions introuvable : `/orch ranger` demande l’app de bureau Claude (onglet Code).' };
  const moi = MOI && S.has(MOI) ? MOI : [...S.values()].filter((j) => j.cwd === DOSSIER && !j.isArchived).sort((a, b) => b.lastActivityAt - a.lastActivityAt)[0]?.sessionId;
  if (!moi) return { erreur: 'Aucune session de l’app trouvée pour ce dossier.' };
  const F = famillede(S, moi); const M = memoire();
  const L = [];
  for (const id of F.membres) {
    const j = S.get(id); if (!j || j.isArchived) continue;
    const t = await lireSession(transcription(j), j.cwd);
    const p = j.postTurnSummary || {};
    const recent = MAINTENANT - Math.max(t.mtime, j.lastActivityAt || 0) < 3 * 60000 && id !== moi;
    const etat = id === moi || recent ? 'travaille' : p.status_category === 'blocked' || p.needs_action ? 'attend' : p.status_category === 'review_ready' ? 'à relire' : p.status_category === 'completed' ? 'finie' : 'au repos';
    const x = { id, titre: j.title || '(sans titre)', cwd: j.cwd, cli: j.cliSessionId, parent: j.spawnedFrom?.sessionId, etat, ancetre: F.ancetres.has(id) && id !== moi,
      inactif: MAINTENANT - (j.lastActivityAt || j.createdAt || MAINTENANT), rapport: j.lastTurnReport || t.recap || '', detail: p.status_detail || '',
      question: p.needs_action || (etat === 'attend' ? t.ask || p.status_detail : ''), rss: M.parSession[id] || 0,
      ctx: t.ctx, cout: t.cout, jetons: t.jetons, tours: t.tours, modele: j.model || t.modele, commits: t.commits, reste: t.plan.filter((y) => y.etat !== 'completed'),
      plan: t.plan, fichiers: [...t.fichiers], demande: t.demande, recap: t.recap, ask: t.ask, creee: j.createdAt, nonCommite: nonCommite(j, t.fichiers) };
    L.push(x);
  }
  for (const x of L) x.fillesActives = L.filter((y) => y.parent === x.id && ['travaille', 'attend'].includes(y.etat)).length;
  for (const x of L) [x.tri, x.raison] = trier(x);
  const archivees = [...F.membres].filter((id) => S.get(id)?.isArchived).length;
  return { L, M, racine: F.racine, moi, archivees, titreRacine: S.get(F.racine)?.title || '' };
}

// ── La note de contexte : assez pour reprendre sans rien relire.
function note(x) {
  const projet = x.cwd && projetCoffre(x.cwd);
  const dossier = projet ? path.join(projet, 'Journal/Sessions') : path.join(CACHE, 'notes');
  fs.mkdirSync(dossier, { recursive: true });
  const jour = new Date().toISOString().slice(0, 10);
  const fichier = path.join(dossier, `${jour}-reprise-${slug(x.titre)}-${x.id.slice(6, 14)}.md`);
  const branche = x.cwd ? sh('git', ['branch', '--show-current'], x.cwd).trim() : '';
  const fait = x.plan.filter((y) => y.etat === 'completed');
  const t = ['---', `titre: "Reprise — ${x.titre.replace(/"/g, '\'')}"`, 'type: reprise', `date: ${jour}`, `session: ${x.id}`, `cli_session: ${x.cli}`,
    `dossier: "${x.cwd}"`, `modele: ${x.modele}`, `tours: ${x.tours}`, `contexte: ${x.ctx}`, `cout_usd: ${x.cout.toFixed(2)}`, `archivee: ${jour}`, '---',
    `# Reprise — ${x.titre}`, '',
    `Session archivée le ${jour} par \`/orch ranger\` après ${age(MAINTENANT - (x.creee || MAINTENANT))} de vie et ${x.tours} tours (${k(x.ctx)} jetons de contexte, ${$(x.cout)} aux prix publics). État au rangement : ${x.etat}.`, '',
    '## Ce qui est fait', '', x.rapport ? `> ${x.rapport.replace(/\n+/g, '\n> ')}` : '- (aucun rapport de fin de tour)', '',
    ...(fait.length ? ['Étapes terminées :', ...fait.map((y) => `- [x] ${y.quoi}`), ''] : []),
    `Commits (${x.commits.length}) :`, ...(x.commits.length ? x.commits.map((c) => `- \`${c.sha}\` ${c.msg} — \`${(c.dossier || '').replace(MAISON, '~')}\`, branche \`${c.branche}\``) : ['- aucun commit fait par cette session']), '',
    `Fichiers touchés (${x.fichiers.length}) :`, ...x.fichiers.slice(0, 25).map((f) => `- \`${f.replace(MAISON, '~')}\``), ...(x.fichiers.length > 25 ? [`- … et ${x.fichiers.length - 25} autres`] : []), '',
    '## Ce qui reste à faire', '',
    ...(x.reste.length ? x.reste.map((y) => `- [ ] ${y.quoi}`) : ['- rien d’annoncé dans le plan de la session']),
    ...(x.question ? ['', `Question restée ouverte : ${x.question}`] : x.ask ? ['', `Dernière question posée : ${x.ask}`] : []),
    ...(x.detail ? ['', `Dernier état noté par l’app : ${x.detail}`] : []), '',
    '## Dernière demande reçue', '', '> ' + court(x.demande, 600), '',
    '## Comment reprendre', '',
    `1. Dans l’app : la session « ${x.titre} » est dans les archives ; la désarchiver (\`unarchive_session\` \`${x.id}\`) la rouvre avec tout son contexte.`,
    `2. En terminal : \`cd ${(x.cwd || '').replace(MAISON, '~')} && claude --resume ${x.cli}\`${branche ? ` (branche \`${branche}\`)` : ''}.`,
    '3. Plus léger : une session neuve avec pour seul brief cette note — le contexte repart de zéro au lieu de ' + k(x.ctx) + ' jetons.', ''];
  fs.writeFileSync(fichier, t.join('\n'));
  return fichier;
}

// ── Sorties
const out = [];
const lien = (f) => `[${path.basename(f)}](${f.replace(/ /g, '%20')})`;
if (CMD === 'liste') {
  const I = await inventaire();
  if (I.erreur) { console.log(I.erreur); process.exit(0); }
  const { L, M } = I;
  const ordre = { travaille: 0, attend: 1, 'à relire': 2, 'au repos': 3, finie: 4 };
  L.sort((a, b) => ordre[a.etat] - ordre[b.etat] || b.rss - a.rss);
  const A = L.filter((x) => x.tri !== 'garder'), G = L.filter((x) => x.tri === 'garder'), R = L.filter((x) => x.tri === 'relancer');
  const rssA = A.reduce((a, x) => a + x.rss, 0), vivantes = L.filter((x) => x.rss).length;
  fs.mkdirSync(CACHE, { recursive: true });
  fs.writeFileSync(PLAN, JSON.stringify({ date: M.date, moi: I.moi, avant: { total: M.total, n: M.n, parSession: M.parSession },
    archiver: A.map((x) => ({ id: x.id, titre: x.titre, rss: x.rss, jetons: x.jetons, cout: x.cout, ctx: x.ctx })) }, null, 1));
  if (JSON_) { console.log(JSON.stringify({ L, M }, null, 1)); process.exit(0); }
  const pic = { travaille: '🟢 travaille', attend: '🟠 attend', 'à relire': '🔵 à relire', 'au repos': '⚪ au repos', finie: '✅ finie' };
  const triPic = { archiver: '🗄 archiver', garder: '📌 garder', relancer: '🔁 relancer' };
  out.push(`## 🧹 Ranger l’orchestration — ${court(I.titreRacine, 60)}`, '',
    '| | |', '|---|---|',
    `| **Sessions de la famille** | **${L.length}** ouvertes — ${['travaille', 'attend', 'à relire', 'finie', 'au repos'].map((e) => [e, L.filter((x) => x.etat === e).length]).filter(([, n]) => n).map(([e, n]) => `${n} ${e}`).join(' · ')}${I.archivees ? ` · ${I.archivees} déjà archivée(s)` : ''} |`,
    `| **Mémoire vive, tout Claude Code** | \`${jauge(M.total, os.totalmem() / 1048576, 14)}\` **${mo(M.total)}** sur ${mo(os.totalmem() / 1048576)} — ${M.n} processus \`claude\` sur ce Mac, ${vivantes} de cette famille |`,
    `| **Jetons relus par la famille** | ${k(L.reduce((a, x) => a + x.jetons, 0))} · ${$(L.reduce((a, x) => a + x.cout, 0))} aux prix publics |`,
    `| **Proposé** | 🗄 ${A.length} à archiver · 📌 ${G.length} à garder · 🔁 ${R.length} à relancer |`,
    `| **À rendre en archivant** | **${mo(rssA)}** de mémoire vive (${A.filter((x) => x.rss).length} processus) · ${k(A.reduce((a, x) => a + x.ctx, 0))} jetons de contexte qui ne seront plus relus |`, '',
    '| Session | État | Inactive | Mémoire | Contexte | Coût | Commité | Question | Dernier rapport | Tri |', '|---|---|---|---|---|---|---|---|---|---|',
    ...L.map((x) => `| ${court(x.titre, 42)} | ${pic[x.etat]} | ${x.etat === 'travaille' ? '—' : age(x.inactif)} | ${x.rss ? `\`${jauge(x.rss, 400, 5)}\` ${mo(x.rss)}` : '· fermée'} | \`${jauge(x.ctx, 500000, 5)}\` ${k(x.ctx)} | ${$(x.cout)} | ${x.nonCommite.length ? `✗ ${x.nonCommite.length}` : '✓'} | ${x.question ? '✗ oui' : '✓'} | ${court(x.rapport || x.detail, 55)} | ${triPic[x.tri]} — ${x.raison} |`), '',
    A.length ? `**À archiver (${A.length}, dont ${R.length} à relancer ensuite depuis leur note)** : ${A.map((x) => `${court(x.titre, 40)} \`${x.id.slice(6, 14)}\``).join(' · ')}` : '**Rien à archiver** : toutes les sessions travaillent, attendent ou viennent de finir.', '',
    'Avant chaque archivage, une note de reprise est écrite (fait + commits, reste à faire, comment reprendre) ' +
    'dans le coffre du projet quand il y en a un, sinon dans `~/.cache/orchestration/notes/`.',
    `Ids à archiver : ${A.map((x) => x.id).join(' ') || '—'}`);
} else if (CMD === 'notes') {
  const P = fs.existsSync(PLAN) ? JSON.parse(fs.readFileSync(PLAN, 'utf8')) : { archiver: [] };
  const voulu = IDS.length ? IDS : P.archiver.map((x) => x.id);
  const I = await inventaire(); if (I.erreur) { console.log(I.erreur); process.exit(0); }
  const ecrites = [];
  for (const id of voulu) {
    const x = I.L.find((y) => y.id === id);
    if (!x) { out.push(`- ✗ \`${id}\` : hors de la famille ou déjà archivée`); continue; }
    if (['travaille', 'attend'].includes(x.etat)) { out.push(`- ✗ ${x.titre} : ${x.etat}, pas d’archivage`); continue; }
    const f = note(x); ecrites.push({ id, titre: x.titre, note: f }); out.push(`- ✓ ${x.titre} → ${lien(f)}`);
  }
  P.notes = ecrites; P.archiver = P.archiver.filter((x) => ecrites.some((e) => e.id === x.id));
  for (const e of ecrites) if (!P.archiver.some((x) => x.id === e.id)) { const x = I.L.find((y) => y.id === e.id); P.archiver.push({ id: x.id, titre: x.titre, rss: x.rss, jetons: x.jetons, cout: x.cout, ctx: x.ctx }); }
  fs.writeFileSync(PLAN, JSON.stringify(P, null, 1));
  out.unshift(`### Notes de reprise écrites : ${ecrites.length}`, '');
  out.push('', `Prêtes à archiver : ${ecrites.map((e) => e.id).join(' ') || '—'}`);
} else if (CMD === 'bilan') {
  if (!fs.existsSync(PLAN)) { console.log('Pas de rangement en cours : lancer `/orch ranger` d’abord.'); process.exit(0); }
  const P = JSON.parse(fs.readFileSync(PLAN, 'utf8')); const S = magasin(); let M = memoire();
  // Un processus archivé met quelques secondes à s'arrêter : on attend jusqu'à 15 s qu'ils soient tous partis.
  for (let i = 0; i < 15 && P.archiver.some((x) => S.get(x.id)?.isArchived && M.parSession[x.id]); i++) { await new Promise((r) => setTimeout(r, 1000)); M = memoire(); }
  const faits = P.archiver.filter((x) => S.get(x.id)?.isArchived);
  const fermes = faits.filter((x) => P.avant.parSession[x.id] && !M.parSession[x.id]);
  const rendu = fermes.reduce((a, x) => a + P.avant.parSession[x.id], 0);
  const notes = (P.notes || []).filter((n) => faits.some((x) => x.id === n.id));
  out.push('## ✨ Orchestration rangée', '',
    '| | Avant | Après | |', '|---|---|---|---|',
    `| **Sessions archivées** | | | **${faits.length}** sur ${P.archiver.length} prévue(s) |`,
    `| **Processus \`claude\` vivants** | ${P.avant.n} | ${M.n} | ${fermes.length} fermé(s) par l’archivage |`,
    `| **Mémoire vive, tout Claude Code** | ${mo(P.avant.total)} | ${mo(M.total)} | \`${jauge(rendu, P.avant.total, 14)}\` **${mo(rendu)} rendus** |`,
    `| **Contexte qui ne sera plus relu** | | | **${k(faits.reduce((a, x) => a + x.ctx, 0))} jetons** |`,
    `| **Ce qu’avaient coûté ces sessions** | | | ${k(faits.reduce((a, x) => a + x.jetons, 0))} jetons · ${$(faits.reduce((a, x) => a + x.cout, 0))} |`, '',
    `Mesure : RSS par \`ps\` des processus \`claude\` (et de leurs enfants), le ${new Date(P.date).toLocaleString('fr-FR')} puis le ${new Date(M.date).toLocaleString('fr-FR')}. ` +
    'La différence du total compte aussi les sessions qui ont grossi ou démarré entre-temps ; « rendus » ne compte que les processus des sessions archivées.', '',
    `**Notes de reprise (${notes.length})**`, '', ...notes.map((n) => `- ${court(n.titre, 60)} → ${lien(n.note)}`));
  P.apres = { total: M.total, n: M.n, date: M.date, rendu, fermes: fermes.length, archivees: faits.length };
  fs.writeFileSync(PLAN, JSON.stringify(P, null, 1));
} else out.push('Commandes : `liste` (défaut), `notes [ids…]`, `bilan`.');
console.log(out.join('\n'));
