#!/usr/bin/env node
// Active (ou retire) la compaction sur place dans ~/.claude/settings.json : le crochet hooks/compaction.mjs sur PreCompact et
// SessionStart (matcher compact), et le seuil de compaction automatique. Par défaut, MONTRE seulement ce qui changerait ;
// rien n'est écrit sans --ecrire (et settings.json.avant-compaction garde l'original, copié une seule fois).
// Usage : node outils/compaction.mjs [activer|retirer] [--ecrire] [--fenetre 180000] [--reglages chemin]
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const DEPOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const a = process.argv.slice(2);
const opt = (n) => { const i = a.indexOf(n); return i >= 0 ? a.splice(i, 2)[1] : null; };
const ecrire = a.includes('--ecrire');
const FENETRE = Number(opt('--fenetre') || 180000);
const S = opt('--reglages') || path.join(os.homedir(), '.claude', 'settings.json');
const cmd = a.find((x) => !x.startsWith('--')) || 'activer';
const noeud = process.execPath;
const hook = `"${noeud}" "${DEPOT}/hooks/compaction.mjs"`;

export function appliquer(d, mode = 'activer', fenetre = FENETRE) {
  d = JSON.parse(JSON.stringify(d)); d.hooks ??= {}; const notes = [];
  const ligne = (ev) => (d.hooks[ev] ??= []);
  const present = (ev) => JSON.stringify(d.hooks[ev] || []).includes('hooks/compaction.mjs');
  if (mode === 'activer') {
    if (!present('PreCompact')) { ligne('PreCompact').push({ hooks: [{ type: 'command', command: hook, timeout: 15 }] }); notes.push('crochet PreCompact ajouté (consignes de résumé + note à jour)'); } else notes.push('crochet PreCompact déjà présent');
    if (!present('SessionStart')) { ligne('SessionStart').push({ matcher: 'compact', hooks: [{ type: 'command', command: hook, timeout: 10 }] }); notes.push('crochet SessionStart (compact) ajouté (relire la note après le compactage)'); } else notes.push('crochet SessionStart déjà présent');
    if (d.autoCompactWindow !== fenetre) { notes.push(`autoCompactWindow : ${d.autoCompactWindow ?? 'non réglé (défaut du modèle, ≈ 967 000 pour les modèles à 1 M)'} → ${fenetre}`); d.autoCompactWindow = fenetre; } else notes.push(`autoCompactWindow déjà à ${fenetre}`);
  } else {
    for (const ev of ['PreCompact', 'SessionStart']) if (d.hooks[ev]) { const n = d.hooks[ev].length; d.hooks[ev] = d.hooks[ev].filter((h) => !JSON.stringify(h).includes('hooks/compaction.mjs')); if (d.hooks[ev].length < n) notes.push(`crochet ${ev} retiré`); if (!d.hooks[ev].length) delete d.hooks[ev]; }
    if (d.autoCompactWindow != null) { notes.push(`autoCompactWindow ${d.autoCompactWindow} retiré`); delete d.autoCompactWindow; }
  }
  return { d, notes };
}

if (process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) {
  let actuel = {}; try { actuel = JSON.parse(fs.readFileSync(S, 'utf8')); } catch { if (fs.existsSync(S)) { console.error(`${S} illisible : rien n'est changé.`); process.exit(1); } }
  const { d, notes } = appliquer(actuel, cmd === 'retirer' ? 'retirer' : 'activer');
  console.log(`${ecrire ? 'Écrit dans' : 'Montre (rien n\'est écrit ; ajouter --ecrire) pour'} ${S} :\n${notes.map((n) => `- ${n}`).join('\n')}`);
  if (ecrire) { fs.mkdirSync(path.dirname(S), { recursive: true }); if (fs.existsSync(S) && !fs.existsSync(`${S}.avant-compaction`)) fs.copyFileSync(S, `${S}.avant-compaction`); fs.writeFileSync(S, JSON.stringify(d, null, 2) + '\n'); console.log('Fait. Dans une session déjà ouverte, vérifier avec /autocompact (le réglage se lit au démarrage ou par cette commande).'); }
}
