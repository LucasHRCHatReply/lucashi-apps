#!/usr/bin/env node
// Le bureau de l'orchestration : ce qu'orchestre une session, ses sous-sessions et ses agents, sur une page locale.
// Sert `/sessiondesk`. Tout ce qui se compte se compte ici, sans modèle : la famille de sessions vient de
// `ranger.mjs liste --json` (magasin de l'app, transcriptions, `ps`), les agents de `subagents/agent-*.meta.json`
// et de leur transcription. Seul le récit « voir plus » passe par Haiku 5.5 en effort faible, sur un extrait court,
// mis en cache par empreinte de l'extrait : un état inchangé ne coûte plus rien.
//
// Usage : node outils/bureau.mjs ouvrir [--dossier chemin] [--session id] [--sans-ouvrir]
//         node outils/bureau.mjs donnees [--session id | --cli uuid] [--dossier chemin]
//         node outils/bureau.mjs environnements
//         node outils/bureau.mjs serveur
// Écrit : ~/.cache/orchestration/bureau-cache.json (agents, clé taille:mtime), bureau-resumes.json (récits),
//         bureau.log. Variables : ORCH_BUREAU_PORT, ORCH_CLAUDE (commande claude, pour les tests).
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import http from 'node:http';
import crypto from 'node:crypto';
import { execFileSync, execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { famille, cout, PRIX } from './extraire.mjs';

const DEPOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const MAISON = os.homedir();
const MAGASIN = path.join(MAISON, 'Library/Application Support/Claude/claude-code-sessions');
const PROJETS = path.join(MAISON, '.claude/projects');
const CACHE = path.join(MAISON, '.cache/orchestration');
const F_AGENTS = path.join(CACHE, 'bureau-cache.json');
const F_RESUMES = path.join(CACHE, 'bureau-resumes.json');
const PORT = Number(process.env.ORCH_BUREAU_PORT || 4517);
const CLAUDE = process.env.ORCH_CLAUDE || 'claude';
const VERSION_CACHE = 2;
// L'empreinte du code servi : un serveur resté sur une ancienne version est remplacé à l'ouverture suivante.
const CODE = ['bureau.mjs', 'bureau.html'].map((f) => Math.floor(fs.statSync(path.join(DEPOT, 'outils', f)).mtimeMs)).join(':');

const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args.splice(i, 2)[1] : null; };
const drapeau = (n) => { const i = args.indexOf(n); if (i >= 0) args.splice(i, 1); return i >= 0; };

const encoder = (c) => c.replace(/[^A-Za-z0-9]/g, '-');
const lireJSON = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const ecrireJSON = (f, v) => { try { fs.mkdirSync(path.dirname(f), { recursive: true }); const t = `${f}.${process.pid}`; fs.writeFileSync(t, JSON.stringify(v)); fs.renameSync(t, f); } catch {} };
const projetDe = (cwd = '') => path.basename(cwd.replace(/\/\.claude\/worktrees\/.*$/, '')) || '—';
const projetTerminal = (d) => d.replace(encoder(MAISON), '').replace(/^-/, '') || '~';
const court = (t = '', n = 400) => { const s = String(t).replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
const texteDe = (c) => Array.isArray(c) ? c.filter((x) => x.type === 'text').map((x) => x.text || '').join('\n') : String(c || '');

// ── Le magasin de l'app (comme ranger.mjs) : un JSON par session.
export function magasin() {
  const S = new Map();
  const marcher = (d, n) => { if (n > 3 || !fs.existsSync(d)) return;
    for (const f of fs.readdirSync(d)) { const p = path.join(d, f);
      if (f.startsWith('local_') && f.endsWith('.json')) { const j = lireJSON(p); if (j?.sessionId) S.set(j.sessionId, j); }
      else if (!f.includes('.') && fs.statSync(p).isDirectory()) marcher(p, n + 1); } };
  marcher(MAGASIN, 0);
  return S;
}

// ── Où vit la transcription d'une session CLI : <projets>/<dossier encodé>/<uuid>.jsonl, sinon on cherche.
const ouTranscription = new Map();
function dossierProjet(cli, cwds = []) {
  if (!cli) return null;
  if (ouTranscription.has(cli)) return ouTranscription.get(cli);
  let r = null;
  for (const c of cwds.filter(Boolean)) { const d = path.join(PROJETS, encoder(c)); if (fs.existsSync(path.join(d, `${cli}.jsonl`)) || fs.existsSync(path.join(d, cli))) { r = d; break; } }
  if (!r && fs.existsSync(PROJETS)) for (const d of fs.readdirSync(PROJETS)) { const p = path.join(PROJETS, d); if (fs.existsSync(path.join(p, `${cli}.jsonl`))) { r = p; break; } }
  ouTranscription.set(cli, r);
  return r;
}
const dossierAgents = (cli, cwds) => { const d = dossierProjet(cli, cwds); return d ? path.join(d, cli, 'subagents') : null; };
const fichiersAgents = (dir) => dir && fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => /^agent-.+\.jsonl$/.test(f)) : [];

// ── Un agent : sa fiche (.meta.json) et sa transcription. Résumé sérialisable, en cache par taille:mtime.
let cacheA = null, cacheModifie = false;
function chargerCacheA() { if (cacheA) return; const c = lireJSON(F_AGENTS, {}); cacheA = c.v === VERSION_CACHE ? c.e : {}; }
function sauverCacheA() { if (cacheModifie) ecrireJSON(F_AGENTS, { v: VERSION_CACHE, e: cacheA }); cacheModifie = false; }

export function lireAgent(fichier) {
  chargerCacheA();
  const st = fs.statSync(fichier), cle = `${st.size}:${Math.floor(st.mtimeMs)}`;
  const meta = lireJSON(fichier.replace(/\.jsonl$/, '.meta.json'), {});
  if (cacheA[fichier]?.cle === cle && cacheA[fichier].finished === meta.finished) return { ...cacheA[fichier].r, mtime: st.mtimeMs };
  const r = { id: path.basename(fichier, '.jsonl').replace(/^agent-/, ''), description: meta.description || '', type: meta.agentType || '',
    modele: meta.model || '', effort: meta.effort || '', fond: meta.requestShape === 'background', fini: meta.finished,
    cout: 0, ctx: 0, jetons: 0, tours: 0, outils: 0, debut: '', fin: '', consigne: '', dernier: '', modeleReel: '', arret: '' };
  const vus = new Set();
  for (const l of fs.readFileSync(fichier, 'utf8').split('\n')) {
    if (!l || l.length > 400 * 1024) continue;
    let ev; try { ev = JSON.parse(l); } catch { continue; }
    const m = ev.message; if (!m) continue;
    if (ev.timestamp) { r.debut ||= ev.timestamp; r.fin = ev.timestamp; }
    if (ev.type === 'user') { if (!r.consigne) { const t = typeof m.content === 'string' ? m.content : texteDe(m.content); if (t) r.consigne = court(t, 900); } continue; }
    if (ev.type !== 'assistant') continue;
    for (const c of Array.isArray(m.content) ? m.content : []) {
      if (c.type === 'tool_use') { r.outils++; if (c.name === 'SubagentHandback' && c.input?.message) r.dernier = c.input.message; }   // le rendu passe par cet outil
      if (c.type === 'text' && c.text?.trim()) r.dernier = c.text;
    }
    if (m.stop_reason) r.arret = m.stop_reason;
    if (!m.usage || (m.id && vus.has(m.id))) continue;
    if (m.id) vus.add(m.id);
    const u = m.usage; r.tours++; r.modeleReel = m.model || r.modeleReel; r.cout += cout(famille(m.model), u);
    r.ctx = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    r.jetons += r.ctx + (u.output_tokens || 0);
  }
  r.dernier = r.dernier.slice(-2400);
  if (r.fini === undefined) r.fini = r.arret === 'end_turn';
  cacheA[fichier] = { cle, finished: meta.finished, r }; cacheModifie = true;
  return { ...r, mtime: st.mtimeMs };
}

// État d'un agent : fini, ou travaille (sa session vit et il a écrit il y a moins de 5 min), sinon interrompu.
function etatAgent(a, vivant, maintenant) {
  if (a.fini) return 'finie';
  if (vivant && maintenant - a.mtime < 5 * 60000) return 'travaille';
  return 'interrompue';
}
function agentsDe(cli, cwds, vivant, maintenant, proprietaire) {
  const dir = dossierAgents(cli, cwds);
  return fichiersAgents(dir).map((f) => { const a = lireAgent(path.join(dir, f));
    const { consigne, dernier, mtime, ...reste } = a;
    return { ...reste, genre: 'agent', cle: `a:${a.id}`, proprietaire, etat: etatAgent(a, vivant, maintenant), titre: a.description || a.type || 'agent', modele: a.modeleReel || a.modele, _consigne: consigne, _dernier: dernier };
  }).sort((a, b) => (a.debut || '').localeCompare(b.debut || ''));
}

// ── La famille de sessions : on réutilise ranger.mjs (même tri, mêmes états, même cache).
function famillePar(session, dossier) {
  const a = [path.join(DEPOT, 'outils/ranger.mjs'), 'liste', '--json', '--avec-archivees', '--dossier', dossier || MAISON];
  if (session) a.push('--session', session);
  try { return JSON.parse(execFileSync(process.execPath, a, { encoding: 'utf8', maxBuffer: 1 << 28, timeout: 60000, stdio: ['ignore', 'pipe', 'ignore'] })); }
  catch { return null; }
}

// État d'une session qui n'est pas celle qui regarde (ranger marque toujours « travaille » la session donnée).
function etatAutre(x, j, maintenant) {
  const p = j?.postTurnSummary || {};
  if (x.vivant && x.inactif < 3 * 60000) return 'travaille';
  if (p.status_category === 'blocked' || p.needs_action) return 'attend';
  if (p.status_category === 'completed') return 'finie';
  if (p.status_category === 'review_ready') return 'à relire';
  return x.inactif > 30 * 60000 ? 'dort' : 'au repos';
}

// ── Les données d'un environnement : la session regardée (« chef »), ses descendantes, les agents de chacune.
export function donnees({ session, cli, dossier, moi } = {}) {
  const maintenant = Date.now();
  if (cli && !session) return donneesCli(cli, maintenant);
  const R = famillePar(session, dossier);
  if (!R || !R.L?.length) return { erreur: 'Aucune session de l’app trouvée pour ce dossier : `/sessiondesk` lit le magasin de l’app de bureau Claude (onglet Code).' };
  const S = magasin();
  const chefId = session || R.moi;
  const parId = new Map(R.L.map((x) => [x.id, x]));
  const chef = parId.get(chefId) || R.L[0];
  // Descendantes du chef, profondeur comprise.
  const prof = new Map([[chef.id, 0]]); let ajout = true;
  while (ajout) { ajout = false; for (const x of R.L) if (!prof.has(x.id) && prof.has(x.parent)) { prof.set(x.id, prof.get(x.parent) + 1); ajout = true; } }
  const courante = moi || process.env.CLAUDE_CODE_HOST_SESSION_ID || R.moi;
  const fiche = (x) => {
    const j = S.get(x.id) || {};
    const etat = x.id === courante ? 'travaille' : x.archivee ? 'rangée' : x.id === R.moi ? etatAutre(x, j, maintenant) : x.etat;
    return { genre: 'session', cle: `s:${x.id}`, id: x.id, titre: x.titre, etat, archivee: x.archivee, profondeur: prof.get(x.id) ?? -1,
      parent: x.parent, modele: x.modele || j.model || '', effort: j.effort || '', cout: x.cout, ctx: x.ctx, jetons: x.jetons, tours: x.tours,
      debut: x.creee ? new Date(x.creee).toISOString() : '', fin: new Date(maintenant - (x.inactif || 0)).toISOString(), rss: x.rss,
      plan: x.plan || [], commits: (x.commits || []).map((c) => c.msg), nonCommite: (x.nonCommite || []).length, question: x.question || '',
      projet: projetDe(x.cwd), cwd: x.cwd, cli: x.cli, vivant: x.vivant, surveille: x.surveille || [],
      _demande: court(x.demande, 900), _rapport: court(x.rapport || x.recap, 900), _ask: x.ask || '' };
  };
  const sessions = R.L.filter((x) => prof.has(x.id)).map(fiche).sort((a, b) => a.profondeur - b.profondeur || (a.debut || '').localeCompare(b.debut || ''));
  const agents = sessions.flatMap((s) => agentsDe(s.cli, [s.cwd, S.get(s.id)?.originCwd], s.vivant || s.id === courante, maintenant, s.id));
  sauverCacheA();
  const c = sessions[0];
  const parent = chef.parent && parId.get(chef.parent) ? { id: chef.parent, titre: parId.get(chef.parent).titre } : null;
  return assembler({ chef: c, sessions, agents, parent, courante, maintenant });
}

// Une transcription du terminal (sans fiche dans l'app) qui a lancé des agents.
function donneesCli(cli, maintenant) {
  const d = dossierProjet(cli); if (!d) return { erreur: 'Transcription introuvable.' };
  const f = path.join(d, `${cli}.jsonl`);
  let titre = '', demande = '', debut = '', fin = '', modele = '', coutT = 0, ctx = 0; const vus = new Set();
  if (fs.existsSync(f)) for (const l of fs.readFileSync(f, 'utf8').split('\n')) {
    if (!l || l.length > 400 * 1024) continue; let ev; try { ev = JSON.parse(l); } catch { continue; }
    if (ev.type === 'custom-title' && ev.customTitle) titre = ev.customTitle;
    if (ev.timestamp && !ev.isSidechain) { debut ||= ev.timestamp; fin = ev.timestamp; }
    const m = ev.message; if (!m) continue;
    if (ev.type === 'user' && !demande && !ev.isMeta) { const t = court(typeof m.content === 'string' ? m.content : texteDe(m.content), 900); if (t && !t.startsWith('<')) demande = t; }
    if (ev.type === 'assistant' && m.usage && !(m.id && vus.has(m.id))) { if (m.id) vus.add(m.id); modele = m.model || modele; coutT += cout(famille(m.model), m.usage); const u = m.usage; ctx = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0); }
  }
  const vivant = fs.existsSync(f) && maintenant - fs.statSync(f).mtimeMs < 3 * 60000;
  const chef = { genre: 'session', cle: `c:${cli}`, id: cli, titre: titre || court(demande, 70) || 'session du terminal', etat: vivant ? 'travaille' : 'au repos', profondeur: 0,
    modele, effort: '', cout: coutT, ctx, debut, fin, plan: [], commits: [], projet: projetTerminal(path.basename(d)), cli, vivant, _demande: demande, _rapport: '' };
  const agents = agentsDe(cli, [], vivant, maintenant, cli);
  sauverCacheA();
  return assembler({ chef, sessions: [chef], agents, parent: null, courante: null, maintenant, terminal: true });
}

const ETATS = ['travaille', 'attend', 'interrompue', 'à relire', 'au repos', 'dort', 'finie', 'rangée'];
function assembler({ chef, sessions, agents, parent, courante, maintenant, terminal = false }) {
  const filles = sessions.filter((s) => s.profondeur > 0);
  const compte = (L) => Object.fromEntries(ETATS.map((e) => [e, L.filter((x) => x.etat === e).length]).filter(([, n]) => n));
  const somme = (L, c) => L.reduce((a, x) => a + (x[c] || 0), 0);
  const parModele = (L) => L.reduce((o, x) => { const f = famille(x.modele) === 'autre' ? 'autre' : famille(x.modele); o[f] = (o[f] || 0) + 1; return o; }, {});
  const partiels = sessions.filter((s) => s.cout == null).length;
  return {
    date: new Date(maintenant).toISOString(), courante, terminal, parent,
    chef: { ...chef }, sessions, agents,
    totaux: { sessions: filles.length, agents: agents.length, etatsSessions: compte(filles), etatsAgents: compte(agents),
      travaillent: [...filles, ...agents].filter((x) => x.etat === 'travaille').length,
      cout: somme(sessions, 'cout') + somme(agents, 'cout'), coutAgents: somme(agents, 'cout'), coutPartiel: partiels > 0,
      modelesSessions: parModele(filles), modelesAgents: parModele(agents) },
    phrase: phraseCalculee(chef, filles, agents),
  };
}

// La phrase de tête, calculée : ce que la session a lancé et pour quoi. Haiku peut la réécrire (voir `phrase`).
function phraseCalculee(chef, filles, agents) {
  const n = (k, s, p) => `${k} ${k > 1 ? p : s}`;
  const titres = filles.filter((s) => s.profondeur === 1).slice(0, 3).map((s) => `« ${court(s.titre, 48)} »`);
  if (!filles.length && !agents.length) return 'Cette session n’a encore lancé ni session ni agent.';
  const premieres = filles.filter((s) => s.profondeur === 1).length;
  const liste = titres.length ? ` — ${titres.join(', ')}${premieres > titres.length ? ` et ${premieres - titres.length} autre(s)` : ''}` : '';
  return `Orchestre ${[filles.length && n(filles.length, 'session', 'sessions'), agents.length && n(agents.length, 'agent', 'agents')].filter(Boolean).join(' et ')}${liste}.`;
}

// ── Les environnements de ce Mac : chaque session de l'app qui a lancé des sessions ou des agents, et chaque
// transcription du terminal qui a lancé des agents. Rangés par projet, du plus récent au plus ancien.
export function environnements({ jours = 45 } = {}) {
  const S = magasin(); const depuis = Date.now() - jours * 864e5;
  const enfants = new Map();
  for (const j of S.values()) { const p = j.spawnedFrom?.sessionId; if (p) enfants.set(p, [...(enfants.get(p) || []), j.sessionId]); }
  const descendants = (id) => { const L = [...(enfants.get(id) || [])]; for (let i = 0; i < L.length; i++) L.push(...(enfants.get(L[i]) || [])); return L; };
  const connus = new Set(); const E = [];
  for (const j of S.values()) {
    if (j.cliSessionId) connus.add(j.cliSessionId);
    const p = j.spawnedFrom?.sessionId; if (p && S.has(p)) continue;   // seules les racines ouvrent un environnement
    const D = descendants(j.sessionId);
    const membres = [j, ...D.map((id) => S.get(id)).filter(Boolean)];
    const nAgents = membres.reduce((a, m) => a + fichiersAgents(dossierAgents(m.cliSessionId, [m.cwd, m.originCwd])).length, 0);
    if (!D.length && !nAgents) continue;
    const derniere = Math.max(...membres.map((m) => m.lastActivityAt || m.createdAt || 0));
    if (derniere < depuis) continue;
    E.push({ id: j.sessionId, genre: 'app', titre: j.title || projetDe(j.cwd), projet: projetDe(j.cwd || j.originCwd), sessions: D.length, agents: nAgents, derniere, archivee: !!j.isArchived });
  }
  // Le terminal : <projets>/<dossier>/<uuid>/subagents sans fiche dans l'app.
  if (fs.existsSync(PROJETS)) for (const d of fs.readdirSync(PROJETS)) {
    const p = path.join(PROJETS, d); if (!fs.statSync(p).isDirectory()) continue;
    for (const u of fs.readdirSync(p)) {
      if (connus.has(u) || !/^[0-9a-f-]{36}$/.test(u)) continue;
      const n = fichiersAgents(path.join(p, u, 'subagents')).length; if (!n) continue;
      const f = path.join(p, `${u}.jsonl`); const m = fs.existsSync(f) ? fs.statSync(f).mtimeMs : 0;
      if (m < depuis) continue;
      ouTranscription.set(u, p);
      E.push({ id: u, genre: 'terminal', titre: titreTerminal(f) || `terminal ${u.slice(0, 8)}`, projet: projetTerminal(d), sessions: 0, agents: n, derniere: m });
    }
  }
  return E.sort((a, b) => b.derniere - a.derniere);
}
function titreTerminal(f) {
  if (!fs.existsSync(f)) return '';
  let t = ''; const fd = fs.openSync(f, 'r'); const b = Buffer.alloc(Math.min(256 * 1024, fs.statSync(f).size)); fs.readSync(fd, b, 0, b.length, 0); fs.closeSync(fd);
  for (const l of b.toString('utf8').split('\n')) { let ev; try { ev = JSON.parse(l); } catch { continue; }
    if (ev.type === 'custom-title' && ev.customTitle) return ev.customTitle;
    if (!t && ev.type === 'user' && !ev.isMeta) { const c = court(typeof ev.message?.content === 'string' ? ev.message.content : texteDe(ev.message?.content), 60); if (c && !c.startsWith('<')) t = c; } }
  return t;
}

// ── Le récit « voir plus » : Haiku 5.5 · low sur un extrait court ; cache par empreinte de l'extrait.
export function extrait(x) {
  if (x.genre === 'agent') return [`Agent « ${x.titre} » (${x.type || 'agent'}), état : ${x.etat}.`,
    `Consigne reçue (début) : ${court(x._consigne, 700)}`, `Dernier message rendu (fin) : ${court(x._dernier, 1600)}`].join('\n');
  return [`Session « ${x.titre} », état : ${x.etat}${x.archivee ? ' (rangée)' : ''}.`,
    x._demande && `Demande reçue : ${court(x._demande, 700)}`,
    x._rapport && `Dernier rapport : ${court(x._rapport, 900)}`,
    x._ask && `Question laissée : ${court(x._ask, 200)}`,
    x.question && `En attente de : ${court(x.question, 200)}`,
    x.plan?.length && `Plan : ${x.plan.map((p) => `${p.etat === 'completed' ? '[fait]' : p.etat === 'in_progress' ? '[en cours]' : '[à faire]'} ${p.quoi}`).join(' ; ')}`,
    x.commits?.length && `Commits : ${x.commits.slice(0, 6).join(' ; ')}`,
    x.nonCommite && `${x.nonCommite} fichier(s) modifié(s) non commité(s).`].filter(Boolean).join('\n');
}
const CONSIGNE = 'Tu racontes à quelqu’un qui n’est pas développeur ce qu’une session ou un agent de travail a fait, à partir de l’extrait donné. '
  + 'Réponds uniquement par un objet JSON {"fait":"…","rendu":"…","reste":"…"} : une ou deux phrases courtes chacune, en français courant, ton direct et impersonnel, '
  + 'termes techniques gardés mais simples. « fait » = ce qui a été fait ; « rendu » = ce qui a été livré ou répondu (fichier, commit, chiffre) ; '
  + '« reste » = ce qui reste à faire ou la question en attente, sinon « Rien. ». N’invente rien : ce que l’extrait ne dit pas, écris « non dit ».';

// Un appel à Haiku 5.5 · low, sans outils, sans serveurs MCP, sans réglages ni hooks, prompt système réduit (≈ 12 k jetons relus).
async function haiku(texte, systeme) {
  const t0 = Date.now();
  let sortie;
  try {
    ({ stdout: sortie } = await promisify(execFile)(CLAUDE, ['-p', texte, '--model', 'claude-haiku-5-5', '--effort', 'low', '--output-format', 'json', '--tools', '', '--strict-mcp-config',
      '--no-session-persistence', '--setting-sources', '', '--system-prompt', systeme], { encoding: 'utf8', timeout: 90000, cwd: CACHE, maxBuffer: 1 << 24 }));
  } catch (e) { return { erreur: `Haiku n’a pas répondu (${court(e.message, 120)}).` }; }
  let j; try { j = JSON.parse(sortie); } catch { return { erreur: 'Réponse de Haiku illisible.' }; }
  const u = j.usage || {};
  // Coût aux prix du dépôt (extraire.mjs), et celui que rapporte la CLI, pour comparer.
  return { brut: String(j.result || ''), ms: Date.now() - t0, date: new Date().toISOString(),
    jetons: (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.output_tokens || 0),
    cout: cout('haiku', u), coutCli: j.total_cost_usd ?? null, caracteres: texte.length };
}
async function enCache(cle, f, forcer) {
  const R = lireJSON(F_RESUMES, {});
  if (!forcer && R[cle]) return { ...R[cle], cache: true };
  const r = await f(); if (r.erreur) return r;
  const R2 = lireJSON(F_RESUMES, {}); R2[cle] = r; ecrireJSON(F_RESUMES, R2);
  return { ...r, cache: false };
}
const empreinte = (t) => crypto.createHash('sha1').update(t).digest('hex').slice(0, 16);

export async function recit(x, { forcer = false } = {}) {
  const ex = extrait(x);
  return enCache(empreinte(`${x.cle}\n${ex}`), async () => {
    const h = await haiku(ex, CONSIGNE); if (h.erreur) return h;
    const { brut, ...m } = h;
    let t; try { t = JSON.parse(brut.slice(brut.indexOf('{'), brut.lastIndexOf('}') + 1)); } catch { t = { fait: court(brut, 600), rendu: 'non dit', reste: 'non dit' }; }
    return { fait: t.fait || 'non dit', rendu: t.rendu || 'non dit', reste: t.reste || 'non dit', ...m };
  }, forcer);
}

// La phrase de tête réécrite par Haiku, une fois par famille (clé : chef + ids des filles et agents).
const CONSIGNE_PHRASE = 'Écris une seule phrase de 25 mots au plus, en français courant, qui dit ce que cette session orchestre : le chantier et ce qu’elle fait faire. '
  + 'Commence par « Orchestre ». Ton direct et impersonnel. N’invente rien. Réponds par la phrase seule.';
export async function phrase(D, { forcer = false } = {}) {
  const ex = [`Session « ${D.chef.titre} ».`,
    `Sessions lancées : ${D.sessions.filter((s) => s.profondeur > 0).slice(0, 25).map((s) => s.titre).join(' ; ') || 'aucune'}.`,
    `Agents : ${D.agents.slice(-25).map((a) => a.titre).join(' ; ') || 'aucun'}.`].filter(Boolean).join('\n');
  const cle = empreinte(`p:${D.chef.id}:${[...D.sessions.map((s) => s.id), ...D.agents.map((a) => a.id)].join(',')}`);
  return enCache(cle, async () => { const h = await haiku(ex, CONSIGNE_PHRASE); if (h.erreur) return h; const { brut, ...m } = h; return { texte: court(brut.replace(/^["«\s]+|["»\s]+$/g, ''), 260), ...m }; }, forcer);
}

// Ce que la page reçoit : les champs « _ » (extraits bruts) restent côté serveur.
const publier = (D) => JSON.parse(JSON.stringify(D, (k, v) => k.startsWith('_') ? undefined : v));

// ── Le serveur local : la page, les données d'un environnement, la liste des environnements, les récits.
function serveur() {
  const page = path.join(DEPOT, 'outils/bureau.html');
  const memo = new Map();   // dernier calcul par environnement, pour retrouver l'extrait d'un « voir plus »
  let derniere = Date.now();
  setInterval(() => { if (Date.now() - derniere > 3 * 36e5) process.exit(0); }, 60000).unref();
  const envoyer = (res, code, corps, type = 'application/json; charset=utf-8') => { res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store' }); res.end(typeof corps === 'string' ? corps : JSON.stringify(corps)); };
  http.createServer(async (req, res) => {
    derniere = Date.now();
    const u = new URL(req.url, 'http://x'); const q = Object.fromEntries(u.searchParams);
    try {
      if (u.pathname === '/') return envoyer(res, 200, fs.readFileSync(page, 'utf8'), 'text/html; charset=utf-8');
      if (u.pathname === '/api/ping') return envoyer(res, 200, { ok: true, depot: DEPOT, pid: process.pid, code: CODE });
      if (u.pathname === '/api/envs') return envoyer(res, 200, environnements());
      const env = q.c ? `c:${q.c}` : `s:${q.s || ''}`;
      if (u.pathname === '/api/env') { const D = donnees({ session: q.s, cli: q.c, moi: q.moi, dossier: q.d }); memo.set(env, D); return envoyer(res, 200, publier(D)); }
      const D = memo.get(env) || donnees({ session: q.s, cli: q.c, moi: q.moi, dossier: q.d }); memo.set(env, D);
      if (u.pathname === '/api/phrase') return envoyer(res, 200, D.erreur ? D : await phrase(D));
      if (u.pathname === '/api/recit') {
        const x = [...(D.sessions || []), ...(D.agents || [])].find((y) => y.cle === q.k);
        return x ? envoyer(res, 200, await recit(x, { forcer: q.forcer === '1' })) : envoyer(res, 404, { erreur: 'Introuvable dans cet environnement.' });
      }
      envoyer(res, 404, { erreur: 'inconnu' });
    } catch (e) { envoyer(res, 500, { erreur: court(e.message, 200) }); }
  }).listen(PORT, '127.0.0.1');
}

// ── `ouvrir` : calcule l'état (sortie texte pour le tour du modèle), lance le serveur s'il ne répond pas, ouvre la page.
async function ping() { try { const r = await fetch(`http://127.0.0.1:${PORT}/api/ping`, { signal: AbortSignal.timeout(800) }); return await r.json(); } catch { return null; } }
const repond = async () => { const p = await ping(); return p?.depot === DEPOT && p.code === CODE; };
async function ouvrir(dossier, session, sansOuvrir) {
  const t0 = Date.now();
  const D = donnees({ session, dossier });
  if (D.erreur) { console.log(D.erreur); return; }
  if (!(await repond())) {
    const vieux = await ping(); if (vieux?.pid) { try { process.kill(vieux.pid); } catch {} await new Promise((r) => setTimeout(r, 300)); }
    fs.mkdirSync(CACHE, { recursive: true });
    const log = fs.openSync(path.join(CACHE, 'bureau.log'), 'a');
    spawn(process.execPath, [fileURLToPath(import.meta.url), 'serveur'], { detached: true, stdio: ['ignore', log, log] }).unref();
    for (let i = 0; i < 30 && !(await repond()); i++) await new Promise((r) => setTimeout(r, 100));
  }
  const url = `http://127.0.0.1:${PORT}/?s=${encodeURIComponent(D.chef.id)}&moi=${encodeURIComponent(D.courante || '')}&d=${encodeURIComponent(dossier)}`;
  if (!sansOuvrir && !process.env.ORCH_SANS_OUVRIR) try { execFileSync('open', [url]); } catch {}
  const T = D.totaux; const e = (o) => Object.entries(o).map(([k, n]) => `${n} ${k}`).join(' · ');
  const $ = (n) => `${n.toFixed(2).replace('.', ',')} $`;
  console.log([`## 🪑 Bureau ouvert — ${D.chef.titre}`, '', D.phrase, '',
    '| | |', '|---|---|',
    `| **Sessions** | ${T.sessions}${T.sessions ? ` — ${e(T.etatsSessions)}` : ''} |`,
    `| **Agents** | ${T.agents}${T.agents ? ` — ${e(T.etatsAgents)}` : ''} |`,
    `| **Coût** | ${$(T.cout)}${T.coutPartiel ? ' (au moins)' : ''}, dont agents ${$(T.coutAgents)} |`,
    `| **Page** | ${url} |`, '',
    `Calculé en ${((Date.now() - t0) / 1000).toFixed(1).replace('.', ',')} s, sans modèle. Les récits « voir plus » passent par Haiku 5.5 · low, en cache.`].join('\n'));
}

const [CMD = 'ouvrir'] = args.filter((a) => !a.startsWith('--'));
if (process.argv[1] && fileURLToPath(import.meta.url) === fs.realpathSync(process.argv[1])) {
  const dossier = opt('--dossier') || process.cwd(); const session = opt('--session'); const cliId = opt('--cli'); const sansOuvrir = drapeau('--sans-ouvrir');
  if (CMD === 'serveur') serveur();
  else if (CMD === 'donnees') console.log(JSON.stringify(publier(donnees({ session, cli: cliId, dossier })), null, 1));
  else if (CMD === 'environnements') console.log(JSON.stringify(environnements(), null, 1));
  else await ouvrir(dossier, session, sansOuvrir);
}
export { PRIX };
