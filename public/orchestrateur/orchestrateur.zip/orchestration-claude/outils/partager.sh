#!/bin/bash
# Partage les perfs de ce Mac, avec accord à chaque fois.
# 1. relit les transcriptions Claude Code depuis le dernier partage (outils/extraire.mjs) ;
# 2. montre ce qui partirait : nombre de sessions, totaux, champs — aucun texte de conversation ;
# 3. demande oui / non (fenêtre macOS si lancé par la tâche mensuelle, question dans le terminal sinon) ;
# 4. sur oui seulement : commit et push de perfs/<compte>/historique.jsonl.
# Usage : outils/partager.sh [--depuis AAAA-MM-JJ]
set -euo pipefail
cd "$(dirname "$0")/.."
DEPOT=$(pwd)
COMPTE=$(cat perfs/.compte 2>/dev/null || whoami)
ETAT=perfs/.dernier-partage
DEPUIS=$(cat "$ETAT" 2>/dev/null || date -v-31d +%F)
[ "${1:-}" = "--depuis" ] && DEPUIS=$2
NODE=$(command -v node || echo /usr/local/bin/node)

git pull -q --rebase 2>/dev/null || true
TMP=$(mktemp -d)
"$NODE" outils/extraire.mjs --depuis "$DEPUIS" --compte "$COMPTE" --sortie "$TMP/nouveau.jsonl" >/dev/null 2>&1
N=$(grep -c . "$TMP/nouveau.jsonl" || true)
if [ "$N" = "0" ]; then echo "Rien de neuf depuis le $DEPUIS."; exit 0; fi

APERCU=$("$NODE" -e '
const L=require("fs").readFileSync(process.argv[1],"utf8").trim().split("\n").map(JSON.parse);
const s=(f)=>L.reduce((a,x)=>a+f(x),0);
console.log(`${L.length} sessions du ${process.argv[2]} à aujourd’hui · ${Math.round(s(x=>x.cout))} $ (prix publics)
${s(x=>x.sessions_lancees.length)} sessions lancées · ${s(x=>x.agents.length)} agents · ${L.filter(x=>x.contexte_max>300000).length} sessions > 300 k jetons
Ce qui part : chiffres (jetons, coût, modèle, effort, nombre d’outils, erreurs) et noms de projet hachés.
Ce qui ne part pas : aucun message, aucun prompt, aucun nom de fichier.`)' "$TMP/nouveau.jsonl" "$DEPUIS")

echo "$APERCU"
if [ -n "${ORCH_REPONSE:-}" ]; then R=$ORCH_REPONSE   # pour les essais
elif [ -t 0 ]; then
  read -rp "Partager ces chiffres avec le dépôt orchestration-claude ? [o/N] " R
else
  R=$(osascript -e "button returned of (display dialog \"$APERCU\" with title \"Orchestration — partager les perfs du mois ?\" buttons {\"Non\", \"Voir le détail\", \"Partager\"} default button \"Partager\")" 2>/dev/null || echo Non)
  if [ "$R" = "Voir le détail" ]; then open -a TextEdit "$TMP/nouveau.jsonl"
    R=$(osascript -e 'button returned of (display dialog "Partager après lecture ?" buttons {"Non", "Partager"} default button "Non")' 2>/dev/null || echo Non); fi
  [ "$R" = "Partager" ] && R=o
fi
case "$R" in o|O|oui|y|Y) ;; *) echo "Rien n'est parti."; exit 0 ;; esac

# Installé depuis le zip du site (pas de dépôt git où pousser) : le fichier se dépose dans ~/Downloads.
if ! git rev-parse --git-dir >/dev/null 2>&1 || ! git ls-remote -q origin >/dev/null 2>&1; then
  F=~/Downloads/orchestration-perfs-$COMPTE-$(date +%F).jsonl
  cp "$TMP/nouveau.jsonl" "$F"; date +%F > "$ETAT"; rm -rf "$TMP"
  echo "Fichier prêt : $F — à envoyer à la personne qui vous a partagé le skill."
  [ -t 0 ] || open -R "$F"
  exit 0
fi
mkdir -p "perfs/$COMPTE"
# Une session déjà partagée et mise à jour depuis remplace sa fiche précédente.
"$NODE" -e '
const fs=require("fs"),[ancien,nouveau]=process.argv.slice(1);
const lire=f=>fs.existsSync(f)?fs.readFileSync(f,"utf8").split("\n").filter(Boolean):[];
const m=new Map();for(const l of [...lire(ancien),...lire(nouveau)])m.set(JSON.parse(l).session,l);
fs.writeFileSync(ancien,[...m.values()].join("\n")+"\n");' "perfs/$COMPTE/historique.jsonl" "$TMP/nouveau.jsonl"
date +%F > "$ETAT"
git add "perfs/$COMPTE/historique.jsonl"
git commit -qm "perfs : $COMPTE partage $N sessions depuis le $DEPUIS"
(git pull -q --rebase && git push -q) && echo "Partagé : $N sessions." || echo "Commité ici, envoi à refaire : git push"
rm -rf "$TMP"
