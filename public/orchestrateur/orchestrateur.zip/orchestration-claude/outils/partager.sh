#!/bin/bash
# Partage les perfs de ce Mac, avec accord à chaque fois.
# 1. relit les transcriptions Claude Code depuis le dernier partage (outils/extraire.mjs) ;
# 2. montre ce qui partirait : nombre de sessions, totaux, champs — aucun texte de conversation ;
# 3. demande oui / non (fenêtre macOS si lancé par la tâche mensuelle, question dans le terminal sinon) ;
# 4. sur oui seulement, envoie :
#    - clone du dépôt avec droit d'écriture : commit et push de perfs/<compte>/historique.jsonl ;
#    - sinon (installé depuis le zip du site), ou si GitHub ne répond pas : POST vers la réception du site
#      ($ORCH_RECEPTION), que le Mac analyste rapatrie dans le dépôt (outils/rapatrier.sh) ;
#    - si rien ne passe : rien n'est marqué comme partagé, le mois sera reproposé ; une copie reste dans ~/Downloads.
# Usage : outils/partager.sh [--depuis AAAA-MM-JJ]
set -euo pipefail
cd "$(dirname "$0")/.."
DEPOT=$(pwd)
COMPTE=$(cat perfs/.compte 2>/dev/null || whoami)
ETAT=perfs/.dernier-partage
DEPUIS=$(cat "$ETAT" 2>/dev/null || date -v-31d +%F)
[ "${1:-}" = "--depuis" ] && DEPUIS=$2
NODE=$(command -v node || echo /usr/local/bin/node)
RECEPTION=${ORCH_RECEPTION:-https://apps.srv875929.hstgr.cloud/api/perfs}
# La clé attache le nom du compte à cette installation sur la réception ; tirée une fois, jamais partagée ailleurs.
[ -s perfs/.cle ] || { mkdir -p perfs; openssl rand -hex 16 > perfs/.cle; }
CLE=$(cat perfs/.cle)
dire() { echo "$1"; [ -t 0 ] || osascript -e "display notification \"$1\" with title \"Orchestration — partage\"" 2>/dev/null || true; }
# Envoie le lot à la réception du site ; vrai si elle l'a accepté.
envoyer() {
  local code
  code=$(curl -sS -o "$TMP/reponse" -w '%{http_code}' --max-time 120 --retry 3 --retry-delay 20 --retry-all-errors \
    -H "x-compte: $COMPTE" -H "x-cle: $CLE" -H 'content-type: application/x-ndjson' \
    --data-binary @"$TMP/nouveau.jsonl" "$RECEPTION" 2>>"$TMP/erreurs") || code=000
  [ "$code" = 200 ] && return 0
  echo "réception : HTTP $code $(cat "$TMP/reponse" 2>/dev/null)" >>"$TMP/erreurs"; return 1
}

git pull -q --rebase 2>/dev/null || true
TMP=$(mktemp -d)
"$NODE" outils/extraire.mjs --depuis "$DEPUIS" --compte "$COMPTE" --sortie "$TMP/nouveau.jsonl" >/dev/null 2>&1
N=$(grep -c . "$TMP/nouveau.jsonl" || true)
if [ "$N" = "0" ]; then echo "Rien de neuf depuis le $DEPUIS."; exit 0; fi

APERCU=$("$NODE" -e '
const L=require("fs").readFileSync(process.argv[1],"utf8").trim().split("\n").map(JSON.parse);
const s=(f)=>L.reduce((a,x)=>a+f(x),0);
console.log(`${L.length} sessions du ${process.argv[2]} à aujourd’hui · ${Math.round(s(x=>x.cout))} $ (prix publics)
${s(x=>x.sessions_lancees.length)} sessions lancées · ${s(x=>x.agents.length)} agents · ${L.filter(x=>x.contexte_max>300000).length} sessions > 300 k jetons
Ce qui part : chiffres (jetons, coût, modèle, effort, nombre d’outils, erreurs) et noms de projet hachés.
Ce qui ne part pas : aucun message, aucun prompt, aucun nom de fichier.`)' "$TMP/nouveau.jsonl" "$DEPUIS")

echo "$APERCU"
if [ -n "${ORCH_REPONSE:-}" ]; then R=$ORCH_REPONSE   # pour les essais
elif [ -t 0 ]; then
  read -rp "Partager ces chiffres avec le dépôt orchestration-claude ? [o/N] " R
else
  R=$(osascript -e "button returned of (display dialog \"$APERCU\" with title \"Orchestration — partager les perfs du mois ?\" buttons {\"Non\", \"Voir le détail\", \"Partager\"} default button \"Partager\")" 2>/dev/null || echo Non)
  if [ "$R" = "Voir le détail" ]; then open -a TextEdit "$TMP/nouveau.jsonl"
    R=$(osascript -e 'button returned of (display dialog "Partager après lecture ?" buttons {"Non", "Partager"} default button "Non")' 2>/dev/null || echo Non); fi
  [ "$R" = "Partager" ] && R=o
fi
case "$R" in o|O|oui|y|Y) ;; *) echo "Rien n'est parti."; exit 0 ;; esac

# Clone avec droit d'écriture : on pousse dans le dépôt. Un commit resté en attente d'un mois précédent part aussi.
if git rev-parse --git-dir >/dev/null 2>&1 && git ls-remote -q origin >/dev/null 2>>"$TMP/erreurs"; then
  mkdir -p "perfs/$COMPTE"
  # Une session déjà partagée et mise à jour depuis remplace sa fiche précédente, sans jamais la réduire.
  "$NODE" -e '
const fs=require("fs"),[ancien,nouveau]=process.argv.slice(1);
const lire=f=>fs.existsSync(f)?fs.readFileSync(f,"utf8").split("\n").filter(Boolean):[];
// Par session, la fiche la plus complète (le plus de tours) gagne ; à égalité, la plus récente.
const m=new Map();for(const l of [...lire(ancien),...lire(nouveau)]){const x=JSON.parse(l),p=m.get(x.session);if(!p||(x.tours||0)>=(JSON.parse(p).tours||0))m.set(x.session,l);}
fs.writeFileSync(ancien,[...m.values()].join("\n")+"\n");' "perfs/$COMPTE/historique.jsonl" "$TMP/nouveau.jsonl"
  git add "perfs/$COMPTE/historique.jsonl"
  git commit -qm "perfs : $COMPTE partage $N sessions depuis le $DEPUIS" || true
  for i in 1 2 3; do
    if git pull -q --rebase 2>>"$TMP/erreurs" && git push -q 2>>"$TMP/erreurs"; then
      date +%F > "$ETAT"; dire "Partagé : $N sessions, poussées dans le dépôt."; rm -rf "$TMP"; exit 0; fi
    sleep 20
  done
  echo "push refusé, passage par la réception du site" >>"$TMP/erreurs"
fi

if envoyer; then
  date +%F > "$ETAT"; dire "Partagé : $N sessions, reçues par le site."; rm -rf "$TMP"; exit 0
fi

# Rien n'est passé : la date du dernier partage ne bouge pas, le mois sera reproposé.
F=~/Downloads/orchestration-perfs-$COMPTE-$(date +%F).jsonl
cp "$TMP/nouveau.jsonl" "$F"
mkdir -p ~/.cache/orchestration && cp "$TMP/erreurs" ~/.cache/orchestration/partage-erreurs.log 2>/dev/null || true
cat "$TMP/erreurs" 2>/dev/null
dire "Envoi impossible (réseau ?). Rien n'est marqué partagé : relancer outils/partager.sh. Copie : $F"
[ -t 0 ] || open -R "$F"
[ -x ~/pboard/outils/notifier.sh ] && ~/pboard/outils/notifier.sh "Partage des perfs du mois : envoi impossible, a relancer" "Orchestration" high >/dev/null 2>&1 || true
rm -rf "$TMP"
exit 1
