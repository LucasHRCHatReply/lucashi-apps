#!/usr/bin/env node
// Le skill sert-il ? Compare trois périodes de ce Mac — avant le skill, la règle et le skill v0, le skill
// automatique (v1.2) — sur des mesures rapportées au travail fait (par message humain, par tour, par agent),
// pour que le volume de travail de la période ne fausse pas la lecture.
// Entrée : les fiches de outils/extraire.mjs (node outils/extraire.mjs --depuis 2026-09-15 --sortie f.jsonl).
// Usage : node outils/utilite.mjs f.jsonl [--min 3]   (--min : messages humains minimum, 3 écarte les appels de script)
import fs from 'node:fs';
const MIN = +(process.argv[process.argv.indexOf('--min') + 1] || 0) || (process.argv.includes('--min') ? 0 : 3);
const F = fs.readFileSync(process.argv[2] || 'perfs/' + fs.readFileSync('perfs/.compte', 'utf8').trim() + '/historique.jsonl', 'utf8').trim().split('\n').map(l => JSON.parse(l));
const P = [['avant le skill', '2026-09-15', '2026-10-20'], ['règle + skill v0', '2026-10-20', '2026-10-30'], ['skill v1.2 auto', '2026-10-30', new Date(Date.now() + 864e5).toISOString().slice(0, 10)]];
const med = a => { a = [...a].sort((x, y) => x - y); return a.length ? a[a.length >> 1] : 0; };
// Dénominateur nul ou chiffre non fini : n/a, jamais « Infinity $ » ni « NaN $ ».
const usd = (a, b, d = 2) => b > 0 && Number.isFinite(a / b) ? (a / b).toFixed(d) + ' $' : 'n/a';
const pc = (a, b) => b ? (100 * a / b).toFixed(1) + ' %' : 'n/a';
const ligne = {};
for (const [nom, d, f] of P) {
  const S = F.filter(s => s.debut >= d && s.debut < f && s.messages_humains >= MIN);
  const jours = (Math.min(new Date(f), Date.now()) - new Date(d)) / 864e5;
  const cout = S.reduce((x, s) => x + s.cout, 0), hum = S.reduce((x, s) => x + s.messages_humains, 0);
  const corr = S.reduce((x, s) => x + s.corrections, 0);
  const lance = S.filter(s => s.sessions_lancees.length + s.agents.length > 0);
  const seules = S.filter(s => !s.sessions_lancees.length && !s.agents.length);
  const opusSeul = seules.filter(s => s.modele === 'opus');
  const ag = S.flatMap(s => s.agents); const agMod = ag.filter(a => a.modele !== 'hérité');
  const ss = S.flatMap(s => s.sessions_lancees); const ssMod = ss.filter(x => x.modele !== 'défaut');
  const reels = {}; for (const s of S) for (const [k, v] of Object.entries(s.agents_reels || {})) reels[k] = (reels[k] || 0) + v;
  const nr = Object.values(reels).reduce((x, y) => x + y, 0);
  const gros = S.filter(s => s.contexte_max > 300000);
  const orch = S.filter(s => s.sessions_lancees.length > 0);
  ligne[nom] = {
    'sessions (avec un humain)': S.length, 'jours': jours.toFixed(1),
    'coût total': cout.toFixed(0) + ' $', 'coût par jour': usd(cout, jours, 0),
    'coût médian par session': S.length ? med(S.map(s => s.cout)).toFixed(2) + ' $' : 'n/a',
    'coût par message humain': usd(cout, hum),
    'part du coût dans les agents': pc(S.reduce((x, s) => x + s.cout_agents, 0), cout),
    'sessions seules sur Opus': pc(opusSeul.length, seules.length),
    'agents lancés': ag.length, 'agents avec modèle explicite': pc(agMod.length, ag.length),
    'tours d\'agents sur Haiku': pc(reels.haiku || 0, nr), 'tours d\'agents sur Opus': pc(reels.opus || 0, nr),
    'sessions lancées': ss.length, 'sessions lancées avec modèle': pc(ssMod.length, ss.length),
    'orchestrations avec annonce modèle · effort': pc(orch.filter(s => s.annonces_modele_effort > 0).length, orch.length),
    'sessions au-delà de 300 k': pc(gros.length, S.length),
    'tours au-delà de 300 k': pc(S.reduce((x, s) => x + s.tours_au_dela_300k, 0), S.reduce((x, s) => x + s.tours, 0)),
    'grosses sessions avec note de reprise': pc(gros.filter(s => s.notes_reprise > 0).length, gros.length),
    'corrections pour 100 messages': hum > 0 ? (100 * corr / hum).toFixed(1) : 'n/a',
    // Verdict du hook Stop, recalculé par extraire.mjs (fiches de 02/11/2026 et après seulement)
    ...(S.some(s => s.verdict) ? {
      'verdict réussi sans correction': pc(S.filter(s => s.verdict === 'reussi').length, S.length),
      'verdict échec (tests rouges à la fin)': pc(S.filter(s => s.verdict === 'echec').length, S.length),
      'sans preuve (ni test ni commit)': pc(S.filter(s => s.verdict === 'n/a').length, S.length),
      'sessions qui lancent des tests': pc(S.filter(s => s.series_tests > 0).length, S.length),
      ...(S.some(s => 'modifs_code' in s) ? { 'code modifié non retesté à la fin': pc(S.filter(s => s.code_sans_test_a_la_fin > 0).length, S.filter(s => s.modifs_code > 0).length) } : {}) } : {}),
    'lancements refusés': S.reduce((x, s) => x + s.sessions_refusees, 0),
  };
}
const cles = Object.keys(Object.values(ligne)[0]);
console.log('| Mesure | ' + P.map(p => `${p[0]} (${p[1].slice(5)} → ${p[2].slice(5)})`).join(' | ') + ' |');
console.log('|---|' + P.map(() => '---|').join(''));
for (const k of cles) console.log(`| ${k} | ` + P.map(p => ligne[p[0]][k]).join(' | ') + ' |');
