#!/usr/bin/env node
// Rejoue chaque réponse facturée de ce Mac (conversation et agents) sous deux règles du skill,
// avec les mêmes jetons, pour chiffrer ce qu'elles auraient économisé :
//   A. Opus réservé aux sessions qui orchestrent (elles lancent des sessions) ; ailleurs, Sonnet
//      au même nombre de jetons (le banc du 20/10 : Opus n'a battu Sonnet sur aucune des 11 tâches).
//   B. Relance à 300 k jetons de contexte avec une note de reprise : le contexte relu retombe à
//      100 k puis remonte (dents de scie 100 k → 300 k) ; chaque relance paie 100 k jetons écrits.
// Ce n'est pas une facture : prix publics, et l'hypothèse « mêmes jetons » est prudente
// (une session relancée répond aussi plus vite, Sonnet écrit souvent moins).
//
// Usage : node outils/simuler.mjs [--depuis 2026-10-20] [--jusqu 2026-10-29] [--json]
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { PRIX, famille, cout, lire } from './extraire.mjs';

const arg = (n, d) => { const i = process.argv.indexOf(n); return i > 0 ? process.argv[i + 1] : d; };
const DEPUIS = arg('--depuis', '2026-10-20');
const JUSQU = arg('--jusqu', '2099-12-31') + 'T23:59:59Z';
const RACINE = path.join(os.homedir(), '.claude/projects');
const SEUIL = 300000, BAS = 100000;

const total = { reel: 0, a: 0, b: 0, ab: 0, sessions: 0, orchestrations: 0, relances: 0,
  parFamille: {}, opusHorsOrch: 0, au300k: 0 };
const ajoute = (k, f, v) => { total.parFamille[f] ??= { reel: 0, a: 0, b: 0, ab: 0 }; total.parFamille[f][k] += v; };

function rejoue(messages, orchestre) {
  let relances = 0, dernierPalier = 0;
  for (const { f, u } of messages) {
    const reel = cout(f, u);
    const fa = f === 'opus' && !orchestre ? 'sonnet' : f;
    const a = cout(fa, u);
    const ctx = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    let b = reel, ab = a;
    if (ctx > SEUIL) {
      total.au300k += reel;
      const palier = Math.floor((ctx - SEUIL) / (SEUIL - BAS)) + 1;
      const sim = BAS + (ctx - SEUIL) % (SEUIL - BAS);
      const k = sim / ctx;
      const lu = x => ({ ...u, input_tokens: (u.input_tokens || 0) * k, cache_read_input_tokens: (u.cache_read_input_tokens || 0) * k, cache_creation_input_tokens: (u.cache_creation_input_tokens || 0) * k });
      b = cout(f, lu()); ab = cout(fa, lu());
      if (palier > dernierPalier) { // une relance : 100 k jetons réécrits en cache
        const ecrit = { cache_creation_input_tokens: BAS };
        b += cout(f, ecrit); ab += cout(fa, ecrit); relances += palier - dernierPalier; dernierPalier = palier;
      }
    }
    total.reel += reel; total.a += a; total.b += b; total.ab += ab;
    ajoute('reel', f, reel); ajoute('a', f, a); ajoute('b', f, b); ajoute('ab', f, ab);
    if (f === 'opus' && !orchestre) total.opusHorsOrch += reel;
  }
  return relances;
}

async function messagesDe(fichier) {
  const out = []; const vus = new Map(); let orchestre = false;   // une réponse = plusieurs lignes, seule la plus longue compte
  await lire(fichier, ev => {
    if (ev.timestamp && (ev.timestamp < DEPUIS || ev.timestamp > JUSQU)) return;
    const m = ev.message; if (ev.type !== 'assistant' || !m) return;
    for (const c of Array.isArray(m.content) ? m.content : []) if (c.type === 'tool_use' && /start_session$/.test(c.name)) orchestre = true;
    if (!m.usage) return; const i = m.id && vus.get(m.id);
    if (i != null) { if ((m.usage.output_tokens || 0) > (out[i].u.output_tokens || 0)) out[i].u = m.usage; return; }
    if (m.id) vus.set(m.id, out.length); out.push({ f: famille(m.model), u: m.usage });
  });
  return { out, orchestre };
}

for (const d of fs.readdirSync(RACINE)) {
  const p = path.join(RACINE, d); if (!fs.statSync(p).isDirectory()) continue;
  for (const f of fs.readdirSync(p)) if (f.endsWith('.jsonl')) {
    const fp = path.join(p, f); if (fs.statSync(fp).mtime.toISOString().slice(0, 10) < DEPUIS) continue;
    const { out, orchestre } = await messagesDe(fp);
    if (!out.length) continue;
    total.sessions++; if (orchestre) total.orchestrations++;
    total.relances += rejoue(out, orchestre);
    const sub = path.join(fp.replace(/\.jsonl$/, ''), 'subagents');
    // Un agent repart d'un contexte neuf : seule la règle A le concerne (il hérite du statut de sa session).
    if (fs.existsSync(sub)) for (const g of fs.readdirSync(sub)) if (g.endsWith('.jsonl')) rejoue((await messagesDe(path.join(sub, g))).out, orchestre);
  }
}

const r = x => Math.round(x);
const pc = x => Math.round(100 * (1 - x / total.reel));
const res = { depuis: DEPUIS, jusqu: JUSQU.slice(0, 10), sessions: total.sessions, orchestrations: total.orchestrations,
  reel: r(total.reel), regleA: r(total.a), regleB: r(total.b), lesDeux: r(total.ab),
  economieA: pc(total.a), economieB: pc(total.b), economie: pc(total.ab),
  opusHorsOrchestration: r(total.opusHorsOrch), coutAuDela300k: r(total.au300k), relances: total.relances,
  parFamille: Object.fromEntries(Object.entries(total.parFamille).map(([k, v]) => [k, Object.fromEntries(Object.entries(v).map(([a, b]) => [a, r(b)]))])) };
if (process.argv.includes('--json')) console.log(JSON.stringify(res, null, 1));
else {
  console.log(`${res.sessions} sessions du ${res.depuis} au ${res.jusqu} (${res.orchestrations} orchestrations)\n`);
  console.log(`| Scénario | Coût | Économie |\n|---|---|---|`);
  console.log(`| Réel | ${res.reel} $ | — |`);
  console.log(`| A. Opus seulement pour orchestrer, Sonnet ailleurs | ${res.regleA} $ | ${res.economieA} % |`);
  console.log(`| B. Relance à 300 k avec note de reprise (${res.relances} relances) | ${res.regleB} $ | ${res.economieB} % |`);
  console.log(`| A + B | ${res.lesDeux} $ | ${res.economie} % |`);
  console.log(`\nOpus hors orchestration : ${res.opusHorsOrchestration} $ · coût des réponses au-delà de 300 k : ${res.coutAuDela300k} $`);
}
