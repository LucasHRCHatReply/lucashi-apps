# Orchestration Claude — le skill « prompt master » (v1.7)

Un skill Claude Code qui fait d'une session l'**orchestratrice** d'un chantier : elle découpe, lance de
**vraies sessions** (pas seulement des agents) avec pour chacune le modèle et l'effort les plus bas qui
suffisent, les suit, les relance quand elles grossissent, et rend un résultat qu'on peut ouvrir.

Les règles viennent de vrais chantiers d'octobre 2026 et sont **mesurées** : la v1.0 corrige ce qu'ont
montré 785 sessions (voir `CHANGELOG.md`). Le défaut n° 1 : à « lance des sessions », Claude faisait des
agents ou rien, faute de savoir que l'outil de session est différé et doit être chargé d'abord.

## Installer en plugin (voie officielle)

Dans Claude Code : `/plugin marketplace add LucasHRCHatReply/orchestrateur-releases` puis `/plugin install orchestrateur@orchestration`.
Le dépôt public est fabriqué par `outils/plugin.sh` (`--publier` à chaque nouvelle version) ; le plugin n'a ni tâche
mensuelle, ni partage, ni skill `retour`, et ses données s'écrivent dans `~/.cache/orchestration/donnees` (`outils/donnees.mjs`).

## Installer par le zip (2 minutes)

```bash
curl -fsSL https://apps.srv875929.hstgr.cloud/orchestrateur/orchestrateur.zip -o /tmp/orchestrateur.zip
unzip -oq /tmp/orchestrateur.zip -d ~ && ~/orchestration-claude/install.sh ton-prenom
```

La page du skill (https://apps.srv875929.hstgr.cloud/orchestrateur/) donne aussi un prompt à coller dans
Claude Code, qui télécharge, lit le script et installe. Le dépôt GitHub est privé : `git clone` ne sert
qu'à un compte invité.

L'installation finit par une page d'accueil écrite par Claude sur vos 30 derniers jours.
Puis, dans Claude Code (de préférence l'app de bureau, onglet Code) : « orchestre ce chantier : … » ou `/orchestrateur`,
et `/orch` pour le tableau de bord (`/orch sessions`, `poids`, `cout`, `regles`, `bilan`, `conseil`, `accueil`).

`/orch ranger` range une orchestration : il liste toutes les sessions de la famille (état, âge, mémoire vive,
contexte, coût, travail non commité, question en attente), propose archiver / garder / relancer, écrit une note
de reprise par session (fait et commits, reste à faire, comment reprendre) puis archive après **un seul oui**, et
finit par la mémoire vive rendue. Il n'archive jamais une session qui travaille, attend une réponse ou surveille encore (Monitor, cron, réveil).
`/orch ranger tout --reprise-dans <session>` écrit une note de reprise par session de la famille et une note commune, pour tout reprendre dans la session active avant d'archiver le reste.

`/sessiondesk` ouvre une page locale qui montre ce qu'orchestre la session : ses sous-sessions et ses agents à leur poste (mode Bureau), en tableaux (mode Liste) ou sur une frise (mode Temps), avec état, modèle · effort, coût (relevé de Claude Code quand il existe) et contexte. « Voir plus » raconte en français ce que chacun a fait, rendu et laissé (Haiku 5.5 · low, en cache). Le menu du haut passe aux autres orchestrations du Mac.
Avec 22 sessions vivantes, un Mac de 24 Go portait 4,47 Go de processus `claude` et 5,9 Go de swap ;
une session finie au repos pèse 140 à 250 Mo (mesure du 30/10/2026, `ps`).

`install.sh` pose : les skills (`orchestrateur`, `point`, `pause`, `reprise`, `retour`) en liens vers ce dépôt
(un `git pull` les met à jour ; un skill du même nom déjà chez vous est gardé), le hook qui rappelle de
relancer une session trop lourde, et une tâche mensuelle de partage (ci-dessous).

## Ce qu'on partage, et comment on l'améliore

| Quand | Qui | Quoi |
|---|---|---|
| Le 1er du mois, 10 h | chaque Mac | une fenêtre montre l'aperçu des chiffres du mois ; **rien ne part sans « Partager »** ; après « Partager », l'envoi est automatique (push dans ce dépôt, sinon réception du site) |
| Le 2 du mois, 10 h | le Mac qui a `perfs/.vps` (`--rapatrier` ou `--analyste`) | rapatrie dans ce dépôt les perfs reçues par le site |
| Le 3 du mois, 9 h | le Mac analyste (`./install.sh <nom> --analyste`) | synthèse de tous les comptes + proposition de v suivante du skill en PR |
| À la relecture de la PR | les humains | on garde, on corrige ou on ferme |

**Ce qui part** : par session, des chiffres (jetons, coût recalculé, modèle, effort, nombre de sessions et
d'agents lancés, refus d'outils, poids du contexte, corrections comptées) et le nom du projet **haché**.
**Ce qui ne part jamais** : messages, prompts, réponses, noms de fichiers. Vérifiable avant envoi
(« Voir le détail ») ou à la main : `outils/partager.sh` dans un terminal.

## Contenu

| Chemin | Rôle |
|---|---|
| `skills/orchestrateur/SKILL.md` | le skill : diagnostic, lancer une session (app ou terminal), modèle · effort, brief, suivi, poids, fin |
| `skills/orchestrateur/references/` | les règles d'origine avec leurs mesures |
| `skills/orch`, `outils/etat.mjs` | le tableau de bord `/orch` et ses sous-commandes |
| `outils/ranger.mjs` | `/orch ranger` : inventaire de la famille, mémoire par `ps`, notes de reprise, bilan |
| `skills/sessiondesk`, `outils/bureau.mjs`, `outils/bureau.html` | `/sessiondesk` : la page locale du bureau (Bureau / Liste / Temps, « voir plus » raconté par Haiku en cache, autres orchestrations du Mac) |
| `outils/accueil.mjs` | la page d'accueil écrite par Claude |
| `skills/point`, `pause`, `reprise`, `retour` | point toutes les 5 min, pause/reprise propres, retour qualitatif facultatif |
| `hooks/poids-de-session.mjs` | rappel à 200 000 / 300 000 jetons de contexte |
| `outils/extraire.mjs` | relit `~/.claude/projects` et produit les fiches de perfs (aucun texte) |
| `outils/partager.sh` | aperçu → accord → envoi (push, sinon `POST /api/perfs` du site) |
| `outils/rapatrier.sh` | lots reçus par le site → `perfs/<compte>/historique.jsonl` (hors du zip public) |
| `outils/analyse-mensuelle.sh`, `outils/prompt-amelioration.md` | la passe mensuelle (Opus · medium, en PR) |
| `perfs/<compte>/historique.jsonl`, `perfs/SYNTHESE.md` | les fiches partagées et leur synthèse |
| `CHANGELOG.md`, `apprentissages/` | ce qui a changé, avec le chiffre qui le justifie |

## Prérequis

macOS, Claude Code (`claude` dans le PATH), Node 18+, `git` ; `gh` sur le Mac analyste seulement.
Notifications téléphone facultatives : `export ORCH_NOTIFIER=/chemin/vers/un-script "message" "titre"`.
