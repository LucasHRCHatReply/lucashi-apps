# Orchestration Claude — le skill « prompt master » (v1.1)

Un skill Claude Code qui fait d'une session l'**orchestratrice** d'un chantier : elle découpe, lance de
**vraies sessions** (pas seulement des agents) avec pour chacune le modèle et l'effort les plus bas qui
suffisent, les suit, les relance quand elles grossissent, et rend un résultat qu'on peut ouvrir.

Les règles viennent de vrais chantiers d'octobre 2026 et sont **mesurées** : la v1.0 corrige ce qu'ont
montré 785 sessions (voir `CHANGELOG.md`). Le défaut n° 1 : à « lance des sessions », Claude faisait des
agents ou rien, faute de savoir que l'outil de session est différé et doit être chargé d'abord.

## Installer (2 minutes)

```bash
git clone https://github.com/LucasHRCHatReply/orchestration-claude.git ~/orchestration-claude
cd ~/orchestration-claude && ./install.sh ton-prenom
```

Ou sans git : télécharger le zip depuis la page du skill sur le site des apps, le décompresser dans
`~/orchestration-claude`, puis `./install.sh ton-prenom`.

L'installation finit par une page d'accueil écrite par Claude sur vos 30 derniers jours.
Puis, dans Claude Code (de préférence l'app de bureau, onglet Code) : « orchestre ce chantier : … » ou `/orchestrateur`,
et `/orch` pour le tableau de bord (`/orch sessions`, `poids`, `cout`, `regles`, `bilan`, `conseil`, `accueil`).

`install.sh` pose : les skills (`orchestrateur`, `point`, `pause`, `reprise`, `retour`) en liens vers ce dépôt
(un `git pull` les met à jour ; un skill du même nom déjà chez vous est gardé), le hook qui rappelle de
relancer une session trop lourde, et une tâche mensuelle de partage (ci-dessous).

## Ce qu'on partage, et comment on l'améliore

| Quand | Qui | Quoi |
|---|---|---|
| Le 1er du mois, 10 h | chaque Mac | une fenêtre montre l'aperçu des chiffres du mois ; **rien ne part sans « Partager »** |
| Le 3 du mois, 9 h | le Mac analyste (`./install.sh <nom> --analyste`) | synthèse de tous les comptes + proposition de v suivante du skill en PR |
| À la relecture de la PR | les humains | on garde, on corrige ou on ferme |

**Ce qui part** : par session, des chiffres (jetons, coût recalculé, modèle, effort, nombre de sessions et
d'agents lancés, refus d'outils, poids du contexte, corrections comptées) et le nom du projet **haché**.
**Ce qui ne part jamais** : messages, prompts, réponses, noms de fichiers. Vérifiable avant envoi
(« Voir le détail ») ou à la main : `outils/partager.sh` dans un terminal.

## Contenu

| Chemin | Rôle |
|---|---|
| `skills/orchestrateur/SKILL.md` | le skill : diagnostic, lancer une session (app ou terminal), modèle · effort, brief, suivi, poids, fin |
| `skills/orchestrateur/references/` | les règles d'origine avec leurs mesures |
| `skills/orch`, `outils/etat.mjs` | le tableau de bord `/orch` et ses sous-commandes |
| `outils/accueil.mjs` | la page d'accueil écrite par Claude |
| `skills/point`, `pause`, `reprise`, `retour` | point toutes les 5 min, pause/reprise propres, retour qualitatif facultatif |
| `hooks/poids-de-session.mjs` | rappel à 200 000 / 300 000 jetons de contexte |
| `outils/extraire.mjs` | relit `~/.claude/projects` et produit les fiches de perfs (aucun texte) |
| `outils/partager.sh` | aperçu → accord → envoi |
| `outils/analyse-mensuelle.sh`, `outils/prompt-amelioration.md` | la passe mensuelle (Opus · medium, en PR) |
| `perfs/<compte>/historique.jsonl`, `perfs/SYNTHESE.md` | les fiches partagées et leur synthèse |
| `CHANGELOG.md`, `apprentissages/` | ce qui a changé, avec le chiffre qui le justifie |

## Prérequis

macOS, Claude Code (`claude` dans le PATH), Node 18+, `git` ; `gh` sur le Mac analyste seulement.
Notifications téléphone facultatives : `export ORCH_NOTIFIER=/chemin/vers/un-script "message" "titre"`.
