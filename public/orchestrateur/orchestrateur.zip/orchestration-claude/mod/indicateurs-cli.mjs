#!/usr/bin/env node
// Sortie JSON des indicateurs du bandeau : node mod/indicateurs-cli.mjs [--session local_…] [--dossier chemin]
import { charger } from './indicateurs.mjs';
const a = process.argv.slice(2); const opt = (n) => { const i = a.indexOf(n); return i >= 0 ? a[i + 1] : undefined; };
try { console.log(JSON.stringify(await charger({ session: opt('--session'), dossier: opt('--dossier') }))); }
catch (e) { console.log(JSON.stringify({ erreur: String(e.message || e).slice(0, 200), date: Date.now() })); }
