// Les indicateurs du bandeau d'orchestration (extension de l'app de bureau, onglet Code).
// `calculer` est pur : il reçoit les données déjà lues (celles de outils/bureau.mjs `donnees`, les attentes, le relevé de poids,
// le verdict) et rend ce que le bandeau affiche. `charger` fait les lectures. Rien n'est recalculé autrement que par bureau.mjs.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const CACHE = () => process.env.ORCH_CACHE || path.join(os.homedir(), '.cache', 'orchestration');

// Quatre états lisibles d'un coup d'œil, à partir des états de bureau.mjs.
export const etatBande = (etat) => ({ travaille: 'travaille', attend: 'attend', interrompue: 'attend', 'à relire': 'fini', finie: 'fini', rangée: 'fini' })[etat] || 'repos';
export const LIBELLE = { travaille: 'travaille', attend: 'attend', fini: 'fini', repos: 'au repos' };

// « claude-opus-5-5 » → « opus 5.5 » ; un modèle inconnu reste tel quel ; vide → « n/a ».
export function modeleCourt(m = '') {
  const x = /(haiku|sonnet|opus|fable)-(\d+)(?:-(\d+))?/.exec(m);
  return x ? `${x[1]} ${x[2]}${x[3] ? `.${x[3]}` : ''}` : (m || 'n/a');
}

const ORDRE = { attend: 0, travaille: 1, repos: 2, fini: 3 };

export function calculer({ D, attentes = [], poids = [], verdict = null, maintenant = Date.now() }) {
  if (!D || D.erreur) return { erreur: D?.erreur || 'Aucune donnée.', date: maintenant };
  const filles = (D.sessions || []).filter((s) => !s.suite);
  const agents = D.agents || [];
  // Les identifiants de la famille : app (local_…) et CLI de la lignée, des filles et des agents.
  const ids = new Set([...(D.lignee || []), ...(D.sessions || [])].flatMap((s) => [s.id, s.cli]).filter(Boolean));
  const mienne = attentes.filter((a) => a && ids.has(a.session) && (a.type === 'autorisation' || a.type === 'question'));
  const attendent = new Set(mienne.map((a) => a.session));
  const ligne = (x, genre) => {
    let etat = etatBande(x.etat);
    if (genre === 'session' && (attendent.has(x.id) || attendent.has(x.cli))) etat = 'attend';
    return { genre, nom: x.titre || x.description || x.id, modele: modeleCourt(x.modele || x.modeleReel), effort: x.effort || '', etat, cout: x.cout ?? null, message: etat === 'attend' ? (x.question || '') : '' };
  };
  const lignes = [...filles.map((s) => ligne(s, 'session')), ...agents.map((a) => ligne(a, 'agent'))]
    .sort((a, b) => ORDRE[a.etat] - ORDRE[b.etat]);
  const compte = (L) => L.reduce((o, x) => { o[x.etat] = (o[x.etat] || 0) + 1; return o; }, { travaille: 0, attend: 0, fini: 0, repos: 0 });
  // En attente de l'utilisateur : les lignes qui attendent, plus les attentes qui ne sont celles d'aucune ligne (la session elle-même).
  const idsLignes = new Set([...filles, ...agents].flatMap((x) => [x.id, x.cli]).filter(Boolean));
  const orphelines = mienne.filter((a) => !idsLignes.has(a.session));
  const enAttente = lignes.filter((l) => l.etat === 'attend').length + orphelines.length;
  const synthese = { enCours: lignes.filter((l) => l.etat === 'travaille').length, finis: lignes.filter((l) => l.etat === 'fini').length, enAttente, rien: lignes.length === 0 && enAttente === 0 };
  const chef = D.chef || {};
  // Palier : la dernière ligne du relevé de poids pour cette session (CLI), sinon n/a.
  const rel = [...poids].reverse().find((p) => p && (p.session === chef.cli || p.session === chef.id));
  return {
    date: maintenant, session: chef.id, titre: chef.titre || '',
    filles: { n: filles.length, ...compte(lignes.filter((l) => l.genre === 'session')) },
    agents: { n: agents.length, ...compte(lignes.filter((l) => l.genre === 'agent')) },
    lignes, synthese,
    contexte: { jetons: chef.ctx ?? null, palier: rel?.palier || null },
    cout: D.totaux?.cout ?? null, coutPartiel: !!D.totaux?.coutPartiel,
    attentes: { n: mienne.length, items: mienne.map((a) => ({ type: a.type, projet: a.projet || '', message: a.message || '', depuis: a.depuis || '' })) },
    verdict: verdict?.verdict ? { verdict: verdict.verdict, critere: verdict.critere || '' } : null,
  };
}

const lireJSON = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };

export function lireAttentes(dossier = path.join(CACHE(), 'attentes')) {
  try { return fs.readdirSync(dossier).filter((f) => f.endsWith('.json')).map((f) => lireJSON(path.join(dossier, f))).filter(Boolean); } catch { return []; }
}
export function lirePoids(fichier = path.join(CACHE(), 'poids-sessions.jsonl')) {
  try { return fs.readFileSync(fichier, 'utf8').split('\n').slice(-3000).filter(Boolean).flatMap((l) => { try { return [JSON.parse(l)]; } catch { return []; } }); } catch { return []; }
}

// Les lectures réelles : bureau.mjs (sessions, agents, coût, contexte), puis attentes, poids, verdict.
export async function charger({ session, dossier } = {}) {
  const { donnees } = await import('../outils/bureau.mjs');
  const D = donnees({ session: session || undefined, dossier: dossier || process.cwd() });
  const cli = D?.chef?.cli;
  const verdict = cli ? lireJSON(path.join(CACHE(), 'verdicts', `${cli}.json`)) : null;
  const { lire } = await import('./bandeau-etat.mjs');
  return { ...calculer({ D, attentes: lireAttentes(), poids: lirePoids(), verdict }), prefs: lire() };
}
