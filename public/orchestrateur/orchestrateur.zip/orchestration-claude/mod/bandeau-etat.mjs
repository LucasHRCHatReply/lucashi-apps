#!/usr/bin/env node
// Ce que le bandeau garde d'une session à l'autre : replié ou déplié, bulle d'accueil déjà vue.
// Fichier : ~/.cache/orchestration/bandeau.json (jamais de localStorage). CLI : `get` | `set deplie true|false` | `set onboardingVu true`.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const FICHIER = () => process.env.ORCH_BANDEAU || path.join(process.env.ORCH_CACHE || path.join(os.homedir(), '.cache', 'orchestration'), 'bandeau.json');
export const DEFAUT = { deplie: false, onboardingVu: false };   // replié par défaut, bulle pas encore vue

export function lire(f = FICHIER()) {
  try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); return { deplie: j.deplie === true, onboardingVu: j.onboardingVu === true }; } catch { return { ...DEFAUT }; }
}
export function ecrire(patch, f = FICHIER()) {
  const v = { ...lire(f), ...patch };
  fs.mkdirSync(path.dirname(f), { recursive: true });
  const t = `${f}.${process.pid}`; fs.writeFileSync(t, JSON.stringify(v)); fs.renameSync(t, f);
  return v;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === fs.realpathSync(process.argv[1])) {
  const [cmd, cle, val] = process.argv.slice(2);
  if (cmd === 'set' && ['deplie', 'onboardingVu'].includes(cle)) console.log(JSON.stringify(ecrire({ [cle]: val === 'true' })));
  else console.log(JSON.stringify(lire()));
}
