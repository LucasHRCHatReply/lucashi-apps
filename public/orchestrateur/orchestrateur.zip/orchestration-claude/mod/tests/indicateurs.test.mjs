#!/usr/bin/env node
// Tests des indicateurs du bandeau, sur des données factices : node mod/tests/indicateurs.test.mjs
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { calculer, etatBande, modeleCourt, lireAttentes, lirePoids } from '../indicateurs.mjs';

let echecs = 0;
const ok = (nom, cond, detail = '') => { if (!cond) echecs++; console.log(`${cond ? '✓' : '✗'} ${nom}${detail ? ` — ${detail}` : ''}`); };

const D = {
  chef: { id: 'local_chef', cli: 'cli-chef', titre: 'Chef', ctx: 245154, modele: 'claude-opus-5-5' },
  lignee: [{ id: 'local_chef', cli: 'cli-chef' }],
  sessions: [
    { id: 'local_f1', cli: 'cli-f1', titre: 'Fille A', etat: 'travaille', modele: 'claude-sonnet-5-5', effort: 'low', cout: 1 },
    { id: 'local_f2', cli: 'cli-f2', titre: 'Fille B', etat: 'finie', modele: 'claude-opus-5-5', effort: 'medium', cout: 2 },
    { id: 'local_f3', cli: 'cli-f3', titre: 'Fille B bis', etat: 'travaille', suite: 'x', modele: 'claude-opus-5-5', cout: 0 },   // relancée : ne compte pas
  ],
  agents: [{ id: 'a1', titre: 'Agent un', etat: 'travaille', modele: 'claude-haiku-5-5', effort: '', cout: 0.1 }, { id: 'a2', titre: 'Agent deux', etat: 'finie', modele: 'claude-sonnet-5-5', cout: 0.2 }],
  totaux: { cout: 12.5, coutPartiel: false },
};

ok('états', etatBande('interrompue') === 'attend' && etatBande('à relire') === 'fini' && etatBande('dort') === 'repos' && etatBande('travaille') === 'travaille');
ok('modèle court', modeleCourt('claude-opus-5-5') === 'opus 5.5' && modeleCourt('') === 'n/a' && modeleCourt('gpt-x') === 'gpt-x');

const R = calculer({ D, attentes: [], poids: [], verdict: null });
ok('filles comptées sans les relances', R.filles.n === 2 && R.filles.travaille === 1 && R.filles.fini === 1, JSON.stringify(R.filles));
ok('agents comptés', R.agents.n === 2 && R.agents.travaille === 1 && R.agents.fini === 1);
ok('contexte et coût repris tels quels', R.contexte.jetons === 245154 && R.cout === 12.5);
ok('0 en attente quand rien n’est écrit', R.attentes.n === 0 && R.contexte.palier === null && R.verdict === null);
ok('lignes : travail avant fini', R.lignes[0].etat === 'travaille' && R.lignes.at(-1).etat === 'fini' && R.lignes.length === 4);
ok('modèle · effort', R.lignes.find((l) => l.nom === 'Fille A').modele === 'sonnet 5.5' && R.lignes.find((l) => l.nom === 'Fille A').effort === 'low');

const A = [
  { session: 'cli-f2', type: 'question', message: 'Quelle option ?', projet: 'x', depuis: '2026-11-03T10:00:00Z' },
  { session: 'local_f1', type: 'autorisation', message: 'Bash', projet: 'x' },
  { session: 'cli-f1', type: 'inactive', message: 'dort' },       // inactive : ne compte pas
  { session: 'autre-session', type: 'question', message: 'ailleurs' },   // une autre famille : ne compte pas
];
const R2 = calculer({ D, attentes: A, poids: [{ session: 'cli-chef', contexte: 1, palier: 'note' }, { session: 'cli-chef', contexte: 260000, palier: 'avertir' }, { session: 'z', palier: 'note' }], verdict: { verdict: 'reussi', critere: 'tests verts' } });
ok('attentes de la famille seulement, inactive exclue', R2.attentes.n === 2, `n=${R2.attentes.n}`);
ok('une fille qui pose une question « attend »', R2.lignes.find((l) => l.nom === 'Fille B').etat === 'attend' && R2.filles.attend === 2, JSON.stringify(R2.filles));
ok('palier = dernière ligne du relevé', R2.contexte.palier === 'avertir');
ok('verdict repris', R2.verdict.verdict === 'reussi');
ok('erreur de données : pas de plantage', calculer({ D: { erreur: 'rien' } }).erreur === 'rien' && calculer({}).erreur);

// Lectures : dossier absent ou vide → 0 attente, sans casser ; lignes illisibles ignorées.
const T = fs.mkdtempSync(path.join(os.tmpdir(), 'bandeau-'));
ok('dossier d’attentes absent', lireAttentes(path.join(T, 'nope')).length === 0);
fs.mkdirSync(path.join(T, 'att'));
ok('dossier d’attentes vide', lireAttentes(path.join(T, 'att')).length === 0);
fs.writeFileSync(path.join(T, 'att', 'a.json'), JSON.stringify(A[0])); fs.writeFileSync(path.join(T, 'att', 'b.json'), '{pas du json');
ok('un fichier cassé est ignoré', lireAttentes(path.join(T, 'att')).length === 1);
fs.writeFileSync(path.join(T, 'p.jsonl'), '{"session":"s","palier":"note"}\nzzz\n{"session":"t"}\n');
ok('relevé de poids : ligne cassée ignorée, fichier absent = []', lirePoids(path.join(T, 'p.jsonl')).length === 2 && lirePoids(path.join(T, 'absent')).length === 0);

console.log(echecs ? `\n${echecs} échec(s)` : '\ntout passe');
process.exit(echecs ? 1 : 0);
